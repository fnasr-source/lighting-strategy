import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeProvider } from "@/lib/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import ClientDashboard from "@/pages/client-dashboard";
import Clients from "@/pages/clients";
import Integrations from "@/pages/integrations";
import Reports from "@/pages/reports";
import Settings from "@/pages/settings";
import AuthPage from "@/pages/auth-page";
import FirstTimeSetup from "@/pages/first-time-setup";
import ReportViewer from "@/pages/report-viewer";

function Router() {
  return (
    <Switch>
      {/* Protected internal routes */}
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/clients" component={Clients} />
      <ProtectedRoute path="/integrations" component={Integrations} />
      <ProtectedRoute path="/reports" component={Reports} />
      <ProtectedRoute path="/settings" component={Settings} />
      
      {/* Public client dashboard route */}
      <Route path="/client/:clientId" component={ClientDashboard} />
      
      {/* Public report viewer route */}
      <Route path="/report/:slug" component={ReportViewer} />
      
      {/* Auth page */}
      <Route path="/auth" component={AuthPage} />
      
      {/* First-time setup page */}
      <Route path="/setup" component={FirstTimeSetup} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const [location] = useLocation();
  const isClientDashboard = location.startsWith('/client/');
  const isReportViewer = location.startsWith('/report/');
  const isAuthPage = location === '/auth';
  const isSetupPage = location === '/setup';

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  // Auth page or setup page view (full screen, no sidebar)
  if (isAuthPage || isSetupPage) {
    return (
      <div className="h-screen w-full overflow-x-hidden">
        <Router />
      </div>
    );
  }

  // Client dashboard and report viewer (no sidebar, public shareable)
  if (isClientDashboard || isReportViewer) {
    return (
      <div className="flex flex-col h-screen w-full overflow-x-hidden">
        <header className="flex items-center justify-end p-4 border-b border-border">
          <ThemeToggle />
        </header>
        <main className="flex-1 overflow-auto p-6 max-w-full">
          <Router />
        </main>
      </div>
    );
  }

  // Internal agency view (with sidebar)
  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full overflow-x-hidden">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-x-hidden">
          <header className="flex items-center justify-between p-4 border-b border-border">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <ThemeToggle />
          </header>
          <main className="flex-1 overflow-auto p-6 max-w-full">
            <Router />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <TooltipProvider>
            <AppContent />
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
