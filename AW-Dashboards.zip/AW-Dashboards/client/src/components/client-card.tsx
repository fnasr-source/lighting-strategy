import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MoreVertical, Eye, Settings, Trash2, Link2, Check, RefreshCw } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { GA4ConfigDialog } from "./ga4-config-dialog";
import type { Client } from "@shared/schema";

interface ClientCardProps {
  client: Client;
  connectedPlatforms: number;
  lastReportDate?: string;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export function ClientCard({
  client,
  connectedPlatforms,
  lastReportDate,
  onView,
  onEdit,
  onDelete,
}: ClientCardProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  
  const initials = client.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  const syncMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", `/api/clients/${client.id}/sync-historical-data`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/clients/${client.id}/monthly-metrics`] });
      toast({
        title: "Historical data sync started",
        description: "This may take a few moments. Monthly Review will update automatically when complete.",
      });
    },
    onError: () => {
      toast({
        title: "Sync failed",
        description: "Failed to start historical data sync. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCopyLink = () => {
    const clientDashboardUrl = `${window.location.origin}/client/${client.id}`;
    navigator.clipboard.writeText(clientDashboardUrl);
    setCopied(true);
    toast({
      title: "Link copied!",
      description: "Client dashboard link has been copied to clipboard.",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card className="hover-elevate" data-testid={`card-client-${client.id}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-3">
        <div className="flex items-center gap-3">
          <Avatar>
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-semibold">{client.name}</h3>
            {client.email && (
              <p className="text-sm text-muted-foreground">{client.email}</p>
            )}
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" data-testid={`button-menu-${client.id}`}>
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onView} data-testid={`menuitem-view-${client.id}`}>
              <Eye className="h-4 w-4 mr-2" />
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleCopyLink} data-testid={`menuitem-copy-link-${client.id}`}>
              {copied ? <Check className="h-4 w-4 mr-2" /> : <Link2 className="h-4 w-4 mr-2" />}
              {copied ? "Link Copied!" : "Copy Dashboard Link"}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onEdit} data-testid={`menuitem-edit-${client.id}`}>
              <Settings className="h-4 w-4 mr-2" />
              Edit Client
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onDelete} className="text-destructive" data-testid={`menuitem-delete-${client.id}`}>
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Connected Platforms</span>
          <span className="font-medium">{connectedPlatforms}</span>
        </div>
        {lastReportDate && (
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Last Report</span>
            <span className="font-medium">{lastReportDate}</span>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col gap-2">
        <div className="flex gap-2 w-full">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={onView}
            data-testid={`button-view-${client.id}`}
          >
            View Dashboard
          </Button>
          <GA4ConfigDialog client={client} />
        </div>
        <Button
          variant="secondary"
          size="sm"
          className="w-full"
          onClick={() => syncMutation.mutate()}
          disabled={syncMutation.isPending}
          data-testid={`button-sync-${client.id}`}
        >
          {syncMutation.isPending ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Syncing...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4 mr-2" />
              Sync Historical Data
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
