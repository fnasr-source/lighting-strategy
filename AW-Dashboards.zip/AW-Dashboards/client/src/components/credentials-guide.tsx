import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";

interface CredentialsGuideProps {
  platform: string;
}

export function CredentialsGuide({ platform }: CredentialsGuideProps) {
  const guides: Record<string, JSX.Element> = {
    "Meta Ads": (
      <Alert data-testid="credentials-guide-meta">
        <Info className="h-4 w-4" />
        <AlertTitle>How to get Meta Ads API credentials</AlertTitle>
        <AlertDescription className="space-y-2 mt-2">
          <div className="space-y-1">
            <p className="font-medium">Required credentials:</p>
            <pre className="text-xs bg-muted p-2 rounded">
{`{
  "accessToken": "YOUR_ACCESS_TOKEN",
  "adAccountId": "YOUR_AD_ACCOUNT_ID"
}`}
            </pre>
          </div>
          <div className="space-y-1 text-sm">
            <p className="font-medium">Steps to get credentials:</p>
            <ol className="list-decimal list-inside space-y-1 ml-2">
              <li>Go to <a href="https://developers.facebook.com/" target="_blank" rel="noopener noreferrer" className="text-primary underline">Meta for Developers</a></li>
              <li>Create an app or select an existing app</li>
              <li>Add the "Marketing API" product to your app</li>
              <li>Generate an access token with <code className="bg-muted px-1 rounded">ads_read</code> permissions</li>
              <li>Find your Ad Account ID in Meta Ads Manager (Settings → Ad Account Settings)</li>
            </ol>
          </div>
        </AlertDescription>
      </Alert>
    ),
    "Shopify": (
      <Alert data-testid="credentials-guide-shopify">
        <Info className="h-4 w-4" />
        <AlertTitle>How to get Shopify API credentials</AlertTitle>
        <AlertDescription className="space-y-2 mt-2">
          <div className="space-y-1">
            <p className="font-medium">Required credentials:</p>
            <pre className="text-xs bg-muted p-2 rounded">
{`{
  "shopUrl": "your-store.myshopify.com",
  "accessToken": "YOUR_ADMIN_API_ACCESS_TOKEN"
}`}
            </pre>
          </div>
          <div className="space-y-1 text-sm">
            <p className="font-medium">Steps to get credentials:</p>
            <ol className="list-decimal list-inside space-y-1 ml-2">
              <li>Log in to your Shopify admin panel</li>
              <li>Go to Settings → Apps and sales channels</li>
              <li>Click "Develop apps" → "Create an app"</li>
              <li>Give your app a name (e.g., "Marketing Dashboard")</li>
              <li>Go to "Configuration" and configure Admin API scopes:
                <ul className="list-disc list-inside ml-4 mt-1">
                  <li><code className="bg-muted px-1 rounded">read_orders</code></li>
                  <li><code className="bg-muted px-1 rounded">read_products</code></li>
                </ul>
              </li>
              <li>Click "Install app" and reveal the Admin API access token</li>
              <li>Copy your access token and store URL</li>
            </ol>
          </div>
        </AlertDescription>
      </Alert>
    ),
    "Google Ads": (
      <Alert data-testid="credentials-guide-google">
        <Info className="h-4 w-4" />
        <AlertTitle>How to get Google Ads API credentials</AlertTitle>
        <AlertDescription className="space-y-2 mt-2">
          <div className="space-y-1">
            <p className="font-medium">Required credentials:</p>
            <pre className="text-xs bg-muted p-2 rounded">
{`{
  "customerId": "123-456-7890",
  "developerToken": "YOUR_DEVELOPER_TOKEN",
  "refreshToken": "YOUR_REFRESH_TOKEN"
}`}
            </pre>
          </div>
          <div className="space-y-1 text-sm">
            <p className="font-medium">Steps to get credentials:</p>
            <ol className="list-decimal list-inside space-y-1 ml-2">
              <li>Go to <a href="https://ads.google.com/" target="_blank" rel="noopener noreferrer" className="text-primary underline">Google Ads</a></li>
              <li>Click Tools & Settings → API Center</li>
              <li>Request a developer token and wait for approval</li>
              <li>Set up OAuth 2.0 credentials in Google Cloud Console</li>
              <li>Generate a refresh token using the OAuth 2.0 Playground</li>
              <li>Find your Customer ID in Google Ads (top right corner)</li>
            </ol>
          </div>
        </AlertDescription>
      </Alert>
    ),
    "TikTok Ads": (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>TikTok Ads Integration</AlertTitle>
        <AlertDescription>
          <p className="text-sm">TikTok Ads integration is coming soon. Currently using demo data.</p>
        </AlertDescription>
      </Alert>
    ),
    "Snapchat Ads": (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Snapchat Ads Integration</AlertTitle>
        <AlertDescription>
          <p className="text-sm">Snapchat Ads integration is coming soon. Currently using demo data.</p>
        </AlertDescription>
      </Alert>
    ),
    "Google Analytics": (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Google Analytics Integration</AlertTitle>
        <AlertDescription>
          <p className="text-sm">Google Analytics integration is coming soon. Currently using demo data.</p>
        </AlertDescription>
      </Alert>
    ),
    "WooCommerce": (
      <Alert data-testid="credentials-guide-woocommerce">
        <Info className="h-4 w-4" />
        <AlertTitle>How to get WooCommerce API credentials</AlertTitle>
        <AlertDescription className="space-y-2 mt-2">
          <div className="space-y-1">
            <p className="font-medium">Required credentials:</p>
            <pre className="text-xs bg-muted p-2 rounded">
{`{
  "storeUrl": "https://yourstore.com",
  "consumerKey": "ck_...",
  "consumerSecret": "cs_..."
}`}
            </pre>
          </div>
          <div className="space-y-1 text-sm">
            <p className="font-medium">Steps to get credentials:</p>
            <ol className="list-decimal list-inside space-y-1 ml-2">
              <li>Log in to your WordPress admin panel</li>
              <li>Go to WooCommerce → Settings → Advanced → REST API</li>
              <li>Click "Add key" to create a new API key</li>
              <li>Enter a description (e.g., "Marketing Dashboard")</li>
              <li>Select User: choose an admin user</li>
              <li>Select Permissions: <code className="bg-muted px-1 rounded">Read</code></li>
              <li>Click "Generate API key" and save the consumer key and secret</li>
            </ol>
          </div>
        </AlertDescription>
      </Alert>
    ),
  };

  return guides[platform] || null;
}
