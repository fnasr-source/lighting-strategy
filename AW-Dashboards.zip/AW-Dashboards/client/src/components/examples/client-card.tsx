import { ClientCard } from '../client-card';

export default function ClientCardExample() {
  const handleAction = (action: string, clientId: string) => {
    console.log(`${action} triggered for client ${clientId}`);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
      <ClientCard
        id="1"
        name="Acme Corporation"
        email="contact@acme.com"
        connectedPlatforms={5}
        lastReportDate="2 days ago"
        onView={() => handleAction('View', '1')}
        onEdit={() => handleAction('Edit', '1')}
        onDelete={() => handleAction('Delete', '1')}
      />
      <ClientCard
        id="2"
        name="TechStart Inc"
        email="hello@techstart.io"
        connectedPlatforms={3}
        lastReportDate="1 week ago"
        onView={() => handleAction('View', '2')}
        onEdit={() => handleAction('Edit', '2')}
        onDelete={() => handleAction('Delete', '2')}
      />
      <ClientCard
        id="3"
        name="Global Retail Co"
        connectedPlatforms={6}
        lastReportDate="Yesterday"
        onView={() => handleAction('View', '3')}
        onEdit={() => handleAction('Edit', '3')}
        onDelete={() => handleAction('Delete', '3')}
      />
    </div>
  );
}
