import { MetricCard } from '../metric-card';
import { Eye, MousePointerClick, DollarSign, TrendingUp } from 'lucide-react';

export default function MetricCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-6">
      <MetricCard
        title="Impressions"
        value="2.4M"
        change={12.5}
        icon={Eye}
        trend={[45, 52, 48, 61, 58, 72, 69]}
      />
      <MetricCard
        title="Clicks"
        value="142.5K"
        change={8.3}
        icon={MousePointerClick}
        trend={[35, 42, 38, 51, 48, 62, 59]}
      />
      <MetricCard
        title="Revenue"
        value="$52,340"
        change={-3.2}
        icon={DollarSign}
        trend={[65, 62, 58, 51, 48, 42, 39]}
      />
      <MetricCard
        title="ROAS"
        value="4.2x"
        change={5.7}
        icon={TrendingUp}
        trend={[25, 32, 38, 41, 48, 52, 59]}
      />
    </div>
  );
}
