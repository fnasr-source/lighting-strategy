import { PerformanceChart } from '../performance-chart';

export default function PerformanceChartExample() {
  const data = [
    { date: 'Jan 1', impressions: 45000, clicks: 2100, conversions: 180 },
    { date: 'Jan 8', impressions: 52000, clicks: 2400, conversions: 210 },
    { date: 'Jan 15', impressions: 48000, clicks: 2200, conversions: 195 },
    { date: 'Jan 22', impressions: 61000, clicks: 2800, conversions: 245 },
    { date: 'Jan 29', impressions: 58000, clicks: 2650, conversions: 230 },
    { date: 'Feb 5', impressions: 72000, clicks: 3200, conversions: 290 },
    { date: 'Feb 12', impressions: 69000, clicks: 3050, conversions: 275 },
  ];

  return (
    <div className="p-6">
      <PerformanceChart
        title="Campaign Performance Over Time"
        data={data}
        lines={[
          { dataKey: 'impressions', color: 'hsl(var(--chart-1))', name: 'Impressions' },
          { dataKey: 'clicks', color: 'hsl(var(--chart-2))', name: 'Clicks' },
          { dataKey: 'conversions', color: 'hsl(var(--chart-3))', name: 'Conversions' },
        ]}
      />
    </div>
  );
}
