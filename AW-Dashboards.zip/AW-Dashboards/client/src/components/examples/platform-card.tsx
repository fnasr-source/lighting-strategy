import { PlatformCard } from '../platform-card';
import { SiFacebook, SiGoogle, SiTiktok, SiSnapchat, SiShopify } from 'react-icons/si';
import { BarChart3 } from 'lucide-react';

export default function PlatformCardExample() {
  const handleAction = (action: string, platform: string) => {
    console.log(`${action} triggered for ${platform}`);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
      <PlatformCard
        name="Meta Ads"
        icon={SiFacebook as any}
        isConnected={true}
        lastSync="2 hours ago"
        onConnect={() => handleAction('Connect', 'Meta Ads')}
        onConfigure={() => handleAction('Configure', 'Meta Ads')}
      />
      <PlatformCard
        name="Google Ads"
        icon={SiGoogle as any}
        isConnected={true}
        lastSync="1 hour ago"
        onConnect={() => handleAction('Connect', 'Google Ads')}
        onConfigure={() => handleAction('Configure', 'Google Ads')}
      />
      <PlatformCard
        name="TikTok Ads"
        icon={SiTiktok as any}
        isConnected={false}
        onConnect={() => handleAction('Connect', 'TikTok Ads')}
        onConfigure={() => handleAction('Configure', 'TikTok Ads')}
      />
      <PlatformCard
        name="Snapchat Ads"
        icon={SiSnapchat as any}
        isConnected={false}
        onConnect={() => handleAction('Connect', 'Snapchat Ads')}
        onConfigure={() => handleAction('Configure', 'Snapchat Ads')}
      />
      <PlatformCard
        name="Google Analytics"
        icon={BarChart3}
        isConnected={true}
        lastSync="30 minutes ago"
        onConnect={() => handleAction('Connect', 'Google Analytics')}
        onConfigure={() => handleAction('Configure', 'Google Analytics')}
      />
      <PlatformCard
        name="Shopify"
        icon={SiShopify as any}
        isConnected={true}
        lastSync="3 hours ago"
        onConnect={() => handleAction('Connect', 'Shopify')}
        onConfigure={() => handleAction('Configure', 'Shopify')}
      />
    </div>
  );
}
