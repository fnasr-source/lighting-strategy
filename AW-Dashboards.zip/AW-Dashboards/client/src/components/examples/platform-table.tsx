import { PlatformTable } from '../platform-table';

export default function PlatformTableExample() {
  const data = [
    {
      platform: 'Meta Ads',
      impressions: 1200000,
      clicks: 48000,
      ctr: 4.0,
      conversions: 1200,
      spend: 15000,
      revenue: 72000,
      roas: 4.8,
    },
    {
      platform: 'Google Ads',
      impressions: 850000,
      clicks: 34000,
      ctr: 4.0,
      conversions: 950,
      spend: 12000,
      revenue: 52000,
      roas: 4.33,
    },
    {
      platform: 'TikTok Ads',
      impressions: 650000,
      clicks: 26000,
      ctr: 4.0,
      conversions: 680,
      spend: 8000,
      revenue: 28000,
      roas: 3.5,
    },
    {
      platform: 'Snapchat Ads',
      impressions: 320000,
      clicks: 12800,
      ctr: 4.0,
      conversions: 320,
      spend: 5000,
      revenue: 14000,
      roas: 2.8,
    },
  ];

  return (
    <div className="p-6">
      <PlatformTable data={data} />
    </div>
  );
}
