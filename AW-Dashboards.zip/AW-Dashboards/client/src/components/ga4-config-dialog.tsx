import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { BarChart3 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Client } from "@shared/schema";

interface GA4ConfigDialogProps {
  client: Client;
}

export function GA4ConfigDialog({ client }: GA4ConfigDialogProps) {
  const [open, setOpen] = useState(false);
  const [propertyId, setPropertyId] = useState(client.ga4PropertyId || "");
  const [credentialsJson, setCredentialsJson] = useState("");
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: async (data: { ga4PropertyId: string; ga4Credentials: any }) => {
      return await apiRequest("PATCH", `/api/clients/${client.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      setOpen(false);
      toast({
        title: "Google Analytics connected",
        description: "Session data will now be fetched from GA4 when available.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to connect Google Analytics. Please check your credentials.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!propertyId.trim()) {
      toast({
        title: "Error",
        description: "Please enter a GA4 Property ID.",
        variant: "destructive",
      });
      return;
    }

    // Build the payload - only include credentials if new JSON is provided
    const payload: any = {
      ga4PropertyId: propertyId,
    };

    // Only update credentials if new JSON is provided
    if (credentialsJson.trim()) {
      try {
        payload.ga4Credentials = JSON.parse(credentialsJson);
      } catch (error) {
        toast({
          title: "Error",
          description: "Invalid JSON format for service account credentials.",
          variant: "destructive",
        });
        return;
      }
    } else if (!isConnected) {
      // If connecting for the first time, credentials are required
      toast({
        title: "Error",
        description: "Service account credentials are required for initial connection.",
        variant: "destructive",
      });
      return;
    }
    // If already connected and no new credentials provided, keep existing ones

    updateMutation.mutate(payload);
  };

  const handleDisconnect = () => {
    updateMutation.mutate({
      ga4PropertyId: "",
      ga4Credentials: null,
    });
  };

  const isConnected = !!client.ga4PropertyId;

  return (
    <>
      <Button
        variant={isConnected ? "default" : "outline"}
        size="sm"
        onClick={() => setOpen(true)}
        data-testid={`button-ga4-config-${client.id}`}
      >
        <BarChart3 className="h-4 w-4 mr-2" />
        {isConnected ? "GA4 Connected" : "Connect GA4"}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[600px]" data-testid="dialog-ga4-config">
          <DialogHeader>
            <DialogTitle>Google Analytics 4 Configuration</DialogTitle>
            <DialogDescription>
              Connect your Google Analytics 4 property to enable accurate session tracking and conversion rate calculations.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="propertyId">
                GA4 Property ID
                <span className="text-muted-foreground text-sm ml-2">(Required)</span>
              </Label>
              <Input
                id="propertyId"
                placeholder="123456789 or properties/123456789"
                value={propertyId}
                onChange={(e) => setPropertyId(e.target.value)}
                data-testid="input-ga4-property-id"
              />
              <p className="text-sm text-muted-foreground">
                Find this in Google Analytics → Admin → Property Settings
              </p>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="credentials">
                Service Account Credentials JSON
                <span className="text-muted-foreground text-sm ml-2">
                  {isConnected ? "(Leave empty to keep existing)" : "(Required for API access)"}
                </span>
              </Label>
              <Textarea
                id="credentials"
                placeholder={
                  isConnected
                    ? "Leave empty to keep existing credentials, or paste new JSON to update"
                    : `{\n  "type": "service_account",\n  "project_id": "your-project",\n  "private_key_id": "...",\n  "private_key": "...",\n  "client_email": "...",\n  ...\n}`
                }
                value={credentialsJson}
                onChange={(e) => setCredentialsJson(e.target.value)}
                rows={8}
                className="font-mono text-sm"
                data-testid="input-ga4-credentials"
              />
              <p className="text-sm text-muted-foreground">
                {isConnected ? (
                  <>Credentials are securely stored. Only paste new JSON if you need to update them.</>
                ) : (
                  <>
                    Create a service account in Google Cloud Console and download the JSON key file.{" "}
                    <a
                      href="https://developers.google.com/analytics/devguides/reporting/data/v1/quickstart-client-libraries#python"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline"
                    >
                      Learn how
                    </a>
                  </>
                )}
              </p>
            </div>

            {isConnected && (
              <div className="bg-muted/50 p-3 rounded-md">
                <p className="text-sm font-medium text-green-600 dark:text-green-500">
                  ✓ Google Analytics 4 is currently connected
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Property ID: {client.ga4PropertyId}
                </p>
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            {isConnected && (
              <Button
                variant="destructive"
                onClick={handleDisconnect}
                disabled={updateMutation.isPending}
                data-testid="button-ga4-disconnect"
              >
                Disconnect
              </Button>
            )}
            <Button
              onClick={handleSubmit}
              disabled={updateMutation.isPending}
              data-testid="button-ga4-save"
            >
              {updateMutation.isPending ? "Saving..." : isConnected ? "Update" : "Connect"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
