import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Info } from "lucide-react";
import { LucideIcon } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { SiFacebook, SiGoogle, SiTiktok, SiSnapchat, SiShopify, SiWoo } from "react-icons/si";
import { Badge } from "@/components/ui/badge";

interface TrendPoint {
  date: string;
  value: number;
}

interface MetricCardProps {
  title: string;
  value: string;
  change: number;
  icon: LucideIcon;
  trend?: TrendPoint[];
  tooltip?: string;
  platforms?: string[];
}

const PlatformIcon = ({ platform }: { platform: string }) => {
  const iconMap: Record<string, { icon: any; label: string; color: string }> = {
    "Meta Ads": { icon: SiFacebook, label: "Meta", color: "text-blue-500" },
    "Google Ads": { icon: SiGoogle, label: "Google", color: "text-red-500" },
    "TikTok Ads": { icon: SiTiktok, label: "TikTok", color: "text-pink-500" },
    "Snapchat Ads": { icon: SiSnapchat, label: "Snapchat", color: "text-yellow-500" },
    "Shopify": { icon: SiShopify, label: "Shopify", color: "text-green-500" },
    "WooCommerce": { icon: SiWoo, label: "WooCommerce", color: "text-purple-500" },
  };
  
  const config = iconMap[platform];
  if (!config) return null;
  
  const Icon = config.icon;
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span className={`inline-flex ${config.color}`} data-testid={`platform-icon-${platform.toLowerCase().replace(/\s+/g, '-')}`}>
          <Icon className="h-3 w-3" />
        </span>
      </TooltipTrigger>
      <TooltipContent side="bottom">
        <p className="text-xs">{config.label}</p>
      </TooltipContent>
    </Tooltip>
  );
};

export function MetricCard({ title, value, change, icon: Icon, trend, tooltip, platforms }: MetricCardProps) {
  const isPositive = change >= 0;
  
  const maxTrendValue = trend && trend.length > 0 
    ? Math.max(...trend.map(t => t.value || 0))
    : 1;

  const formatTrendValue = (val: number | undefined | null): string => {
    if (val === undefined || val === null || isNaN(val)) return '0';
    if (val >= 1000000) return `${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `${(val / 1000).toFixed(1)}K`;
    return val.toLocaleString();
  };

  return (
    <Card data-testid={`card-metric-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <div className="flex items-center gap-1.5">
          <div className="text-sm font-medium text-muted-foreground">{title}</div>
          {tooltip && (
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" data-testid={`tooltip-${title.toLowerCase().replace(/\s+/g, '-')}`} />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="text-sm">{tooltip}</p>
              </TooltipContent>
            </Tooltip>
          )}
        </div>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-mono font-semibold">{value}</div>
        <div className="flex items-center justify-between gap-2 mt-1">
          <div className="flex items-center gap-1">
            {isPositive ? (
              <TrendingUp className="h-3 w-3 text-chart-2" />
            ) : (
              <TrendingDown className="h-3 w-3 text-destructive" />
            )}
            <span
              className={`text-xs font-medium ${
                isPositive ? "text-chart-2" : "text-destructive"
              }`}
            >
              {isPositive ? "+" : ""}{change}%
            </span>
            <span className="text-xs text-muted-foreground ml-1">vs last period</span>
          </div>
          {platforms && platforms.length > 0 && (
            <div className="flex items-center gap-1" data-testid={`platforms-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {platforms.map((platform, idx) => (
                <PlatformIcon key={idx} platform={platform} />
              ))}
            </div>
          )}
        </div>
        {trend && trend.length > 0 && (
          <div className="mt-2 h-12 flex items-end gap-0.5">
            {trend.map((point, i) => (
              <Tooltip key={i} delayDuration={0}>
                <TooltipTrigger asChild>
                  <button
                    className="flex-1 bg-primary/20 rounded-sm hover-elevate cursor-pointer transition-colors touch-manipulation"
                    style={{ height: `${(point.value / maxTrendValue) * 100}%` }}
                    data-testid={`sparkline-bar-${i}`}
                    aria-label={`${point.date}: ${formatTrendValue(point.value)}`}
                  />
                </TooltipTrigger>
                <TooltipContent>
                  <div className="text-xs">
                    <div className="font-semibold">{point.date}</div>
                    <div className="text-muted-foreground">{formatTrendValue(point.value)}</div>
                  </div>
                </TooltipContent>
              </Tooltip>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
