import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Loader2, ChevronUp, ChevronDown, ArrowUp, ArrowDown } from "lucide-react";
import { useState, useMemo } from "react";

interface MonthlyMetricsTableProps {
  clientId: string;
  baseCurrency: string;
}

interface MonthlyMetrics {
  month: string;
  spend: number;
  adRevenue: number;
  ecommerceRevenue: number;
  roas: number;
  orders: number;
  cpo: number;
  aov: number;
  cpm: number;
  impressions: number;
  roasMoM?: number;
  cpoMoM?: number;
}

type SortField = keyof MonthlyMetrics;
type SortDirection = 'asc' | 'desc';

// Generate list of last N completed months (excluding current month)
function getLastCompletedMonths(count: number): string[] {
  const months: string[] = [];
  const now = new Date();
  
  // Start from last month (completed month)
  let year = now.getFullYear();
  let month = now.getMonth(); // 0-11, current month
  
  for (let i = 0; i < count; i++) {
    month--; // Go to previous month
    if (month < 0) {
      month = 11;
      year--;
    }
    const monthKey = `${year}-${String(month + 1).padStart(2, '0')}`;
    months.unshift(monthKey); // Add to beginning so oldest is first
  }
  
  return months;
}

// Aggregate daily data into monthly metrics with all months filled
function aggregateByMonth(dailyData: Array<{ 
  isoDate?: string;
  date: string; 
  spend: number; 
  revenue: number;
  conversions: number;
  impressions: number;
}>): MonthlyMetrics[] {
  const monthlyMap = new Map<string, { 
    spend: number; 
    revenue: number;
    conversions: number;
    impressions: number;
  }>();

  dailyData.forEach(({ isoDate, date, spend, revenue, conversions, impressions }) => {
    // Use isoDate if available (format: "2025-11-04"), fallback to date for backwards compatibility
    const dateStr = isoDate || date;
    const dateObj = new Date(dateStr);
    const monthKey = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, '0')}`;
    
    const existing = monthlyMap.get(monthKey) || { spend: 0, revenue: 0, conversions: 0, impressions: 0 };
    monthlyMap.set(monthKey, {
      spend: existing.spend + (spend || 0),
      revenue: existing.revenue + (revenue || 0),
      conversions: existing.conversions + (conversions || 0),
      impressions: existing.impressions + (impressions || 0),
    });
  });

  // Generate complete list of last 14 completed months
  const allMonths = getLastCompletedMonths(14);
  
  // Fill in data for all months (zeros for missing months)
  const monthlyData: MonthlyMetrics[] = allMonths.map(month => {
    const data = monthlyMap.get(month) || { spend: 0, revenue: 0, conversions: 0, impressions: 0 };
    return {
      month,
      spend: data.spend,
      revenue: data.revenue,
      orders: data.conversions,
      impressions: data.impressions,
      roas: data.spend > 0 ? data.revenue / data.spend : 0,
      cpo: data.spend > 0 && data.conversions > 0 ? data.spend / data.conversions : 0,
      aov: data.conversions > 0 ? data.revenue / data.conversions : 0,
      cpm: data.impressions > 0 ? (data.spend / data.impressions) * 1000 : 0,
    };
  });

  // Calculate month-over-month changes
  for (let i = 1; i < monthlyData.length; i++) {
    const current = monthlyData[i];
    const previous = monthlyData[i - 1];
    
    if (previous.roas > 0) {
      current.roasMoM = ((current.roas - previous.roas) / previous.roas) * 100;
    }
    
    if (previous.cpo > 0) {
      current.cpoMoM = ((current.cpo - previous.cpo) / previous.cpo) * 100;
    }
  }

  return monthlyData;
}

// Format month for display (e.g., "2024-01" -> "Jan 2024")
function formatMonth(monthStr: string): string {
  const [year, month] = monthStr.split('-');
  const date = new Date(parseInt(year), parseInt(month) - 1);
  return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
}

// Format currency
function formatCurrency(value: number, currency: string): string {
  if (!currency || currency === '') {
    currency = 'USD';
  }
  
  const number = value.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  
  if (currency === 'EGP') {
    return `${number} £ E`;
  }
  
  try {
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
    
    const parts = formatter.formatToParts(1);
    const symbol = parts.find(p => p.type === 'currency')?.value || currency;
    
    return `${number} ${symbol}`;
  } catch {
    return number;
  }
}

// Get color class based on value and type
function getColorClass(value: number, type: 'spend' | 'revenue' | 'roas' | 'cpo'): string {
  if (value === 0) return '';
  
  switch (type) {
    case 'spend':
    case 'revenue':
      // Blue scale - higher is more intense
      if (value > 50000) return 'bg-blue-500/10 text-blue-700 dark:text-blue-400';
      if (value > 20000) return 'bg-blue-400/10 text-blue-600 dark:text-blue-300';
      if (value > 5000) return 'bg-blue-300/10 text-blue-500 dark:text-blue-200';
      return 'bg-blue-200/10 text-blue-400 dark:text-blue-100';
    
    case 'roas':
      // Green to red - high ROAS is green
      if (value >= 5) return 'bg-green-500/10 text-green-700 dark:text-green-400';
      if (value >= 3) return 'bg-green-400/10 text-green-600 dark:text-green-300';
      if (value >= 2) return 'bg-yellow-400/10 text-yellow-600 dark:text-yellow-300';
      if (value >= 1) return 'bg-orange-400/10 text-orange-600 dark:text-orange-300';
      return 'bg-red-400/10 text-red-600 dark:text-red-300';
    
    case 'cpo':
      // Red to green - low CPO is green
      if (value <= 50) return 'bg-green-500/10 text-green-700 dark:text-green-400';
      if (value <= 100) return 'bg-green-400/10 text-green-600 dark:text-green-300';
      if (value <= 200) return 'bg-yellow-400/10 text-yellow-600 dark:text-yellow-300';
      if (value <= 300) return 'bg-orange-400/10 text-orange-600 dark:text-orange-300';
      return 'bg-red-400/10 text-red-600 dark:text-red-300';
    
    default:
      return '';
  }
}

export function MonthlyMetricsTable({ clientId, baseCurrency }: MonthlyMetricsTableProps) {
  const [sortField, setSortField] = useState<SortField>('month');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  // Fetch pre-aggregated monthly metrics (instant loading!)
  const { data: monthlyMetrics, isLoading } = useQuery<{
    months: Array<{
      monthEndDate: string;
      currency: string;
      combined: {
        spend: number;
        revenue: number;
        orders: number;
        impressions: number;
        roas: number;
        cpo: number;
        aov: number;
        cpm: number;
      };
    }>;
    asOf: string;
  }>({
    queryKey: [`/api/clients/${clientId}/monthly-metrics`],
    enabled: !!clientId,
  });

  const monthlyData = useMemo(() => {
    if (!monthlyMetrics?.months) return [];
    
    // Transform API response to table format and calculate MoM changes
    const data: MonthlyMetrics[] = monthlyMetrics.months.map(m => {
      const [year, month, day] = m.monthEndDate.split('-');
      const monthKey = `${year}-${month}`;
      return {
        month: monthKey,
        spend: m.ad?.spend || 0,
        adRevenue: m.ad?.revenue || 0,
        ecommerceRevenue: m.ecommerce?.revenue || 0,
        roas: m.ad?.roas || 0,
        orders: m.ecommerce?.orders || 0,
        cpo: m.ad?.cpo || 0,
        aov: m.ecommerce?.aov || 0,
        cpm: m.ad?.cpm || 0,
        impressions: m.ad?.impressions || 0,
      };
    });
    
    // Calculate month-over-month changes
    for (let i = 1; i < data.length; i++) {
      const current = data[i];
      const previous = data[i - 1];
      
      if (previous.roas > 0) {
        current.roasMoM = ((current.roas - previous.roas) / previous.roas) * 100;
      }
      
      if (previous.cpo > 0) {
        current.cpoMoM = ((current.cpo - previous.cpo) / previous.cpo) * 100;
      }
    }
    
    return data;
  }, [monthlyMetrics]);

  const sortedData = useMemo(() => {
    if (monthlyData.length === 0) return [];
    
    const sorted = [...monthlyData].sort((a, b) => {
      const aValue = a[sortField] ?? 0;
      const bValue = b[sortField] ?? 0;
      
      let comparison = 0;
      
      if (sortField === 'month') {
        comparison = aValue.toString().localeCompare(bValue.toString());
      } else {
        comparison = (aValue as number) - (bValue as number);
      }
      
      // If primary sort values are equal, sort by month as secondary key for stable sorting
      if (comparison === 0) {
        comparison = a.month.localeCompare(b.month);
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });
    
    return sorted;
  }, [monthlyData, sortField, sortDirection]);

  const totals = useMemo(() => {
    if (monthlyData.length === 0) return null;
    
    const totalSpend = monthlyData.reduce((sum, m) => sum + m.spend, 0);
    const totalAdRevenue = monthlyData.reduce((sum, m) => sum + m.adRevenue, 0);
    const totalEcommerceRevenue = monthlyData.reduce((sum, m) => sum + m.ecommerceRevenue, 0);
    const totalOrders = monthlyData.reduce((sum, m) => sum + m.orders, 0);
    const totalImpressions = monthlyData.reduce((sum, m) => sum + m.impressions, 0);
    
    return {
      spend: totalSpend,
      adRevenue: totalAdRevenue,
      ecommerceRevenue: totalEcommerceRevenue,
      roas: totalSpend > 0 ? totalAdRevenue / totalSpend : 0,
      orders: totalOrders,
      cpo: totalSpend > 0 && totalOrders > 0 ? totalSpend / totalOrders : 0,
      aov: totalOrders > 0 ? totalEcommerceRevenue / totalOrders : 0,
      cpm: totalImpressions > 0 ? (totalSpend / totalImpressions) * 1000 : 0,
    };
  }, [monthlyData]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ChevronUp className="h-3 w-3 opacity-0 group-hover:opacity-30" />;
    return sortDirection === 'asc' 
      ? <ChevronUp className="h-3 w-3" />
      : <ChevronDown className="h-3 w-3" />;
  };

  if (isLoading) {
    return (
      <Card data-testid="table-monthly-metrics">
        <CardHeader>
          <CardTitle>Monthly Metrics Summary</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[360px]">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  if (monthlyData.length === 0) {
    return (
      <Card data-testid="table-monthly-metrics">
        <CardHeader>
          <CardTitle>Monthly Metrics Summary</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[360px]">
          <p className="text-muted-foreground">No historical data available. Please sync historical data first.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="table-monthly-metrics">
      <CardHeader>
        <CardTitle>Monthly Metrics Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="sticky top-0 bg-card z-10">
              <tr className="border-b">
                <th className="text-left p-3 font-semibold text-sm">
                  <button
                    className="flex items-center gap-1 cursor-pointer group w-full text-left hover:text-primary"
                    onClick={() => handleSort('month')}
                    data-testid="header-month"
                    aria-sort={sortField === 'month' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>Month</span>
                    <SortIcon field="month" />
                  </button>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <button
                    className="flex items-center justify-end gap-1 cursor-pointer group w-full hover:text-primary"
                    onClick={() => handleSort('spend')}
                    data-testid="header-spend"
                    aria-sort={sortField === 'spend' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>Ad Spend</span>
                    <SortIcon field="spend" />
                  </button>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <button
                    className="flex items-center justify-end gap-1 cursor-pointer group w-full hover:text-primary"
                    onClick={() => handleSort('adRevenue')}
                    data-testid="header-ad-revenue"
                    aria-sort={sortField === 'adRevenue' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>Ad Revenue</span>
                    <SortIcon field="adRevenue" />
                  </button>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <button
                    className="flex items-center justify-end gap-1 cursor-pointer group w-full hover:text-primary"
                    onClick={() => handleSort('ecommerceRevenue')}
                    data-testid="header-ecommerce-revenue"
                    aria-sort={sortField === 'ecommerceRevenue' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>E-commerce Revenue</span>
                    <SortIcon field="ecommerceRevenue" />
                  </button>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <button
                    className="flex items-center justify-end gap-1 cursor-pointer group w-full hover:text-primary"
                    onClick={() => handleSort('roas')}
                    data-testid="header-roas"
                    aria-sort={sortField === 'roas' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>ROAS</span>
                    <SortIcon field="roas" />
                  </button>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <span>ROAS MoM</span>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <button
                    className="flex items-center justify-end gap-1 cursor-pointer group w-full hover:text-primary"
                    onClick={() => handleSort('orders')}
                    data-testid="header-orders"
                    aria-sort={sortField === 'orders' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>Orders</span>
                    <SortIcon field="orders" />
                  </button>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <button
                    className="flex items-center justify-end gap-1 cursor-pointer group w-full hover:text-primary"
                    onClick={() => handleSort('cpo')}
                    data-testid="header-cpo"
                    aria-sort={sortField === 'cpo' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>CPO</span>
                    <SortIcon field="cpo" />
                  </button>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <span>CPO MoM</span>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <button
                    className="flex items-center justify-end gap-1 cursor-pointer group w-full hover:text-primary"
                    onClick={() => handleSort('aov')}
                    data-testid="header-aov"
                    aria-sort={sortField === 'aov' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>AOV</span>
                    <SortIcon field="aov" />
                  </button>
                </th>
                <th className="text-right p-3 font-semibold text-sm">
                  <button
                    className="flex items-center justify-end gap-1 cursor-pointer group w-full hover:text-primary"
                    onClick={() => handleSort('cpm')}
                    data-testid="header-cpm"
                    aria-sort={sortField === 'cpm' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <span>CPM</span>
                    <SortIcon field="cpm" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedData.map((row, index) => (
                <tr 
                  key={row.month} 
                  className="border-b hover-elevate"
                  data-testid={`row-month-${index}`}
                >
                  <td className="p-3 text-sm font-medium" data-testid={`cell-month-${index}`}>
                    {formatMonth(row.month)}
                  </td>
                  <td className={`p-3 text-sm text-right tabular-nums ${getColorClass(row.spend, 'spend')}`} data-testid={`cell-spend-${index}`}>
                    {formatCurrency(row.spend, baseCurrency)}
                  </td>
                  <td className={`p-3 text-sm text-right tabular-nums ${getColorClass(row.adRevenue, 'revenue')}`} data-testid={`cell-ad-revenue-${index}`}>
                    {formatCurrency(row.adRevenue, baseCurrency)}
                  </td>
                  <td className={`p-3 text-sm text-right tabular-nums ${getColorClass(row.ecommerceRevenue, 'revenue')}`} data-testid={`cell-ecommerce-revenue-${index}`}>
                    {formatCurrency(row.ecommerceRevenue, baseCurrency)}
                  </td>
                  <td className={`p-3 text-sm text-right tabular-nums ${getColorClass(row.roas, 'roas')}`} data-testid={`cell-roas-${index}`}>
                    {row.roas.toFixed(2)}x
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid={`cell-roas-mom-${index}`}>
                    {row.roasMoM !== undefined ? (
                      <span className={row.roasMoM >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                        {row.roasMoM >= 0 ? <ArrowUp className="inline h-3 w-3" /> : <ArrowDown className="inline h-3 w-3" />}
                        {Math.abs(row.roasMoM).toFixed(1)}%
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid={`cell-orders-${index}`}>
                    {row.orders.toLocaleString()}
                  </td>
                  <td className={`p-3 text-sm text-right tabular-nums ${getColorClass(row.cpo, 'cpo')}`} data-testid={`cell-cpo-${index}`}>
                    {row.cpo > 0 ? formatCurrency(row.cpo, baseCurrency) : '—'}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid={`cell-cpo-mom-${index}`}>
                    {row.cpoMoM !== undefined ? (
                      <span className={row.cpoMoM <= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                        {row.cpoMoM <= 0 ? <ArrowDown className="inline h-3 w-3" /> : <ArrowUp className="inline h-3 w-3" />}
                        {Math.abs(row.cpoMoM).toFixed(1)}%
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid={`cell-aov-${index}`}>
                    {row.aov > 0 ? formatCurrency(row.aov, baseCurrency) : '—'}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid={`cell-cpm-${index}`}>
                    {row.cpm > 0 ? formatCurrency(row.cpm, baseCurrency) : '—'}
                  </td>
                </tr>
              ))}
              {totals && (
                <tr className="border-t-2 font-semibold bg-muted/30" data-testid="row-totals">
                  <td className="p-3 text-sm" data-testid="cell-totals-label">Total</td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid="cell-totals-spend">
                    {formatCurrency(totals.spend, baseCurrency)}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid="cell-totals-ad-revenue">
                    {formatCurrency(totals.adRevenue, baseCurrency)}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid="cell-totals-ecommerce-revenue">
                    {formatCurrency(totals.ecommerceRevenue, baseCurrency)}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid="cell-totals-roas">
                    {totals.roas.toFixed(2)}x
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums">—</td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid="cell-totals-orders">
                    {totals.orders.toLocaleString()}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid="cell-totals-cpo">
                    {totals.cpo > 0 ? formatCurrency(totals.cpo, baseCurrency) : '—'}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums">—</td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid="cell-totals-aov">
                    {totals.aov > 0 ? formatCurrency(totals.aov, baseCurrency) : '—'}
                  </td>
                  <td className="p-3 text-sm text-right tabular-nums" data-testid="cell-totals-cpm">
                    {totals.cpm > 0 ? formatCurrency(totals.cpm, baseCurrency) : '—'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
