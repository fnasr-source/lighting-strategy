import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
  LabelList,
} from "recharts";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

interface MonthlyROASChartProps {
  clientId: string;
  baseCurrency: string;
}

interface MonthlyData {
  month: string;
  spend: number;
  ecommerceRevenue: number;
  roas: number;
}


// Format month for display (e.g., "2024-01" -> "Jan 2024")
function formatMonth(monthStr: string): string {
  const [year, month] = monthStr.split('-');
  const date = new Date(parseInt(year), parseInt(month) - 1);
  return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
}

// Format currency with proper symbols and E suffix for EGP
function formatCurrency(value: number, currency: string): string {
  if (!currency || currency === '') {
    currency = 'USD'; // Default fallback
  }
  
  // Format the number with 2 decimal places
  const number = value.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  
  // For EGP, use £ symbol with E suffix
  if (currency === 'EGP') {
    return `${number} £ E`;
  }
  
  // For other currencies, try to get the symbol
  try {
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
    
    // Extract just the symbol
    const parts = formatter.formatToParts(1);
    const symbol = parts.find(p => p.type === 'currency')?.value || currency;
    
    return `${number} ${symbol}`;
  } catch {
    // If currency code is invalid, just return the number
    return number;
  }
}

// Custom label for bars (above bar)
const BarLabel = (props: any) => {
  const { x, y, width, value, currency } = props;
  if (!value || value === 0) return null;
  
  const formatted = formatCurrency(value, currency);
  
  return (
    <text
      x={x + width / 2}
      y={y - 5}
      fill="hsl(var(--muted-foreground))"
      textAnchor="middle"
      fontSize={11}
      fontWeight={500}
    >
      {formatted}
    </text>
  );
};

// Custom label for line (above point)
const LineLabel = (props: any) => {
  const { x, y, value } = props;
  if (!value || value === 0) return null;
  
  return (
    <text
      x={x}
      y={y - 10}
      fill="hsl(var(--chart-3))"
      textAnchor="middle"
      fontSize={11}
      fontWeight={600}
    >
      {value.toFixed(2)}
    </text>
  );
};

// Custom tooltip component that accepts currency prop
const CustomTooltip = ({ active, payload, currency }: any) => {
  if (!active || !payload || !payload.length) return null;

  const data = payload[0].payload;

  return (
    <div
      className="rounded-md border bg-popover p-3 shadow-lg"
      style={{
        backgroundColor: "hsl(var(--popover))",
        border: "1px solid hsl(var(--border))",
      }}
    >
      <p className="font-semibold mb-2 text-sm">{formatMonth(data.month)}</p>
      <div className="space-y-1 text-xs">
        <div className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: "hsl(var(--chart-1))" }} />
            <span className="text-muted-foreground">Ad Spend:</span>
          </span>
          <span className="font-medium tabular-nums">{formatCurrency(data.spend, currency)}</span>
        </div>
        <div className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: "hsl(var(--chart-2))" }} />
            <span className="text-muted-foreground">E-commerce Revenue:</span>
          </span>
          <span className="font-medium tabular-nums">{formatCurrency(data.ecommerceRevenue, currency)}</span>
        </div>
        <div className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "hsl(var(--chart-3))" }} />
            <span className="text-muted-foreground">ROAS:</span>
          </span>
          <span className="font-medium tabular-nums">{data.roas.toFixed(2)}x</span>
        </div>
        <div className="text-[10px] text-muted-foreground/70 pt-0.5">
          (Ad Revenue ÷ Ad Spend)
        </div>
      </div>
    </div>
  );
};

export function MonthlyROASChart({ clientId, baseCurrency }: MonthlyROASChartProps) {
  // Fetch pre-aggregated monthly metrics (instant loading!)
  const { data: monthlyMetrics, isLoading } = useQuery<{
    months: Array<{
      monthEndDate: string;
      currency: string;
      ad?: {
        spend: number;
        revenue: number;
        roas: number;
      };
      ecommerce?: {
        revenue: number;
      };
    }>;
    asOf: string;
  }>({
    queryKey: [`/api/clients/${clientId}/monthly-metrics`],
    enabled: !!clientId,
  });

  if (isLoading) {
    return (
      <Card data-testid="chart-monthly-roas">
        <CardHeader>
          <CardTitle>Monthly Performance Overview</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[360px]">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  if (!monthlyMetrics?.months || monthlyMetrics.months.length === 0) {
    return (
      <Card data-testid="chart-monthly-roas">
        <CardHeader>
          <CardTitle>Monthly Performance Overview</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[360px]">
          <p className="text-muted-foreground">No historical data available. Please sync historical data first.</p>
        </CardContent>
      </Card>
    );
  }

  // Transform API response to chart format
  const monthlyData = monthlyMetrics.months.map(m => {
    const [year, month, day] = m.monthEndDate.split('-');
    const monthKey = `${year}-${month}`;
    return {
      month: monthKey,
      spend: m.ad?.spend || 0,
      ecommerceRevenue: m.ecommerce?.revenue || 0,
      roas: m.ad?.roas || 0,
    };
  });

  // Already sorted and limited to 14 months by the backend
  const last14Months = monthlyData;

  // Format months for display
  const chartData = last14Months.map(item => ({
    ...item,
    monthLabel: formatMonth(item.month), // Format like "Sep 2024"
  }));

  // Auto-scale both axes
  const maxSpendRevenue = Math.max(
    ...chartData.map(d => Math.max(d.spend, d.ecommerceRevenue)),
    0
  );
  const maxRoas = Math.max(...chartData.map(d => d.roas), 0);

  return (
    <Card data-testid="chart-monthly-roas">
      <CardHeader>
        <CardTitle>Monthly Performance Overview</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={360}>
          <ComposedChart
            data={chartData}
            margin={{ top: 30, right: 30, bottom: 10, left: 10 }}
            barGap={4}
            barCategoryGap="20%"
          >
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis
              dataKey="monthLabel"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              interval={0}
              angle={0}
              height={40}
            />
            <YAxis
              yAxisId="left"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              domain={[0, maxSpendRevenue * 1.15]}
              tickFormatter={(value) => formatCurrency(value, baseCurrency)}
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              domain={[0, maxRoas * 1.15]}
              tickFormatter={(value) => value.toFixed(2)}
            />
            <Tooltip content={(props) => <CustomTooltip {...props} currency={baseCurrency} />} />
            <Legend
              wrapperStyle={{ fontSize: 12, paddingTop: 10 }}
              iconType="rect"
              formatter={(value) => {
                if (value === "spend") return "Ad Spend";
                if (value === "ecommerceRevenue") return "E-commerce Revenue";
                if (value === "roas") return "ROAS (Ad Revenue ÷ Ad Spend)";
                return value;
              }}
            />
            
            {/* Bars for spend and ecommerce revenue */}
            <Bar
              yAxisId="left"
              dataKey="spend"
              fill="hsl(var(--chart-1))"
              name="spend"
              radius={[4, 4, 0, 0]}
              maxBarSize={30}
              barSize={30}
            >
              <LabelList content={(props) => <BarLabel {...props} currency={baseCurrency} />} position="top" />
            </Bar>
            <Bar
              yAxisId="left"
              dataKey="ecommerceRevenue"
              fill="hsl(var(--chart-2))"
              name="ecommerceRevenue"
              radius={[4, 4, 0, 0]}
              maxBarSize={30}
              barSize={30}
            >
              <LabelList content={(props) => <BarLabel {...props} currency={baseCurrency} />} position="top" />
            </Bar>
            
            {/* Line for ROAS */}
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="roas"
              stroke="hsl(var(--chart-3))"
              strokeWidth={3}
              dot={{ fill: "hsl(var(--chart-3))", r: 4 }}
              name="roas"
              label={<LineLabel />}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
