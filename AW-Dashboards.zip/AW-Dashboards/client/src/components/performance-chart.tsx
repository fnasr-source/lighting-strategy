import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useState } from "react";

interface PerformanceChartProps {
  title: string;
  data: Array<{
    date: string;
    [key: string]: string | number;
  }>;
  lines: Array<{
    dataKey: string;
    color: string;
    name: string;
    yAxisId?: string;
  }>;
}

export function PerformanceChart({ title, data, lines }: PerformanceChartProps) {
  const [visibleLines, setVisibleLines] = useState<Set<string>>(
    new Set(lines.map(l => l.dataKey))
  );

  const toggleLine = (dataKey: string) => {
    const newVisible = new Set(visibleLines);
    if (newVisible.has(dataKey)) {
      newVisible.delete(dataKey);
    } else {
      newVisible.add(dataKey);
    }
    setVisibleLines(newVisible);
  };

  const hasLeftAxis = lines.some(l => !l.yAxisId || l.yAxisId === 'left');
  const hasRightAxis = lines.some(l => l.yAxisId === 'right');

  return (
    <Card data-testid={`chart-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
        <CardTitle>{title}</CardTitle>
        <div className="flex flex-wrap gap-2">
          {lines.map((line) => (
            <Badge
              key={line.dataKey}
              variant={visibleLines.has(line.dataKey) ? "default" : "outline"}
              className="cursor-pointer hover-elevate active-elevate-2"
              style={{
                backgroundColor: visibleLines.has(line.dataKey) ? line.color : 'transparent',
                borderColor: line.color,
                color: visibleLines.has(line.dataKey) ? 'hsl(var(--primary-foreground))' : line.color,
              }}
              onClick={() => toggleLine(line.dataKey)}
              data-testid={`toggle-${line.dataKey}`}
            >
              {line.name}
            </Badge>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis
              dataKey="date"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            {hasLeftAxis && (
              <YAxis
                yAxisId="left"
                className="text-xs"
                tick={{ fill: "hsl(var(--muted-foreground))" }}
              />
            )}
            {hasRightAxis && (
              <YAxis
                yAxisId="right"
                orientation="right"
                className="text-xs"
                tick={{ fill: "hsl(var(--muted-foreground))" }}
              />
            )}
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "0.375rem",
              }}
            />
            {lines.filter(line => visibleLines.has(line.dataKey)).map((line) => (
              <Line
                key={line.dataKey}
                type="monotone"
                dataKey={line.dataKey}
                stroke={line.color}
                name={line.name}
                strokeWidth={2}
                dot={false}
                yAxisId={line.yAxisId || 'left'}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
