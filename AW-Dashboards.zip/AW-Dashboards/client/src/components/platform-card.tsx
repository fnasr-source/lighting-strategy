import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";
import { Settings } from "lucide-react";

interface PlatformCardProps {
  name: string;
  icon: LucideIcon;
  isConnected: boolean;
  lastSync?: string;
  onConnect: () => void;
  onConfigure: () => void;
}

export function PlatformCard({
  name,
  icon: Icon,
  isConnected,
  lastSync,
  onConnect,
  onConfigure,
}: PlatformCardProps) {
  return (
    <Card data-testid={`card-platform-${name.toLowerCase()}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-muted flex items-center justify-center">
            <Icon className="h-5 w-5 text-foreground" />
          </div>
          <h3 className="font-semibold">{name}</h3>
        </div>
        <Badge variant={isConnected ? "default" : "secondary"} data-testid={`badge-status-${name.toLowerCase()}`}>
          {isConnected ? "Connected" : "Disconnected"}
        </Badge>
      </CardHeader>
      <CardContent>
        {isConnected && lastSync && (
          <p className="text-sm text-muted-foreground">
            Last sync: {lastSync}
          </p>
        )}
        {!isConnected && (
          <p className="text-sm text-muted-foreground">
            Connect your {name} account to start tracking metrics
          </p>
        )}
      </CardContent>
      <CardFooter className="flex gap-2">
        {isConnected ? (
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={onConfigure}
            data-testid={`button-configure-${name.toLowerCase()}`}
          >
            <Settings className="h-4 w-4 mr-2" />
            Configure
          </Button>
        ) : (
          <Button
            size="sm"
            className="w-full"
            onClick={onConnect}
            data-testid={`button-connect-${name.toLowerCase()}`}
          >
            Connect
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
