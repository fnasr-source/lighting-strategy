import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface PlatformData {
  platform: string;
  impressions: number;
  clicks: number;
  ctr: number;
  conversions: number;
  spend: number;
  revenue: number;
  roas: number;
  currency?: string;
  originalCurrency?: string;
}

interface PlatformTableProps {
  data: PlatformData[];
  baseCurrency?: string;
}

type SortField = 'platform' | 'impressions' | 'clicks' | 'ctr' | 'conversions' | 'spend' | 'revenue' | 'roas' | 'cac' | 'aov' | 'mer';
type SortDirection = 'asc' | 'desc' | null;

export function PlatformTable({ data, baseCurrency = "USD" }: PlatformTableProps) {
  const [sortField, setSortField] = useState<SortField | null>(null);
  const [sortDirection, setSortDirection] = useState<SortDirection>(null);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toLocaleString();
  };

  const formatCurrency = (num: number, currency: string = baseCurrency) => {
    const symbols: { [key: string]: string } = {
      USD: "$",
      EUR: "€",
      GBP: "£",
      CAD: "C$",
      AUD: "A$",
      JPY: "¥",
      CNY: "¥",
      INR: "₹",
      BRL: "R$",
      MXN: "$",
      EGP: "E£",
      AED: "د.إ",
      SAR: "﷼",
    };
    const symbol = symbols[currency] || currency;
    return `${symbol}${num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      if (sortDirection === 'asc') setSortDirection('desc');
      else if (sortDirection === 'desc') {
        setSortField(null);
        setSortDirection(null);
      } else setSortDirection('asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="ml-2 h-3 w-3" />;
    if (sortDirection === 'asc') return <ArrowUp className="ml-2 h-3 w-3" />;
    return <ArrowDown className="ml-2 h-3 w-3" />;
  };

  // Calculate additional metrics and sort
  const enrichedData = data.map(row => ({
    ...row,
    cac: row.conversions > 0 ? row.spend / row.conversions : 0,
    aov: row.conversions > 0 ? row.revenue / row.conversions : 0,
    mer: row.spend > 0 ? row.revenue / row.spend : 0,
  }));

  const sortedData = sortField && sortDirection
    ? [...enrichedData].sort((a, b) => {
        let aVal = a[sortField];
        let bVal = b[sortField];
        if (sortField === 'platform') {
          aVal = aVal.toString().toLowerCase();
          bVal = bVal.toString().toLowerCase();
        }
        if (sortDirection === 'asc') return aVal > bVal ? 1 : -1;
        return aVal < bVal ? 1 : -1;
      })
    : enrichedData;

  return (
    <Card data-testid="table-platform-performance">
      <CardHeader>
        <CardTitle>Platform Performance (All values in {baseCurrency})</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8 -ml-3"
                    onClick={() => handleSort('platform')}
                    data-testid="sort-platform"
                  >
                    Platform
                    {getSortIcon('platform')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('impressions')}
                    data-testid="sort-impressions"
                  >
                    Impressions
                    {getSortIcon('impressions')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('clicks')}
                    data-testid="sort-clicks"
                  >
                    Clicks
                    {getSortIcon('clicks')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('ctr')}
                    data-testid="sort-ctr"
                  >
                    CTR
                    {getSortIcon('ctr')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('spend')}
                    data-testid="sort-spend"
                  >
                    Spend
                    {getSortIcon('spend')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('revenue')}
                    data-testid="sort-revenue"
                  >
                    Revenue
                    {getSortIcon('revenue')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('conversions')}
                    data-testid="sort-conversions"
                  >
                    Purchases
                    {getSortIcon('conversions')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('cac')}
                    data-testid="sort-cac"
                  >
                    CAC
                    {getSortIcon('cac')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('aov')}
                    data-testid="sort-aov"
                  >
                    AOV
                    {getSortIcon('aov')}
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8"
                    onClick={() => handleSort('roas')}
                    data-testid="sort-roas"
                  >
                    ROAS
                    {getSortIcon('roas')}
                  </Button>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedData.map((row, index) => (
                <TableRow key={index} data-testid={`row-platform-${index}`}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{row.platform}</Badge>
                      {row.originalCurrency && row.originalCurrency !== baseCurrency && (
                        <Badge variant="secondary" className="text-xs">
                          {row.originalCurrency} → {baseCurrency}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {formatNumber(row.impressions)}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {formatNumber(row.clicks)}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {row.ctr.toFixed(2)}%
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {formatCurrency(row.spend, row.currency || baseCurrency)}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {formatCurrency(row.revenue, row.currency || baseCurrency)}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {row.conversions}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {row.cac > 0 ? formatCurrency(row.cac, row.currency || baseCurrency) : '-'}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm">
                    {row.aov > 0 ? formatCurrency(row.aov, row.currency || baseCurrency) : '-'}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm font-semibold">
                    {row.roas.toFixed(2)}x
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
