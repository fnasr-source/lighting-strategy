import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { TrendingUp, MousePointer, ShoppingCart, DollarSign, FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface TopAd {
  id: string;
  name: string;
  creative: {
    type: 'image' | 'video' | 'carousel';
    thumbnail_url?: string;
    image_url?: string;
    video_url?: string;
  };
  adCopy: {
    headline?: string;
    primaryText?: string;
    description?: string;
  };
  metrics: {
    impressions: number;
    clicks: number;
    conversions: number;
    spend: number;
    ctr: number;
    cpc: number;
    roas: number;
  };
}

interface TopAdsResponse {
  ads: TopAd[];
  baseCurrency: string;
}

interface TopAdCopiesProps {
  clientId: string;
  timeframe: number;
  limit?: number;
}

export function TopAdCopies({ clientId, timeframe, limit = 5 }: TopAdCopiesProps) {
  const { data, isLoading } = useQuery<TopAdsResponse>({
    queryKey: ['/api/metrics/top-ads', { clientId, timeframe, limit }],
    queryFn: async () => {
      const res = await fetch(`/api/metrics/top-ads?clientId=${clientId}&timeframe=${timeframe}&limit=${limit}`, {
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Failed to fetch top ads');
      return res.json();
    },
    enabled: !!clientId,
    staleTime: Infinity,
  });
  
  const topAds = data?.ads || [];
  const baseCurrency = data?.baseCurrency || 'USD';

  const formatCurrency = (num: number, currency?: string) => {
    const curr = currency || baseCurrency;
    const symbols: { [key: string]: string } = {
      USD: "$",
      EUR: "€",
      GBP: "£",
      CAD: "C$",
      AUD: "A$",
      JPY: "¥",
      CNY: "¥",
      INR: "₹",
      BRL: "R$",
      MXN: "$",
      EGP: "E£",
      AED: "د.إ",
      SAR: "﷼",
    };
    const symbol = symbols[curr] || curr;
    return `${symbol}${formatNumber(num)}`;
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toLocaleString();
  };

  if (isLoading) {
    return (
      <Card data-testid="card-top-ad-copies">
        <CardHeader>
          <CardTitle className="text-xl">Top Performing Ad Copies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!topAds || topAds.length === 0) {
    return (
      <Card data-testid="card-top-ad-copies">
        <CardHeader>
          <CardTitle className="text-xl">Top Performing Ad Copies</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No ad copy data available for the selected period.</p>
        </CardContent>
      </Card>
    );
  }

  const adsWithCopy = topAds.filter(ad => ad.adCopy.headline || ad.adCopy.primaryText);
  
  if (adsWithCopy.length === 0) {
    return (
      <Card data-testid="card-top-ad-copies">
        <CardHeader>
          <CardTitle className="text-xl">Top Performing Ad Copies</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No ad copy text found for the selected period. Ads may not have headline or description text.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="card-top-ad-copies">
      <CardHeader>
        <CardTitle className="text-xl">Top Performing Ad Copies</CardTitle>
        <p className="text-sm text-muted-foreground">
          Best performing ad text ranked by ROAS
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {adsWithCopy.map((ad, index) => (
            <div
              key={ad.id}
              className="group rounded-md border bg-card p-4 hover-elevate active-elevate-2 transition-all"
              data-testid={`ad-copy-item-${index}`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 space-y-2">
                    {ad.adCopy.headline && (
                      <div data-testid={`ad-copy-headline-${index}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <FileText className="h-3 w-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground uppercase tracking-wide">Headline</span>
                        </div>
                        <h4 className="text-base font-semibold leading-tight">
                          {ad.adCopy.headline}
                        </h4>
                      </div>
                    )}

                    {ad.adCopy.primaryText && (
                      <div data-testid={`ad-copy-primary-${index}`}>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {ad.adCopy.primaryText}
                        </p>
                      </div>
                    )}
                  </div>

                  {index < 3 && (
                    <Badge 
                      variant="secondary" 
                      className="bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/20 text-xs shrink-0"
                      data-testid={`ad-copy-rank-${index}`}
                    >
                      #{index + 1}
                    </Badge>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-3 border-t text-sm">
                  <div data-testid={`ad-copy-impressions-${index}`}>
                    <div className="flex items-center gap-1 text-muted-foreground mb-1">
                      <TrendingUp className="h-3 w-3" />
                      <span className="text-xs">Impressions</span>
                    </div>
                    <p className="font-mono font-medium">{formatNumber(ad.metrics.impressions)}</p>
                  </div>

                  <div data-testid={`ad-copy-clicks-${index}`}>
                    <div className="flex items-center gap-1 text-muted-foreground mb-1">
                      <MousePointer className="h-3 w-3" />
                      <span className="text-xs">Clicks</span>
                    </div>
                    <p className="font-mono font-medium">{formatNumber(ad.metrics.clicks)}</p>
                  </div>

                  <div data-testid={`ad-copy-conversions-${index}`}>
                    <div className="flex items-center gap-1 text-muted-foreground mb-1">
                      <ShoppingCart className="h-3 w-3" />
                      <span className="text-xs">Conversions</span>
                    </div>
                    <p className="font-mono font-medium">{ad.metrics.conversions}</p>
                  </div>

                  <div data-testid={`ad-copy-spend-${index}`}>
                    <div className="flex items-center gap-1 text-muted-foreground mb-1">
                      <DollarSign className="h-3 w-3" />
                      <span className="text-xs">Spend</span>
                    </div>
                    <p className="font-mono font-medium">{formatCurrency(ad.metrics.spend)}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 pt-3 border-t">
                  <div data-testid={`ad-copy-ctr-${index}`}>
                    <p className="text-xs text-muted-foreground mb-1">CTR</p>
                    <p className="text-lg font-mono font-semibold">{ad.metrics.ctr}%</p>
                  </div>
                  <div data-testid={`ad-copy-roas-${index}`}>
                    <p className="text-xs text-muted-foreground mb-1">ROAS</p>
                    <p className="text-lg font-mono font-semibold text-primary">{ad.metrics.roas}x</p>
                  </div>
                  <div data-testid={`ad-copy-cpc-${index}`}>
                    <p className="text-xs text-muted-foreground mb-1">CPC</p>
                    <p className="text-lg font-mono font-semibold">{formatCurrency(ad.metrics.cpc)}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
