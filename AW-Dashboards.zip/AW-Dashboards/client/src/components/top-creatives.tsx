import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Image, Video, Layers, TrendingUp, MousePointer, ShoppingCart, DollarSign } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface TopAd {
  id: string;
  name: string;
  creative: {
    type: 'image' | 'video' | 'carousel';
    thumbnail_url?: string;
    image_url?: string;
    video_url?: string;
  };
  adCopy: {
    headline?: string;
    primaryText?: string;
    description?: string;
  };
  metrics: {
    impressions: number;
    clicks: number;
    conversions: number;
    spend: number;
    ctr: number;
    cpc: number;
    roas: number;
  };
}

interface TopAdsResponse {
  ads: TopAd[];
  baseCurrency: string;
}

interface TopCreativesProps {
  clientId: string;
  timeframe: number;
  limit?: number;
}

export function TopCreatives({ clientId, timeframe, limit = 6 }: TopCreativesProps) {
  const { data, isLoading } = useQuery<TopAdsResponse>({
    queryKey: ['/api/metrics/top-ads', { clientId, timeframe, limit }],
    queryFn: async () => {
      const res = await fetch(`/api/metrics/top-ads?clientId=${clientId}&timeframe=${timeframe}&limit=${limit}`, {
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Failed to fetch top ads');
      return res.json();
    },
    enabled: !!clientId,
    staleTime: Infinity,
  });
  
  const topAds = data?.ads || [];
  const baseCurrency = data?.baseCurrency || 'USD';

  const formatCurrency = (num: number, currency?: string) => {
    const curr = currency || baseCurrency;
    const symbols: { [key: string]: string } = {
      USD: "$",
      EUR: "€",
      GBP: "£",
      CAD: "C$",
      AUD: "A$",
      JPY: "¥",
      CNY: "¥",
      INR: "₹",
      BRL: "R$",
      MXN: "$",
      EGP: "E£",
      AED: "د.إ",
      SAR: "﷼",
    };
    const symbol = symbols[curr] || curr;
    return `${symbol}${formatNumber(num)}`;
  };

  const getCreativeIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="h-4 w-4" />;
      case 'carousel':
        return <Layers className="h-4 w-4" />;
      default:
        return <Image className="h-4 w-4" />;
    }
  };

  const getCreativeTypeColor = (type: string) => {
    switch (type) {
      case 'video':
        return 'bg-purple-500/90 text-white dark:text-white border-purple-500/20';
      case 'carousel':
        return 'bg-blue-500/90 text-white dark:text-white border-blue-500/20';
      default:
        return 'bg-green-500/90 text-white dark:text-white border-green-500/20';
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toLocaleString();
  };

  if (isLoading) {
    return (
      <Card data-testid="card-top-creatives">
        <CardHeader>
          <CardTitle className="text-xl">Top Performing Creatives</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="h-48 w-full rounded-md" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!topAds || topAds.length === 0) {
    return (
      <Card data-testid="card-top-creatives">
        <CardHeader>
          <CardTitle className="text-xl">Top Performing Creatives</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No ad data available for the selected period.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="card-top-creatives">
      <CardHeader>
        <CardTitle className="text-xl">Top Performing Creatives</CardTitle>
        <p className="text-sm text-muted-foreground">
          Best performing ad creatives ranked by ROAS
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {topAds.map((ad, index) => (
            <div
              key={ad.id}
              className="group relative overflow-hidden rounded-md border bg-card hover-elevate active-elevate-2 transition-all"
              data-testid={`creative-item-${index}`}
            >
              <div className="relative aspect-square bg-muted">
                {ad.creative.image_url || ad.creative.thumbnail_url ? (
                  <img
                    src={ad.creative.image_url || ad.creative.thumbnail_url}
                    alt={ad.name}
                    className="h-full w-full object-cover"
                    loading="lazy"
                    data-testid={`creative-image-${index}`}
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      if (target.src === ad.creative.image_url && ad.creative.thumbnail_url) {
                        target.src = ad.creative.thumbnail_url;
                      }
                    }}
                  />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    {getCreativeIcon(ad.creative.type)}
                  </div>
                )}
                
                <div className="absolute top-2 left-2 flex gap-2">
                  <Badge 
                    variant="secondary" 
                    className={`${getCreativeTypeColor(ad.creative.type)} text-xs backdrop-blur-sm bg-opacity-90 dark:bg-opacity-90 shadow-sm`}
                    data-testid={`creative-type-${index}`}
                  >
                    {getCreativeIcon(ad.creative.type)}
                    <span className="ml-1 capitalize">{ad.creative.type}</span>
                  </Badge>
                  {index < 3 && (
                    <Badge 
                      variant="secondary" 
                      className="bg-amber-500/90 text-white dark:text-white border-amber-500/20 text-xs backdrop-blur-sm shadow-sm font-semibold"
                      data-testid={`creative-rank-${index}`}
                    >
                      #{index + 1}
                    </Badge>
                  )}
                </div>
              </div>

              <div className="p-3 space-y-2">
                <h4 className="text-sm font-medium truncate" data-testid={`creative-name-${index}`}>
                  {ad.name}
                </h4>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-1 text-muted-foreground" data-testid={`creative-impressions-${index}`}>
                    <TrendingUp className="h-3 w-3" />
                    <span className="font-mono">{formatNumber(ad.metrics.impressions)}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground" data-testid={`creative-clicks-${index}`}>
                    <MousePointer className="h-3 w-3" />
                    <span className="font-mono">{formatNumber(ad.metrics.clicks)}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground" data-testid={`creative-conversions-${index}`}>
                    <ShoppingCart className="h-3 w-3" />
                    <span className="font-mono">{ad.metrics.conversions}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground" data-testid={`creative-spend-${index}`}>
                    <DollarSign className="h-3 w-3" />
                    <span className="font-mono">{formatCurrency(ad.metrics.spend)}</span>
                  </div>
                </div>

                <div className="flex gap-2 pt-2 border-t">
                  <div className="flex-1" data-testid={`creative-ctr-${index}`}>
                    <p className="text-xs text-muted-foreground">CTR</p>
                    <p className="text-sm font-mono font-medium">{ad.metrics.ctr}%</p>
                  </div>
                  <div className="flex-1" data-testid={`creative-roas-${index}`}>
                    <p className="text-xs text-muted-foreground">ROAS</p>
                    <p className="text-sm font-mono font-medium">{ad.metrics.roas}x</p>
                  </div>
                  <div className="flex-1" data-testid={`creative-cpc-${index}`}>
                    <p className="text-xs text-muted-foreground">CPC</p>
                    <p className="text-sm font-mono font-medium">{formatCurrency(ad.metrics.cpc)}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
