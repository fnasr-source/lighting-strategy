// Reference: blueprint:javascript_auth_all_persistance
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";
import { Redirect } from "wouter";
import { Loader2 } from "lucide-react";
import admireworksLogo from "@assets/AW icon_1762197633878.jpg";
import { useQuery } from "@tanstack/react-query";

export default function AuthPage() {
  const { user, isLoading, loginMutation } = useAuth();
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  // Check if any users exist in the system
  const { data: systemStatus, isLoading: checkingSystem } = useQuery<{ hasUsers: boolean }>({
    queryKey: ["/api/system/has-users"],
  });

  // Redirect to home if already logged in (after hooks)
  if (user) {
    return <Redirect to="/" />;
  }

  // Redirect to first-time setup if no users exist
  if (!checkingSystem && systemStatus && !systemStatus.hasUsers) {
    return <Redirect to="/setup" />;
  }

  if (isLoading || checkingSystem) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({
      username: loginUsername,
      password: loginPassword,
    });
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left side - Auth form */}
      <div className="flex items-center justify-center p-8">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center space-y-2">
            <img 
              src={admireworksLogo} 
              alt="Admireworks" 
              className="h-16 w-16 mx-auto object-contain rounded-md"
            />
            <h1 className="text-3xl font-bold">Welcome to Admireworks</h1>
            <p className="text-muted-foreground">Sign in to access your analytics dashboard</p>
          </div>

          <Card className="w-full">
            <CardHeader>
              <CardTitle>Login</CardTitle>
              <CardDescription>Enter your credentials to access your account</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username">Username</Label>
                  <Input
                    id="login-username"
                    type="text"
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    required
                    data-testid="input-login-username"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">Password</Label>
                  <Input
                    id="login-password"
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    required
                    data-testid="input-login-password"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full"
                  disabled={loginMutation.isPending}
                  data-testid="button-login-submit"
                >
                  {loginMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Logging in...
                    </>
                  ) : (
                    "Login"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Right side - Hero/Marketing content */}
      <div className="hidden lg:flex items-center justify-center bg-primary p-8">
        <div className="max-w-lg text-primary-foreground space-y-6">
          <h2 className="text-4xl font-bold">Unified Marketing Analytics</h2>
          <p className="text-lg text-primary-foreground/90">
            Track your campaigns across Meta Ads, Google Ads, TikTok, Snapchat, and e-commerce platforms all in one place.
          </p>
          <ul className="space-y-3 text-primary-foreground/90">
            <li className="flex items-start gap-2">
              <span className="mt-1">✓</span>
              <span>Multi-platform integration with real-time data syncing</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-1">✓</span>
              <span>Advanced analytics and performance metrics</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-1">✓</span>
              <span>Client management and shareable dashboards</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-1">✓</span>
              <span>Multi-currency support for global campaigns</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
