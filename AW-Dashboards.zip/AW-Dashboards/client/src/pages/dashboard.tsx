import { MetricCard } from "@/components/metric-card";
import { PerformanceChart } from "@/components/performance-chart";
import { PlatformTable } from "@/components/platform-table";
import { TopCreatives } from "@/components/top-creatives";
import { TopAdCopies } from "@/components/top-ad-copies";
import { MonthlyROASChart } from "@/components/monthly-roas-chart";
import { MonthlyMetricsTable } from "@/components/monthly-metrics-table";
import { 
  Eye, 
  MousePointerClick, 
  DollarSign, 
  TrendingUp, 
  CreditCard, 
  ShoppingCart, 
  Users, 
  Repeat, 
  Link2, 
  BarChart3, 
  Percent, 
  Package,
  ShoppingBag
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Client } from "@shared/schema";

interface TrendPoint {
  date: string;
  value: number;
}

interface MetricData {
  value: number;
  change: number;
  trend: TrendPoint[];
  platforms: string[];
  hasSessionData?: boolean; // Optional flag for conversion rate
}

interface DashboardMetrics {
  // Core metrics
  impressions: MetricData;
  clicks: MetricData;
  spend: MetricData;
  roas: MetricData;
  ctr: MetricData;
  
  // Split revenue
  adRevenue: MetricData;
  ecommerceRevenue: MetricData;
  
  // Split purchases
  adConversions: MetricData;
  ecommerceOrders: MetricData;
  
  // Ad platform specific metrics
  reach: MetricData;
  frequency: MetricData;
  linkClicks: MetricData;
  cpm: MetricData;
  costPerOrder: MetricData;
  linkCtr: MetricData;
  costPerLinkClick: MetricData;
  
  // E-commerce specific metrics
  conversionRate: MetricData;
  avgOrderValue: MetricData;
  
  chartData: Array<{
    isoDate: string; // ISO date for filtering
    date: string;
    impressions: number;
    clicks: number;
    revenue: number;
    spend?: number;
    roas?: number;
  }>;
  platformData: Array<{
    platform: string;
    impressions: number;
    clicks: number;
    ctr: number;
    conversions: number;
    spend: number;
    revenue: number;
    roas: number;
    currency: string;
    originalCurrency?: string;
  }>;
  baseCurrency: string;
  dataAvailability?: {
    metaLastBreakdownDate: string | null;
    totalDaysRequested: number;
    dailyDataCount: number;
  };
}

export default function Dashboard() {
  const [selectedClientId, setSelectedClientId] = useState<string>("");
  const [timeframe, setTimeframe] = useState("30");
  const [activeTab, setActiveTab] = useState("overview");
  const [visitedTabs, setVisitedTabs] = useState<Set<string>>(new Set(["overview"]));

  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  // Auto-select first client if none selected
  useEffect(() => {
    if (clients.length > 0 && !selectedClientId) {
      setSelectedClientId(clients[0].id);
    }
  }, [clients, selectedClientId]);

  useEffect(() => {
    if (!visitedTabs.has(activeTab)) {
      setVisitedTabs(prev => new Set([...Array.from(prev), activeTab]));
    }
  }, [activeTab, visitedTabs]);

  const { data: metrics, isLoading } = useQuery<DashboardMetrics>({
    queryKey: [`/api/metrics/dashboard?clientId=${selectedClientId}&timeframe=${timeframe}`],
    enabled: !!selectedClientId,
  });

  const selectedClient = clients.find(c => c.id === selectedClientId);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const formatCurrency = (num: number, currency?: string) => {
    const curr = currency || metrics?.baseCurrency || "USD";
    const symbols: { [key: string]: string } = {
      USD: "$",
      EUR: "€",
      GBP: "£",
      CAD: "C$",
      AUD: "A$",
      JPY: "¥",
      CNY: "¥",
      INR: "₹",
      BRL: "R$",
      MXN: "$",
      EGP: "E£",
      AED: "د.إ",
      SAR: "﷼",
    };
    const symbol = symbols[curr] || curr;
    return `${symbol}${num.toLocaleString()}`;
  };

  // Check if all required metrics are loaded
  const hasAllMetrics = metrics && metrics.impressions && metrics.adConversions && 
    metrics.reach && metrics.linkClicks && metrics.cpm &&
    metrics.adRevenue && metrics.ecommerceRevenue;

  if (isLoading || !metrics || !hasAllMetrics) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Overview of all platform performance
            </p>
          </div>
        </div>
        <div className="text-center py-12">
          <p className="text-muted-foreground">Loading dashboard metrics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-full overflow-x-hidden">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            {selectedClient ? `${selectedClient.name} - Performance Overview` : "Select a client to view metrics"}
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Select value={selectedClientId} onValueChange={setSelectedClientId}>
            <SelectTrigger className="w-full sm:w-[200px]" data-testid="select-client">
              <SelectValue placeholder="Select client" />
            </SelectTrigger>
            <SelectContent>
              {clients.map((client) => (
                <SelectItem key={client.id} value={client.id}>
                  {client.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-full sm:w-[150px]" data-testid="select-timeframe">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">Today</SelectItem>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="14">Last 14 days</SelectItem>
              <SelectItem value="28">Last 28 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="mtd">Month to Date</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6" data-testid="dashboard-tabs">
        <TabsList data-testid="tabs-list">
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="monthly-review" data-testid="tab-monthly-review">Monthly Review</TabsTrigger>
          <TabsTrigger value="creatives" data-testid="tab-creatives">Top Creatives</TabsTrigger>
          <TabsTrigger value="ad-copies" data-testid="tab-ad-copies">Top Ad Copies</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6" data-testid="tab-content-overview">
          <div className="text-sm text-muted-foreground">
            All values in {metrics.baseCurrency}
          </div>

          {/* Core Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <MetricCard
              title="Impressions"
              value={formatNumber(metrics.impressions.value)}
              change={metrics.impressions.change}
              icon={Eye}
              trend={metrics.impressions.trend}
              platforms={metrics.impressions.platforms}
              tooltip="Total number of times your ads were displayed across all platforms. Calculated by summing impressions from all connected advertising platforms."
            />
            <MetricCard
              title="Clicks"
              value={formatNumber(metrics.clicks.value)}
              change={metrics.clicks.change}
              icon={MousePointerClick}
              trend={metrics.clicks.trend}
              platforms={metrics.clicks.platforms}
              tooltip="Total number of clicks on your ads. This includes all clicks across Meta Ads, Google Ads, TikTok, Snapchat, and other connected platforms."
            />
            <MetricCard
              title={`Spend (${metrics.baseCurrency})`}
              value={formatCurrency(metrics.spend.value, metrics.baseCurrency)}
              change={metrics.spend.change}
              icon={CreditCard}
              trend={metrics.spend.trend}
              platforms={metrics.spend.platforms}
              tooltip={`Total advertising spend across all platforms, converted to ${metrics.baseCurrency}. This represents your total marketing investment for the selected period.`}
            />
            <MetricCard
              title="ROAS"
              value={`${metrics.roas.value.toFixed(1)}x`}
              change={metrics.roas.change}
              icon={TrendingUp}
              trend={metrics.roas.trend}
              platforms={metrics.roas.platforms}
              tooltip="Return on Ad Spend (ROAS). Calculated as Ad Revenue ÷ Ad Spend. A ROAS of 2.0x means you earn $2 for every $1 spent on advertising."
            />
            <MetricCard
              title="CTR"
              value={`${metrics.ctr.value}%`}
              change={metrics.ctr.change}
              icon={Percent}
              trend={metrics.ctr.trend}
              platforms={metrics.ctr.platforms}
              tooltip="Click-Through Rate. Percentage of impressions that resulted in clicks."
            />
          </div>

          {/* Revenue Metrics - Split by source */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <MetricCard
              title={`Ad Revenue (${metrics.baseCurrency})`}
              value={formatCurrency(metrics.adRevenue.value, metrics.baseCurrency)}
              change={metrics.adRevenue.change}
              icon={DollarSign}
              trend={metrics.adRevenue.trend}
              platforms={metrics.adRevenue.platforms}
              tooltip={`Revenue generated from advertising platforms, converted to ${metrics.baseCurrency}. This represents revenue attributed to your ad campaigns.`}
            />
            <MetricCard
              title={`E-commerce Revenue (${metrics.baseCurrency})`}
              value={formatCurrency(metrics.ecommerceRevenue.value, metrics.baseCurrency)}
              change={metrics.ecommerceRevenue.change}
              icon={ShoppingBag}
              trend={metrics.ecommerceRevenue.trend}
              platforms={metrics.ecommerceRevenue.platforms}
              tooltip={`Total revenue from e-commerce platforms (Shopify, WooCommerce), converted to ${metrics.baseCurrency}. This includes all sales, whether from ads or direct traffic.`}
            />
          </div>

          {/* Purchase Metrics - Split by source */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <MetricCard
              title="Ad Conversions"
              value={formatNumber(metrics.adConversions.value)}
              change={metrics.adConversions.change}
              icon={ShoppingCart}
              trend={metrics.adConversions.trend}
              platforms={metrics.adConversions.platforms}
              tooltip="Number of purchases attributed to your advertising campaigns across Meta Ads, Google Ads, TikTok, and Snapchat."
            />
            <MetricCard
              title="E-commerce Orders"
              value={formatNumber(metrics.ecommerceOrders.value)}
              change={metrics.ecommerceOrders.change}
              icon={Package}
              trend={metrics.ecommerceOrders.trend}
              platforms={metrics.ecommerceOrders.platforms}
              tooltip="Total orders from your e-commerce platforms (Shopify, WooCommerce). This includes all sales, whether from ads or direct traffic."
            />
          </div>

          {/* Ad Platform Metrics */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Ad Platform Metrics</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <MetricCard
                title="Reach"
                value={formatNumber(metrics.reach.value)}
                change={metrics.reach.change}
                icon={Users}
                trend={metrics.reach.trend}
                platforms={metrics.reach.platforms}
                tooltip="Number of unique users who saw your ads."
              />
              <MetricCard
                title="Frequency"
                value={metrics.frequency.value.toFixed(2)}
                change={metrics.frequency.change}
                icon={Repeat}
                trend={metrics.frequency.trend}
                platforms={metrics.frequency.platforms}
                tooltip="Average number of times each user saw your ads. Calculated as Impressions ÷ Reach."
              />
              <MetricCard
                title="Link Clicks"
                value={formatNumber(metrics.linkClicks.value)}
                change={metrics.linkClicks.change}
                icon={Link2}
                trend={metrics.linkClicks.trend}
                platforms={metrics.linkClicks.platforms}
                tooltip="Number of clicks on links within your ads that led users to destinations on or off the platform."
              />
              <MetricCard
                title={`CPM (${metrics.baseCurrency})`}
                value={formatCurrency(metrics.cpm.value, metrics.baseCurrency)}
                change={metrics.cpm.change}
                icon={BarChart3}
                trend={metrics.cpm.trend}
                platforms={metrics.cpm.platforms}
                tooltip="Cost Per Mille (thousand impressions). Average cost to reach 1,000 people with your ads."
              />
              <MetricCard
                title={`Cost Per Order (${metrics.baseCurrency})`}
                value={formatCurrency(metrics.costPerOrder.value, metrics.baseCurrency)}
                change={metrics.costPerOrder.change}
                icon={CreditCard}
                trend={metrics.costPerOrder.trend}
                platforms={metrics.costPerOrder.platforms}
                tooltip="Average advertising cost per conversion. Calculated as Spend ÷ Ad Conversions."
              />
              <MetricCard
                title="Link CTR"
                value={`${metrics.linkCtr.value}%`}
                change={metrics.linkCtr.change}
                icon={Percent}
                trend={metrics.linkCtr.trend}
                platforms={metrics.linkCtr.platforms}
                tooltip="Link Click-Through Rate. Percentage of impressions that resulted in link clicks."
              />
              <MetricCard
                title={`Cost Per Link Click (${metrics.baseCurrency})`}
                value={formatCurrency(metrics.costPerLinkClick.value, metrics.baseCurrency)}
                change={metrics.costPerLinkClick.change}
                icon={DollarSign}
                trend={metrics.costPerLinkClick.trend}
                platforms={metrics.costPerLinkClick.platforms}
                tooltip="Average cost for each link click. Calculated as Spend ÷ Link Clicks."
              />
            </div>
          </div>

          {/* E-commerce Metrics */}
          <div>
            <h3 className="text-lg font-semibold mb-4">E-commerce Metrics</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Show Conversion Rate only if session data is available */}
              {metrics.conversionRate.hasSessionData && (
                <MetricCard
                  title="Conversion Rate"
                  value={`${metrics.conversionRate.value}%`}
                  change={metrics.conversionRate.change}
                  icon={Percent}
                  trend={metrics.conversionRate.trend}
                  platforms={metrics.conversionRate.platforms}
                  tooltip="Percentage of store visitors who complete a purchase. Calculated as (E-commerce Orders ÷ Sessions) × 100. Uses session data from Shopify/WooCommerce."
                />
              )}
              <MetricCard
                title={`Average Order Value (${metrics.baseCurrency})`}
                value={formatCurrency(metrics.avgOrderValue.value, metrics.baseCurrency)}
                change={metrics.avgOrderValue.change}
                icon={DollarSign}
                trend={metrics.avgOrderValue.trend}
                platforms={metrics.avgOrderValue.platforms}
                tooltip="Average revenue per order from your e-commerce platforms. Calculated as E-commerce Revenue ÷ E-commerce Orders. Uses Shopify's total_price which includes all discounts and adjustments."
              />
            </div>
            {/* Show note when session data is not available */}
            {!metrics.conversionRate.hasSessionData && metrics.conversionRate.platforms.length > 0 && (
              <div className="text-sm text-muted-foreground mt-4 p-3 bg-muted/50 rounded-md">
                <span className="font-medium">Note:</span> Conversion Rate is currently unavailable. This metric requires session data from Shopify Analytics API (ShopifyQL), which may not be accessible on all Shopify plans. If your store has access to Shopify Analytics, the conversion rate will appear automatically once session data becomes available.
              </div>
            )}
          </div>

          {/* Performance Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            <PerformanceChart
              title="Traffic Volume"
              data={metrics.chartData.slice(-12)}
              lines={[
                { dataKey: 'impressions', color: 'hsl(var(--chart-1))', name: 'Impressions' },
                { dataKey: 'clicks', color: 'hsl(var(--chart-2))', name: 'Clicks', yAxisId: 'right' },
              ]}
            />
            
            <PerformanceChart
              title="Ad Revenue & Spend"
              data={metrics.chartData.slice(-12)}
              lines={[
                { dataKey: 'revenue', color: 'hsl(var(--chart-3))', name: `Ad Revenue (${metrics.baseCurrency})` },
                { dataKey: 'spend', color: 'hsl(var(--chart-4))', name: `Spend (${metrics.baseCurrency})` },
              ]}
            />
            
            <PerformanceChart
              title="Conversions & ROAS"
              data={metrics.chartData.slice(-12)}
              lines={[
                { dataKey: 'conversions', color: 'hsl(var(--chart-2))', name: 'Purchases' },
                { dataKey: 'roas', color: 'hsl(var(--chart-5))', name: 'ROAS', yAxisId: 'right' },
              ]}
            />
          </div>

          <PlatformTable data={metrics.platformData} baseCurrency={metrics.baseCurrency} />
        </TabsContent>

        <TabsContent value="monthly-review" className="space-y-6" data-testid="tab-content-monthly-review">
          {visitedTabs.has("monthly-review") && (
            <>
              {/* Monthly ROAS Chart - 14 months view */}
              <MonthlyROASChart clientId={selectedClientId} baseCurrency={metrics.baseCurrency} />

              {/* Monthly Metrics Table - 14 months view */}
              <MonthlyMetricsTable clientId={selectedClientId} baseCurrency={metrics.baseCurrency} />
            </>
          )}
        </TabsContent>

        <TabsContent value="creatives" className="space-y-6" data-testid="tab-content-creatives">
          {visitedTabs.has("creatives") && (
            <TopCreatives 
              clientId={selectedClientId} 
              timeframe={parseInt(timeframe)} 
              limit={6} 
            />
          )}
        </TabsContent>

        <TabsContent value="ad-copies" className="space-y-6" data-testid="tab-content-ad-copies">
          {visitedTabs.has("ad-copies") && (
            <TopAdCopies 
              clientId={selectedClientId} 
              timeframe={parseInt(timeframe)} 
              limit={5} 
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
