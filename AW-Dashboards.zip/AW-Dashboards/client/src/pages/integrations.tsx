import { PlatformCard } from "@/components/platform-card";
import { SiFacebook, SiGoogle, SiTiktok, SiSnapchat, SiShopify, SiWoo } from "react-icons/si";
import { BarChart3, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { PlatformConnection, Client } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { CredentialsGuide } from "@/components/credentials-guide";

const platformConfigs = [
  { name: "Meta Ads", icon: SiFacebook, requiresAuth: true },
  { name: "Google Ads", icon: SiGoogle, requiresAuth: true },
  { name: "TikTok Ads", icon: SiTiktok, requiresAuth: true },
  { name: "Snapchat Ads", icon: SiSnapchat, requiresAuth: true },
  { name: "Google Analytics", icon: BarChart3, requiresAuth: true },
  { name: "Shopify", icon: SiShopify, requiresAuth: true },
  { name: "WooCommerce", icon: SiWoo, requiresAuth: true },
];

export default function Integrations() {
  const [showConfigDialog, setShowConfigDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<string>("");
  const [activeClientId, setActiveClientId] = useState<string>("");
  const [editingConnection, setEditingConnection] = useState<PlatformConnection | null>(null);
  
  // Individual credential fields
  const [metaAccessToken, setMetaAccessToken] = useState("");
  const [metaAdAccountId, setMetaAdAccountId] = useState("");
  const [shopifyUrl, setShopifyUrl] = useState("");
  const [shopifyAccessToken, setShopifyAccessToken] = useState("");
  const [googleCustomerId, setGoogleCustomerId] = useState("");
  const [googleDeveloperToken, setGoogleDeveloperToken] = useState("");
  const [googleRefreshToken, setGoogleRefreshToken] = useState("");
  const [wooStoreUrl, setWooStoreUrl] = useState("");
  const [wooConsumerKey, setWooConsumerKey] = useState("");
  const [wooConsumerSecret, setWooConsumerSecret] = useState("");
  
  const { toast} = useToast();

  const { data: connections = [], isLoading: connectionsLoading } = useQuery<PlatformConnection[]>({
    queryKey: ["/api/platforms"],
  });

  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  const connectMutation = useMutation({
    mutationFn: async (data: { clientId: string; platform: string; credentials?: any }) => {
      return await apiRequest("POST", "/api/platforms", {
        clientId: data.clientId,
        platform: data.platform,
        isConnected: true,
        credentials: data.credentials || {},
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/platforms"] });
      setShowConfigDialog(false);
      setSelectedPlatform("");
      // Clear credential fields
      setMetaAccessToken("");
      setMetaAdAccountId("");
      setShopifyUrl("");
      setShopifyAccessToken("");
      setGoogleCustomerId("");
      setGoogleDeveloperToken("");
      setGoogleRefreshToken("");
      setWooStoreUrl("");
      setWooConsumerKey("");
      setWooConsumerSecret("");
      toast({
        title: "Platform connected",
        description: "The platform has been successfully connected.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to connect platform. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      return await apiRequest("PATCH", `/api/platforms/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/platforms"] });
      setShowEditDialog(false);
      setEditingConnection(null);
      // Clear credential fields
      setMetaAccessToken("");
      setMetaAdAccountId("");
      setShopifyUrl("");
      setShopifyAccessToken("");
      setGoogleCustomerId("");
      setGoogleDeveloperToken("");
      setGoogleRefreshToken("");
      setWooStoreUrl("");
      setWooConsumerKey("");
      setWooConsumerSecret("");
      toast({
        title: "Platform updated",
        description: "Platform connection has been updated successfully.",
      });
    },
  });

  const disconnectMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/platforms/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/platforms"] });
      toast({
        title: "Platform disconnected",
        description: "The platform has been successfully disconnected.",
      });
    },
  });

  const handleConnect = (platformName: string) => {
    if (!activeClientId) {
      toast({
        title: "Select a client",
        description: "Please select a client first to connect platforms.",
        variant: "destructive",
      });
      return;
    }
    setSelectedPlatform(platformName);
    // Clear all credential fields
    setMetaAccessToken("");
    setMetaAdAccountId("");
    setShopifyUrl("");
    setShopifyAccessToken("");
    setGoogleCustomerId("");
    setGoogleDeveloperToken("");
    setGoogleRefreshToken("");
    setWooStoreUrl("");
    setWooConsumerKey("");
    setWooConsumerSecret("");
    setShowConfigDialog(true);
  };

  const handleConfigure = (platformName: string) => {
    const connection = connections.find(c => 
      c.platform === platformName && c.clientId === activeClientId
    );
    if (connection) {
      setEditingConnection(connection);
      
      // Load credentials into individual fields
      const creds: any = connection.credentials || {};
      if (platformName === "Meta Ads") {
        setMetaAccessToken(creds.accessToken || "");
        setMetaAdAccountId(creds.adAccountId || "");
      } else if (platformName === "Shopify") {
        setShopifyUrl(creds.shopUrl || "");
        setShopifyAccessToken(creds.accessToken || "");
      } else if (platformName === "Google Ads") {
        setGoogleCustomerId(creds.customerId || "");
        setGoogleDeveloperToken(creds.developerToken || "");
        setGoogleRefreshToken(creds.refreshToken || "");
      } else if (platformName === "WooCommerce") {
        setWooStoreUrl(creds.storeUrl || "");
        setWooConsumerKey(creds.consumerKey || "");
        setWooConsumerSecret(creds.consumerSecret || "");
      }
      
      setShowEditDialog(true);
    }
  };

  const handleSaveConnection = () => {
    if (!activeClientId || !selectedPlatform) return;
    
    let credentials: any = {};
    
    // Build credentials based on platform
    if (selectedPlatform === "Meta Ads") {
      if (!metaAccessToken.trim() || !metaAdAccountId.trim()) {
        toast({
          title: "Missing credentials",
          description: "Please provide both Access Token and Ad Account ID.",
          variant: "destructive",
        });
        return;
      }
      credentials = {
        accessToken: metaAccessToken.trim(),
        adAccountId: metaAdAccountId.trim(),
      };
    } else if (selectedPlatform === "Shopify") {
      if (!shopifyUrl.trim() || !shopifyAccessToken.trim()) {
        toast({
          title: "Missing credentials",
          description: "Please provide both Shop URL and Access Token.",
          variant: "destructive",
        });
        return;
      }
      credentials = {
        shopUrl: shopifyUrl.trim(),
        accessToken: shopifyAccessToken.trim(),
      };
    } else if (selectedPlatform === "Google Ads") {
      if (!googleCustomerId.trim() || !googleDeveloperToken.trim() || !googleRefreshToken.trim()) {
        toast({
          title: "Missing credentials",
          description: "Please provide Customer ID, Developer Token, and Refresh Token.",
          variant: "destructive",
        });
        return;
      }
      credentials = {
        customerId: googleCustomerId.trim(),
        developerToken: googleDeveloperToken.trim(),
        refreshToken: googleRefreshToken.trim(),
      };
    } else if (selectedPlatform === "WooCommerce") {
      if (!wooStoreUrl.trim() || !wooConsumerKey.trim() || !wooConsumerSecret.trim()) {
        toast({
          title: "Missing credentials",
          description: "Please provide Store URL, Consumer Key, and Consumer Secret.",
          variant: "destructive",
        });
        return;
      }
      credentials = {
        storeUrl: wooStoreUrl.trim(),
        consumerKey: wooConsumerKey.trim(),
        consumerSecret: wooConsumerSecret.trim(),
      };
    }
    
    connectMutation.mutate({
      clientId: activeClientId,
      platform: selectedPlatform,
      credentials,
    });
  };

  const handleUpdateConnection = () => {
    if (!editingConnection) return;
    
    let credentials: any = {};
    
    // Build credentials based on platform
    if (editingConnection.platform === "Meta Ads") {
      if (!metaAccessToken.trim() || !metaAdAccountId.trim()) {
        toast({
          title: "Missing credentials",
          description: "Please provide both Access Token and Ad Account ID.",
          variant: "destructive",
        });
        return;
      }
      credentials = {
        accessToken: metaAccessToken.trim(),
        adAccountId: metaAdAccountId.trim(),
      };
    } else if (editingConnection.platform === "Shopify") {
      if (!shopifyUrl.trim() || !shopifyAccessToken.trim()) {
        toast({
          title: "Missing credentials",
          description: "Please provide both Shop URL and Access Token.",
          variant: "destructive",
        });
        return;
      }
      credentials = {
        shopUrl: shopifyUrl.trim(),
        accessToken: shopifyAccessToken.trim(),
      };
    } else if (editingConnection.platform === "Google Ads") {
      if (!googleCustomerId.trim() || !googleDeveloperToken.trim() || !googleRefreshToken.trim()) {
        toast({
          title: "Missing credentials",
          description: "Please provide Customer ID, Developer Token, and Refresh Token.",
          variant: "destructive",
        });
        return;
      }
      credentials = {
        customerId: googleCustomerId.trim(),
        developerToken: googleDeveloperToken.trim(),
        refreshToken: googleRefreshToken.trim(),
      };
    } else if (editingConnection.platform === "WooCommerce") {
      if (!wooStoreUrl.trim() || !wooConsumerKey.trim() || !wooConsumerSecret.trim()) {
        toast({
          title: "Missing credentials",
          description: "Please provide Store URL, Consumer Key, and Consumer Secret.",
          variant: "destructive",
        });
        return;
      }
      credentials = {
        storeUrl: wooStoreUrl.trim(),
        consumerKey: wooConsumerKey.trim(),
        consumerSecret: wooConsumerSecret.trim(),
      };
    }
    
    updateMutation.mutate({
      id: editingConnection.id,
      data: {
        credentials,
        lastSync: new Date().toISOString(),
      },
    });
  };

  const handleDisconnect = () => {
    if (editingConnection) {
      disconnectMutation.mutate(editingConnection.id);
      setShowEditDialog(false);
      setEditingConnection(null);
      // Clear credential fields
      setMetaAccessToken("");
      setMetaAdAccountId("");
      setShopifyUrl("");
      setShopifyAccessToken("");
      setGoogleCustomerId("");
      setGoogleDeveloperToken("");
      setGoogleRefreshToken("");
      setWooStoreUrl("");
      setWooConsumerKey("");
      setWooConsumerSecret("");
    }
  };

  const handleSyncAll = () => {
    if (!activeClientId) return;
    const connectedPlatforms = connections.filter(c => 
      c.clientId === activeClientId && c.isConnected
    );
    connectedPlatforms.forEach(connection => {
      updateMutation.mutate({ 
        id: connection.id, 
        data: { lastSync: new Date().toISOString() } 
      });
    });
  };

  const getPlatformStatus = (platformName: string) => {
    const connection = connections.find(c => 
      c.platform === platformName && 
      c.clientId === activeClientId && 
      c.isConnected
    );
    return {
      isConnected: !!connection,
      lastSync: connection?.lastSync ? new Date(connection.lastSync).toLocaleString() : undefined,
    };
  };

  const activeClient = clients.find(c => c.id === activeClientId);

  const formatLastSync = (lastSync?: string) => {
    if (!lastSync) return undefined;
    const date = new Date(lastSync);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    return `${days} day${days > 1 ? 's' : ''} ago`;
  };

  if (connectionsLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Integrations</h1>
            <p className="text-muted-foreground mt-1">
              Connect your advertising platforms and e-commerce stores
            </p>
          </div>
        </div>
        <div className="text-center py-12">
          <p className="text-muted-foreground">Loading integrations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Integrations</h1>
          <p className="text-muted-foreground mt-1">
            {activeClientId 
              ? `Managing integrations for ${activeClient?.name || "client"}`
              : "Select a client to manage their platform integrations"
            }
          </p>
        </div>
        <div className="flex gap-2">
          <Select value={activeClientId} onValueChange={setActiveClientId}>
            <SelectTrigger className="w-[200px]" data-testid="select-active-client">
              <SelectValue placeholder="Select client" />
            </SelectTrigger>
            <SelectContent>
              {clients.map((client) => (
                <SelectItem key={client.id} value={client.id}>
                  {client.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button 
            variant="outline" 
            data-testid="button-sync-all" 
            onClick={handleSyncAll}
            disabled={updateMutation.isPending || !activeClientId}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${updateMutation.isPending ? 'animate-spin' : ''}`} />
            Sync All
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {platformConfigs.map((platform) => {
          const status = getPlatformStatus(platform.name);
          return (
            <PlatformCard
              key={platform.name}
              name={platform.name}
              icon={platform.icon as any}
              isConnected={status.isConnected}
              lastSync={formatLastSync(status.lastSync)}
              onConnect={() => handleConnect(platform.name)}
              onConfigure={() => handleConfigure(platform.name)}
            />
          );
        })}
      </div>

      <Dialog open={showConfigDialog} onOpenChange={setShowConfigDialog}>
        <DialogContent data-testid="dialog-configure-platform">
          <DialogHeader>
            <DialogTitle>Connect {selectedPlatform}</DialogTitle>
            <DialogDescription>
              Configure the connection to {selectedPlatform} for a specific client.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <CredentialsGuide platform={selectedPlatform} />
            <div className="space-y-2">
              <Label>Client</Label>
              <div className="text-sm font-medium">{activeClient?.name || "Unknown"}</div>
            </div>
            
            {selectedPlatform === "Meta Ads" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="meta-access-token">Access Token *</Label>
                  <Input
                    id="meta-access-token"
                    placeholder="EAA..."
                    value={metaAccessToken}
                    onChange={(e) => setMetaAccessToken(e.target.value)}
                    data-testid="input-meta-access-token"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="meta-ad-account-id">Ad Account ID *</Label>
                  <Input
                    id="meta-ad-account-id"
                    placeholder="123456789"
                    value={metaAdAccountId}
                    onChange={(e) => setMetaAdAccountId(e.target.value)}
                    data-testid="input-meta-ad-account-id"
                  />
                </div>
              </>
            )}
            
            {selectedPlatform === "Shopify" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="shopify-url">Shop URL *</Label>
                  <Input
                    id="shopify-url"
                    placeholder="your-store.myshopify.com"
                    value={shopifyUrl}
                    onChange={(e) => setShopifyUrl(e.target.value)}
                    data-testid="input-shopify-url"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="shopify-access-token">Admin API Access Token *</Label>
                  <Input
                    id="shopify-access-token"
                    placeholder="shpat_..."
                    value={shopifyAccessToken}
                    onChange={(e) => setShopifyAccessToken(e.target.value)}
                    data-testid="input-shopify-access-token"
                  />
                </div>
              </>
            )}
            
            {selectedPlatform === "Google Ads" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="google-customer-id">Customer ID *</Label>
                  <Input
                    id="google-customer-id"
                    placeholder="123-456-7890"
                    value={googleCustomerId}
                    onChange={(e) => setGoogleCustomerId(e.target.value)}
                    data-testid="input-google-customer-id"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="google-developer-token">Developer Token *</Label>
                  <Input
                    id="google-developer-token"
                    placeholder="Your developer token"
                    value={googleDeveloperToken}
                    onChange={(e) => setGoogleDeveloperToken(e.target.value)}
                    data-testid="input-google-developer-token"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="google-refresh-token">Refresh Token *</Label>
                  <Input
                    id="google-refresh-token"
                    placeholder="OAuth refresh token"
                    value={googleRefreshToken}
                    onChange={(e) => setGoogleRefreshToken(e.target.value)}
                    data-testid="input-google-refresh-token"
                  />
                </div>
              </>
            )}
            
            {selectedPlatform === "WooCommerce" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="woo-store-url">Store URL *</Label>
                  <Input
                    id="woo-store-url"
                    placeholder="https://yourstore.com"
                    value={wooStoreUrl}
                    onChange={(e) => setWooStoreUrl(e.target.value)}
                    data-testid="input-woo-store-url"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="woo-consumer-key">Consumer Key *</Label>
                  <Input
                    id="woo-consumer-key"
                    placeholder="ck_..."
                    value={wooConsumerKey}
                    onChange={(e) => setWooConsumerKey(e.target.value)}
                    data-testid="input-woo-consumer-key"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="woo-consumer-secret">Consumer Secret *</Label>
                  <Input
                    id="woo-consumer-secret"
                    placeholder="cs_..."
                    value={wooConsumerSecret}
                    onChange={(e) => setWooConsumerSecret(e.target.value)}
                    data-testid="input-woo-consumer-secret"
                  />
                </div>
              </>
            )}
            
            {!["Meta Ads", "Shopify", "Google Ads", "WooCommerce"].includes(selectedPlatform) && (
              <p className="text-sm text-muted-foreground">
                This platform will use demo data. Real API integration coming soon.
              </p>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowConfigDialog(false)}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveConnection}
              disabled={!activeClientId || connectMutation.isPending}
              data-testid="button-save-connection"
            >
              {connectMutation.isPending ? "Connecting..." : "Connect Platform"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent data-testid="dialog-edit-platform">
          <DialogHeader>
            <DialogTitle>Manage {editingConnection?.platform}</DialogTitle>
            <DialogDescription>
              Update credentials or disconnect this platform.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {editingConnection && <CredentialsGuide platform={editingConnection.platform} />}
            
            {editingConnection?.platform === "Meta Ads" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="edit-meta-access-token">Access Token *</Label>
                  <Input
                    id="edit-meta-access-token"
                    placeholder="EAA..."
                    value={metaAccessToken}
                    onChange={(e) => setMetaAccessToken(e.target.value)}
                    data-testid="input-edit-meta-access-token"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-meta-ad-account-id">Ad Account ID *</Label>
                  <Input
                    id="edit-meta-ad-account-id"
                    placeholder="123456789"
                    value={metaAdAccountId}
                    onChange={(e) => setMetaAdAccountId(e.target.value)}
                    data-testid="input-edit-meta-ad-account-id"
                  />
                </div>
              </>
            )}
            
            {editingConnection?.platform === "Shopify" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="edit-shopify-url">Shop URL *</Label>
                  <Input
                    id="edit-shopify-url"
                    placeholder="your-store.myshopify.com"
                    value={shopifyUrl}
                    onChange={(e) => setShopifyUrl(e.target.value)}
                    data-testid="input-edit-shopify-url"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-shopify-access-token">Admin API Access Token *</Label>
                  <Input
                    id="edit-shopify-access-token"
                    placeholder="shpat_..."
                    value={shopifyAccessToken}
                    onChange={(e) => setShopifyAccessToken(e.target.value)}
                    data-testid="input-edit-shopify-access-token"
                  />
                </div>
              </>
            )}
            
            {editingConnection?.platform === "Google Ads" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="edit-google-customer-id">Customer ID *</Label>
                  <Input
                    id="edit-google-customer-id"
                    placeholder="123-456-7890"
                    value={googleCustomerId}
                    onChange={(e) => setGoogleCustomerId(e.target.value)}
                    data-testid="input-edit-google-customer-id"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-google-developer-token">Developer Token *</Label>
                  <Input
                    id="edit-google-developer-token"
                    placeholder="Your developer token"
                    value={googleDeveloperToken}
                    onChange={(e) => setGoogleDeveloperToken(e.target.value)}
                    data-testid="input-edit-google-developer-token"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-google-refresh-token">Refresh Token *</Label>
                  <Input
                    id="edit-google-refresh-token"
                    placeholder="OAuth refresh token"
                    value={googleRefreshToken}
                    onChange={(e) => setGoogleRefreshToken(e.target.value)}
                    data-testid="input-edit-google-refresh-token"
                  />
                </div>
              </>
            )}
            
            {editingConnection?.platform === "WooCommerce" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="edit-woo-store-url">Store URL *</Label>
                  <Input
                    id="edit-woo-store-url"
                    placeholder="https://yourstore.com"
                    value={wooStoreUrl}
                    onChange={(e) => setWooStoreUrl(e.target.value)}
                    data-testid="input-edit-woo-store-url"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-woo-consumer-key">Consumer Key *</Label>
                  <Input
                    id="edit-woo-consumer-key"
                    placeholder="ck_..."
                    value={wooConsumerKey}
                    onChange={(e) => setWooConsumerKey(e.target.value)}
                    data-testid="input-edit-woo-consumer-key"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-woo-consumer-secret">Consumer Secret *</Label>
                  <Input
                    id="edit-woo-consumer-secret"
                    placeholder="cs_..."
                    value={wooConsumerSecret}
                    onChange={(e) => setWooConsumerSecret(e.target.value)}
                    data-testid="input-edit-woo-consumer-secret"
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter className="flex justify-between">
            <Button
              variant="destructive"
              onClick={handleDisconnect}
              disabled={disconnectMutation.isPending}
              data-testid="button-disconnect"
            >
              {disconnectMutation.isPending ? "Disconnecting..." : "Disconnect"}
            </Button>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowEditDialog(false)}
                data-testid="button-cancel-edit"
              >
                Cancel
              </Button>
              <Button
                onClick={handleUpdateConnection}
                disabled={updateMutation.isPending}
                data-testid="button-update-connection"
              >
                {updateMutation.isPending ? "Updating..." : "Update & Sync"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
