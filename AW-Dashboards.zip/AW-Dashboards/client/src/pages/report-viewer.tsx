import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, FileText } from "lucide-react";
import type { Report } from "@shared/schema";

function parseMarkdown(content: string) {
  const lines = content.split('\n');
  const elements: JSX.Element[] = [];
  let tableBuffer: string[] = [];
  let inTable = false;
  let listBuffer: string[] = [];
  let inList = false;
  
  const flushTable = () => {
    if (tableBuffer.length > 0) {
      elements.push(<MarkdownTable key={`table-${elements.length}`} rows={tableBuffer} />);
      tableBuffer = [];
      inTable = false;
    }
  };

  const flushList = () => {
    if (listBuffer.length > 0) {
      elements.push(
        <ul key={`list-${elements.length}`} className="list-disc pl-6 space-y-1 my-4">
          {listBuffer.map((item, i) => (
            <li key={i} className="text-foreground/90">
              {parseInlineMarkdown(item)}
            </li>
          ))}
        </ul>
      );
      listBuffer = [];
      inList = false;
    }
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();
    
    // Handle tables
    if (trimmed.startsWith('|')) {
      if (!inTable) {
        flushList();
        inTable = true;
      }
      tableBuffer.push(line);
      return;
    } else if (inTable) {
      flushTable();
    }

    // Handle lists
    if (trimmed.startsWith('-') && trimmed.length > 1) {
      if (!inList) {
        flushTable();
        inList = true;
      }
      listBuffer.push(trimmed.substring(1).trim());
      return;
    } else if (inList) {
      flushList();
    }

    // Handle horizontal rules
    if (trimmed === '---') {
      flushTable();
      flushList();
      elements.push(<hr key={`hr-${index}`} className="my-8 border-border" />);
      return;
    }

    // Handle headers
    if (trimmed.startsWith('# ')) {
      flushTable();
      flushList();
      elements.push(
        <h1 key={index} className="text-4xl font-bold mt-8 mb-4 text-foreground">
          {parseInlineMarkdown(trimmed.substring(2))}
        </h1>
      );
    } else if (trimmed.startsWith('## ')) {
      flushTable();
      flushList();
      elements.push(
        <h2 key={index} className="text-3xl font-semibold mt-6 mb-3 text-foreground">
          {parseInlineMarkdown(trimmed.substring(3))}
        </h2>
      );
    } else if (trimmed.startsWith('### ')) {
      flushTable();
      flushList();
      elements.push(
        <h3 key={index} className="text-2xl font-semibold mt-5 mb-2 text-primary">
          {parseInlineMarkdown(trimmed.substring(4))}
        </h3>
      );
    } else if (trimmed.startsWith('#### ')) {
      flushTable();
      flushList();
      elements.push(
        <h4 key={index} className="text-xl font-semibold mt-4 mb-2 text-foreground">
          {parseInlineMarkdown(trimmed.substring(5))}
        </h4>
      );
    } else if (trimmed.length > 0) {
      // Regular paragraph
      flushTable();
      flushList();
      elements.push(
        <p key={index} className="my-3 text-foreground/90 leading-relaxed">
          {parseInlineMarkdown(trimmed)}
        </p>
      );
    }
  });

  // Flush any remaining buffers
  flushTable();
  flushList();

  return elements;
}

function parseInlineMarkdown(text: string): (string | JSX.Element)[] {
  const parts: (string | JSX.Element)[] = [];
  let currentIndex = 0;
  let partKey = 0;

  const boldRegex = /\*\*(.*?)\*\*/g;
  let match;

  while ((match = boldRegex.exec(text)) !== null) {
    if (match.index > currentIndex) {
      parts.push(text.substring(currentIndex, match.index));
    }
    parts.push(
      <strong key={`bold-${partKey++}`} className="font-semibold text-foreground">
        {match[1]}
      </strong>
    );
    currentIndex = match.index + match[0].length;
  }

  if (currentIndex < text.length) {
    parts.push(text.substring(currentIndex));
  }

  return parts.length > 0 ? parts : [text];
}

function MarkdownTable({ rows }: { rows: string[] }) {
  const tableRows = rows.map(row => 
    row.split('|').filter(cell => cell.trim().length > 0).map(cell => cell.trim())
  );

  if (tableRows.length < 2) return null;

  const headers = tableRows[0];
  const dataRows = tableRows.slice(2); // Skip header and separator row

  return (
    <div className="my-6 overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-primary/20">
            {headers.map((header, i) => (
              <th
                key={i}
                className="px-4 py-3 text-left font-semibold text-foreground bg-muted/50"
              >
                {parseInlineMarkdown(header)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {dataRows.map((row, i) => (
            <tr key={i} className="border-b border-border hover-elevate">
              {row.map((cell, j) => (
                <td key={j} className="px-4 py-3 text-foreground/90">
                  {parseInlineMarkdown(cell)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function ReportViewer() {
  const { slug } = useParams();

  const { data: report, isLoading, error } = useQuery<Report>({
    queryKey: ['/api/reports/slug', slug],
    queryFn: async () => {
      const response = await fetch(`/api/reports/slug/${slug}`);
      if (!response.ok) {
        throw new Error('Report not found');
      }
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-5xl mx-auto space-y-4">
          <Skeleton className="h-12 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Report not found or unavailable.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto p-6 md:p-8 lg:p-12">
        <Card className="shadow-lg">
          <CardHeader className="border-b border-border pb-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-primary/10">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <CardTitle className="text-3xl font-bold mb-2">
                  {report.name}
                </CardTitle>
                {report.description && (
                  <CardDescription className="text-base">
                    {report.description}
                  </CardDescription>
                )}
                <div className="mt-3 text-sm text-muted-foreground">
                  Generated: {new Date(report.generatedAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-8">
            <div className="prose prose-slate dark:prose-invert max-w-none">
              {parseMarkdown(report.content)}
            </div>
          </CardContent>
        </Card>
        
        <footer className="mt-12 text-center text-sm text-muted-foreground pb-8">
          <p>Powered by Admireworks</p>
        </footer>
      </div>
    </div>
  );
}
