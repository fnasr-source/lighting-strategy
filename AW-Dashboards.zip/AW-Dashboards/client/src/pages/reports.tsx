import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, FileText, Link as LinkIcon, Copy, ExternalLink } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Client, Report } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Reports() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [reportName, setReportName] = useState("");
  const [reportSlug, setReportSlug] = useState("");
  const [reportDescription, setReportDescription] = useState("");
  const [reportContent, setReportContent] = useState("");
  const [selectedClient, setSelectedClient] = useState("");
  const { toast } = useToast();

  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  const { data: reports = [], isLoading: reportsLoading } = useQuery<Report[]>({
    queryKey: ["/api/reports"],
  });

  const createReportMutation = useMutation({
    mutationFn: async (data: { 
      name: string; 
      slug: string; 
      description?: string;
      content: string;
      clientId: string;
    }) => {
      return await apiRequest("POST", "/api/reports", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      setIsDialogOpen(false);
      resetForm();
      toast({
        title: "Report created",
        description: "Your report has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteReportMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/reports/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      toast({
        title: "Report deleted",
        description: "The report has been removed.",
      });
    },
  });

  const resetForm = () => {
    setReportName("");
    setReportSlug("");
    setReportDescription("");
    setReportContent("");
    setSelectedClient("");
  };

  const handleNameChange = (value: string) => {
    setReportName(value);
    if (!reportSlug || reportSlug === generateSlug(reportName)) {
      setReportSlug(generateSlug(value));
    }
  };

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  };

  const handleCreateReport = () => {
    if (!reportName || !reportSlug || !reportContent || !selectedClient) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createReportMutation.mutate({
      name: reportName,
      slug: reportSlug,
      description: reportDescription || undefined,
      content: reportContent,
      clientId: selectedClient,
    });
  };

  const getClientName = (clientId: string) => {
    const client = clients.find(c => c.id === clientId);
    return client?.name || "Unknown Client";
  };

  const getShareableLink = (slug: string) => {
    const url = `${window.location.origin}/report/${slug}`;
    return url;
  };

  const copyLink = (slug: string) => {
    const link = getShareableLink(slug);
    navigator.clipboard.writeText(link);
    toast({
      title: "Link copied",
      description: "Shareable link copied to clipboard.",
    });
  };

  const openReport = (slug: string) => {
    window.open(`/report/${slug}`, '_blank');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Reports</h1>
          <p className="text-muted-foreground mt-1">
            Create and manage shareable client reports
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-report">
              <Plus className="h-4 w-4 mr-2" />
              Create Report
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Report</DialogTitle>
              <DialogDescription>
                Create a shareable report with markdown content
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="client-select">Client *</Label>
                <Select value={selectedClient} onValueChange={setSelectedClient}>
                  <SelectTrigger id="client-select" data-testid="select-client">
                    <SelectValue placeholder="Select client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="report-name">Report Name *</Label>
                <Input
                  id="report-name"
                  placeholder="e.g., Q4 2024 Performance Analysis"
                  value={reportName}
                  onChange={(e) => handleNameChange(e.target.value)}
                  data-testid="input-report-name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="report-slug">
                  URL Slug * 
                  <span className="text-xs text-muted-foreground ml-2">(lowercase, hyphens only)</span>
                </Label>
                <Input
                  id="report-slug"
                  placeholder="q4-2024-performance"
                  value={reportSlug}
                  onChange={(e) => setReportSlug(generateSlug(e.target.value))}
                  data-testid="input-report-slug"
                />
                {reportSlug && (
                  <p className="text-xs text-muted-foreground">
                    URL: {getShareableLink(reportSlug)}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="report-description">Description (optional)</Label>
                <Input
                  id="report-description"
                  placeholder="Short summary of the report"
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  data-testid="input-report-description"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="report-content">Report Content (Markdown) *</Label>
                <Textarea
                  id="report-content"
                  placeholder="# Report Title&#10;&#10;## Section 1&#10;Your markdown content here..."
                  value={reportContent}
                  onChange={(e) => setReportContent(e.target.value)}
                  className="font-mono text-sm min-h-[300px]"
                  data-testid="textarea-report-content"
                />
                <p className="text-xs text-muted-foreground">
                  Supports markdown formatting: headers, tables, bold, lists, etc.
                </p>
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateReport}
                disabled={createReportMutation.isPending}
                data-testid="button-submit"
              >
                {createReportMutation.isPending ? "Creating..." : "Create Report"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Report Name</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reportsLoading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    Loading reports...
                  </TableCell>
                </TableRow>
              ) : reports.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No reports yet. Create your first report to get started.</p>
                  </TableCell>
                </TableRow>
              ) : (
                reports.map((report) => (
                  <TableRow key={report.id} data-testid={`row-report-${report.id}`}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{report.name}</p>
                        {report.description && (
                          <p className="text-sm text-muted-foreground">{report.description}</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{getClientName(report.clientId)}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(report.generatedAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </TableCell>
                    <TableCell>
                      <Badge variant={report.isPublic ? "secondary" : "outline"}>
                        {report.isPublic ? "Public" : "Private"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openReport(report.slug)}
                          data-testid={`button-open-${report.id}`}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyLink(report.slug)}
                          data-testid={`button-copy-${report.id}`}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            if (confirm('Are you sure you want to delete this report?')) {
                              deleteReportMutation.mutate(report.id);
                            }
                          }}
                          data-testid={`button-delete-${report.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
