# Marketing Analytics Dashboard - Design Guidelines

## Design Approach

**Selected Approach:** Design System (Material Design) with Linear-inspired refinements

**Justification:** This is a utility-focused, information-dense dashboard requiring consistent patterns for data visualization, client management, and report generation. Material Design provides excellent foundation for data-heavy interfaces, enhanced with Linear's clean typography and spatial efficiency.

**Key Principles:**
- Data clarity over decoration
- Efficient information density
- Consistent patterns across all platform integrations
- Professional, trustworthy aesthetic for client reports

## Typography

**Font Families:**
- Primary: Inter (headers, UI elements, data labels)
- Monospace: JetBrains Mono (metrics, numerical data)

**Hierarchy:**
- Page titles: text-3xl font-semibold tracking-tight
- Section headers: text-xl font-semibold
- Card titles: text-lg font-medium
- Body text: text-base font-normal
- Metrics/Numbers: text-2xl font-mono font-semibold
- Labels: text-sm font-medium
- Secondary text: text-sm text-gray-600

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-4, p-6
- Section spacing: space-y-6, space-y-8
- Card gaps: gap-4, gap-6
- Page margins: px-6, px-8

**Grid System:**
- Dashboard widgets: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 (for metric cards)
- Client list: grid-cols-1 lg:grid-cols-2 xl:grid-cols-3
- Charts: Full-width sections with max-w-7xl container
- Forms: Single column, max-w-2xl

## Component Library

### Navigation
**Sidebar Navigation (Left, Fixed):**
- Width: w-64
- Logo placement at top (h-16)
- Navigation items with icons (Heroicons - outline style)
- Active state: Filled background, medium font weight
- Bottom section for user profile and settings

### Dashboard Metrics Cards
**Stat Card Pattern:**
- Rounded corners (rounded-lg)
- Platform icon + metric name (text-sm)
- Large numerical value (text-2xl font-mono)
- Percentage change indicator with trend arrow
- Sparkline chart below metric (h-12)

### Data Tables
**Platform Performance Table:**
- Sticky header row
- Sortable columns with arrow indicators
- Row hover states
- Platform logo/icon in first column
- Right-aligned numerical columns
- Pagination at bottom (showing "1-20 of 150")

### Charts & Visualizations
**Chart Container:**
- Card wrapper (rounded-lg, p-6)
- Header with title and date range selector
- Legend positioned top-right
- Minimum height: h-80 for line/bar charts
- Use Chart.js or Recharts for consistency

**Chart Types:**
- Line charts: Multi-platform performance over time
- Bar charts: Platform comparison
- Donut charts: Traffic source distribution
- Area charts: Revenue trends

### Integration Cards
**Platform Connection Status:**
- Grid layout (3-4 columns on desktop)
- Platform logo centered at top
- Connection status badge (Connected/Disconnected)
- "Configure" or "Connect" button
- Last sync timestamp

### Report Generation Interface
**Report Builder:**
- Two-column layout (form left, preview right on lg+)
- Date range picker (start/end dates)
- Platform checkboxes (multi-select)
- Metric selection dropdown
- Client selector
- Export format buttons (PDF, Excel, CSV)
- Large "Generate Report" button

### Client Management
**Client List View:**
- Search bar at top (w-full max-w-md)
- "Add Client" button (top right)
- Client cards showing: name, connected platforms count, last report date
- Quick actions: Edit, View Reports, Delete

**Client Detail View:**
- Header with client name and breadcrumb
- Tabs: Overview, Platforms, Reports, Settings
- Connected platforms grid
- Recent reports table

### Forms & Inputs
**Input Fields:**
- Consistent height: h-10
- Border radius: rounded-md
- Labels: mb-2 block
- Helper text: text-sm mt-1
- Error states with red accent

**Buttons:**
- Primary: px-4 py-2 rounded-md font-medium
- Secondary: Similar with different treatment
- Icon buttons: p-2 rounded-md (for actions)

### Empty States
**No Data Pattern:**
- Centered icon (h-16 w-16)
- Heading explaining state
- Action button or setup instructions
- Used for: No clients, no connections, no reports

## Page Layouts

### Dashboard Home
- Header with greeting and date range selector
- 4-column metric cards (Impressions, Clicks, Revenue, ROAS)
- Chart section showing performance over time (full-width)
- Platform breakdown table
- Recent activity feed (right sidebar on xl screens)

### Integrations Page
- Page header with title and "Sync All" button
- Platform connection grid (2-3 columns)
- Each platform card expandable for configuration
- Status indicators prominently displayed

### Reports Page
- Tabs: Generate New | Report History
- Generate tab: Form + live preview split
- History tab: Filterable table with download actions
- Export buttons with platform icons

### Client Management
- Search + Add client bar
- Client cards grid
- Click card for detail view
- Detail view with tabbed interface

## Accessibility
- Form inputs include aria-labels
- All interactive elements keyboard navigable
- Focus states clearly visible (ring-2 ring-offset-2)
- Sufficient contrast ratios for text
- Loading states with accessible spinners

## Animations
**Minimal, purposeful only:**
- Page transitions: Fade in (200ms)
- Hover states: No animation, instant feedback
- Loading states: Subtle spinner on data fetch
- Chart animations: Disabled or minimal (300ms ease-in)

**Critical:** Prioritize data clarity and quick comprehension over visual flourishes.