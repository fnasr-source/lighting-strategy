# Admireworks - Multi-Platform Marketing Analytics Dashboard

## Overview
Admireworks is a marketing analytics dashboard designed for agencies and businesses. It unifies data from various advertising and e-commerce platforms (Meta Ads, Google Ads, TikTok Ads, Snapchat Ads, Google Analytics, Shopify, WooCommerce) to track campaign performance, manage multiple clients, and generate consolidated, multi-currency reports. The platform emphasizes data clarity, efficient client management, and cross-platform performance analysis.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React with TypeScript, using Vite.
- **UI Component System**: Shadcn/ui (New York style) based on Radix UI and Tailwind CSS.
- **Design System**: Material Design principles with Linear-inspired refinements, focusing on data clarity and professional aesthetics. Uses Inter for UI and JetBrains Mono for numerical data.
- **State Management**: TanStack Query (React Query) for server state management with aggressive caching.
- **Routing**: Wouter for lightweight client-side routing.
- **Theming**: Custom theme provider for light/dark modes with CSS variables.

### Backend
- **Runtime**: Node.js with Express.
- **API Pattern**: RESTful API.
- **Type Safety**: Shared TypeScript types between client and server.
- **Validation**: Zod schemas for API request validation, generated from Drizzle ORM.

### Data Storage
- **Database**: PostgreSQL via Neon serverless.
- **ORM**: Drizzle ORM for type-safe queries and schema management.
- **Schema Design**: Includes `users`, `clients` (multi-currency), `platform_connections`, and `reports`.
- **Migration Strategy**: Drizzle Kit.

### UI/UX Decisions
- **Client-Specific Dashboards**: Agency Dashboard for internal teams (authenticated, client switcher) and Client Dashboard (`/client/:clientId`) for individual clients (publicly shareable, tabbed navigation). Monthly Review tab is internal-only.
- **Access Control**: Internal dashboard requires username/password authentication; client-shareable dashboards are public.
- **Performance Optimization**: Tab-based lazy loading for "Top Creatives" and "Top Ad Copies" on client dashboards.
- **Data Visualization**:
    - Synchronized charts for metrics with vastly different scales (Traffic, Revenue & Spend, Conversions & ROAS).
    - Daily charts show last 12 days for trend visibility.
    - **Monthly Performance Overview**: 14-month trend chart with grouped bars showing Ad Spend, Ad Revenue, and E-commerce Revenue separately, with ROAS line calculated from Ad Revenue ÷ Ad Spend only. All monetary values formatted with 2 decimals and currency symbols. Fetches 420 days independently for consistent history. Legend clearly indicates "Ad Revenue ÷ Ad Spend" to avoid confusion.
    - **Monthly Metrics Summary Table**: 14-month aggregated data with sortable columns for Ad Spend, Ad Revenue, E-commerce Revenue, ROAS, Orders, CPO, AOV, and CPM. Features conditional color coding, month-over-month % change indicators, sticky header, and separate totals for ad and e-commerce revenue to maintain clarity about ROAS calculation basis.
- **Creative and Ad Copy Analysis**: Displays top-performing ads with visual previews, type/rank badges, and comprehensive metrics.

### System Design Choices
- **Platform Metrics Architecture**:
    - Differentiates Ad Platforms (Meta Ads, Google Ads, TikTok Ads, Snapchat Ads) from E-commerce Platforms (Shopify, WooCommerce).
    - **Ad Platforms**: Provide Impressions, Clicks, Spend, Ad Conversions, Ad Revenue.
    - **E-commerce Platforms**: Provide Orders, E-commerce Revenue, Sessions.
    - **Aggregation Rules**: Impressions, Clicks, Spend from ad platforms only. Revenue is split into "Ad Revenue" and "E-commerce Revenue". Conversions split into "Ad Conversions" and "E-commerce Orders". Sessions from e-commerce platforms only. ROAS calculated from Ad Revenue/Ad Spend only.
    - **Conversion Rate (E-commerce)**: Calculated as (E-commerce Orders ÷ Sessions) × 100. Prioritizes Shopify ShopifyQL for session data, falls back to Google Analytics 4.
    - **Average Order Value**: E-commerce Revenue ÷ E-commerce Orders, using Shopify's `total_price` and including all financial statuses.
- **Currency Handling**: Multi-currency support with all platform metrics converted to the client's base currency. Explicit logging for failed conversions; revenue/spend from unsupported currencies are zeroed out.
- **Meta Ads Data Completeness** (November 2025):
    - **Issue**: Meta's daily breakdown endpoint lags 3-7 days behind their aggregate endpoint due to attribution window processing (28-day attribution windows, iOS tracking delays, cross-device reconciliation). Additionally, Meta's API paginates results (25 days per page).
    - **Solution**: Industry-standard dual-fetch strategy merging conversion-time attribution with impression-time backfill, with full pagination support.
    - **Implementation**: 
        - Fetches TWO datasets from Meta: (1) `action_report_time=conversion` (authoritative but lags 3-7 days), (2) `action_report_time=impression` (always complete, includes all calendar days)
        - **Pagination Handling**: `fetchAllPages()` helper function automatically follows Meta's pagination cursors to retrieve all days (not just first 25 days)
        - **Merge Strategy**: Uses conversion-time data when available (most accurate); for recent days without conversion-time data, uses impression-time data; marks those days with `pendingAttribution: true`. Walks full date range to ensure all days are populated (conversion → impression → zero records for inactive days).
        - **Period Totals (30-day, 14-day)**: Uses Meta's aggregate endpoint directly (100% accurate totals)
    - **Result**: Every day has data (no gaps in charts), 100% accurate aggregate totals, recent days marked as pending attribution for visual indicators. All clients receive complete daily data regardless of ad spend levels.
- **Monthly Data Caching System**:
    - **Purpose**: Provides instant load times for the Monthly Review tab by pre-aggregating 14 months of historical data.
    - **Architecture**: Uses `monthly_platform_metrics` (platform-level), `monthly_client_rollups` (client-level aggregates), and `data_sync_jobs` tables.
    - **API Endpoints**: `POST /api/clients/:id/sync-historical-data` (asynchronous 14-month backfill), `GET /api/clients/:id/monthly-metrics` (retrieves cached data).
    - **Performance**: Achieves ~22ms load times for Monthly Review data.
    - **Data Freshness**: Historical data updated manually via sync button; current month still uses real-time API calls.
- **Manual Data Override System** (November 2025):
    - **Purpose**: Allows admin users to manually edit monthly metrics when platform data is incorrect or missing.
    - **Architecture**: Layered approach - overrides stored in `monthly_data_overrides` table, separate from platform data. Merged at read-time via `getClientMonthlyMetrics()`.
    - **Supported Metrics**: spend, ecommerceRevenue, roas, orders, cpo, aov, cpm (7 key metrics)
    - **Audit Trail**: All changes tracked in `overrides_audit` table (create/update/delete actions with user ID and timestamps)
    - **API Endpoints**: 
        - `GET /api/clients/:id/monthly-overrides` - Fetch all overrides for a client (requires auth)
        - `POST /api/clients/:id/monthly-overrides/batch` - Save batch of overrides with audit trail (admin only)
        - `DELETE /api/clients/:id/monthly-overrides?monthEndDate=...&metricId=...` - Revert to platform data (admin only)
    - **Data Integrity**: Unique constraint on (clientId, monthEndDate, metricId) prevents duplicates. Override values stored as text for precision.
    - **Merge Logic**: In `server/services/monthly-aggregation.ts`, overrides are fetched and merged after platform rollups, taking precedence over platform values.
- **Authentication**: Session-based authentication using Passport.js with PostgreSQL session store. Supports Admin (full control) and User (view-only) roles. First registered user becomes admin. Passwords hashed with scrypt. Internal dashboard routes protected; client-shareable dashboards are public.
- **Shareable Branded Reports** (November 2025):
    - **Purpose**: Allows agencies to create professional, branded performance analysis reports that can be shared with clients via public links.
    - **Architecture**: Reports stored in `reports` table with markdown content, metadata, and unique URL slugs for public access.
    - **Features**:
        - Full markdown support (headers, tables, bold, lists, code blocks, horizontal rules)
        - Custom markdown parser built without external dependencies for security and control
        - Public shareable URLs (`/report/:slug`) accessible without authentication
        - Admin-only creation and management interface at `/reports`
        - Admireworks branding on public viewer pages with theme toggle
        - Copy-to-clipboard functionality for easy link sharing
        - Support for report descriptions and client associations
    - **API Endpoints**:
        - `GET /api/reports/public/:slug` - Fetch public report by slug (no auth required)
        - `GET /api/reports` - List all reports (requires authentication)
        - `POST /api/reports` - Create new report (requires admin authentication)
        - `DELETE /api/reports/:id` - Delete report (requires admin authentication)
    - **Database Schema**: Reports include `slug` (URL identifier), `content` (markdown), `description`, `is_public` (visibility flag), `client_id` (association), and `created_by` (audit trail)
    - **Use Cases**: Quarterly performance summaries, campaign retrospectives, strategic recommendations, client deliverables

## External Dependencies

### Third-Party Platform APIs
- Meta Ads API
- Shopify API
- Google Ads API
- TikTok Ads API
- Snapchat Ads API
- Google Analytics API
- WooCommerce API

### Infrastructure Services
- Neon Database (PostgreSQL hosting)
- Replit (Development and deployment)

### Key NPM Packages
- `@shopify/shopify-api`
- `axios`
- `@neondatabase/serverless`
- `ws`
- `react-hook-form` with `@hookform/resolvers`
- `recharts`
- `date-fns`
- `react-icons`
- `@google-analytics/data` (for GA4 integration)

### Other Integrations
- **Currency Conversion**: Mock service for 90+ currencies, intended for real-time exchange rate API integration in production.