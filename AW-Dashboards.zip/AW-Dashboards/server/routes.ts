import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertClientSchema, insertPlatformConnectionSchema, insertReportSchema, insertUserSchema, insertMonthlyDataOverrideSchema, insertOverridesAuditSchema } from "@shared/schema";
import { z } from "zod";
import { setupAuth, hashPassword } from "./auth";
import { backfillClientMonthlyData, getClientMonthlyMetrics } from "./services/monthly-aggregation";

// Middleware to require authentication for internal routes
const requireAuth = (req: any, res: any, next: any) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
};

// Middleware to require admin role
const requireAdmin = (req: any, res: any, next: any) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Authentication required" });
  }
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes (/api/register, /api/login, /api/logout, /api/user)
  setupAuth(app);

  // Check if any users exist (public endpoint for first-time setup)
  app.get("/api/system/has-users", async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      res.json({ hasUsers: allUsers.length > 0 });
    } catch (error) {
      res.status(500).json({ error: "Failed to check users" });
    }
  });

  // User management routes - admin only
  app.get("/api/users", requireAdmin, async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      // Strip passwords before sending to client
      const usersWithoutPasswords = allUsers.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.post("/api/users", requireAdmin, async (req, res) => {
    try {
      // Validate request body
      const validatedData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      const user = await storage.createUser({
        ...validatedData,
        password: await hashPassword(validatedData.password),
      });

      // Don't send password back
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create user" });
    }
  });

  // Client routes - protected
  app.get("/api/clients", requireAuth, async (req, res) => {
    try {
      const clients = await storage.getAllClients();
      res.json(clients);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch clients" });
    }
  });

  app.get("/api/clients/:id", async (req, res) => {
    try {
      const client = await storage.getClient(req.params.id);
      if (!client) {
        return res.status(404).json({ error: "Client not found" });
      }
      
      // If unauthenticated (public client dashboard), strip sensitive fields
      if (!req.isAuthenticated()) {
        const { ga4Credentials, ...sanitizedClient } = client;
        return res.json(sanitizedClient);
      }
      
      // Authenticated users (internal dashboard) get full details
      res.json(client);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch client" });
    }
  });

  app.post("/api/clients", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(validatedData);
      res.status(201).json(client);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create client" });
    }
  });

  app.patch("/api/clients/:id", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertClientSchema.partial().parse(req.body);
      const client = await storage.updateClient(req.params.id, validatedData);
      if (!client) {
        return res.status(404).json({ error: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update client" });
    }
  });

  app.delete("/api/clients/:id", requireAdmin, async (req, res) => {
    try {
      const success = await storage.deleteClient(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Client not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete client" });
    }
  });

  // Monthly metrics routes
  app.post("/api/clients/:id/sync-historical-data", requireAdmin, async (req, res) => {
    try {
      const clientId = req.params.id;
      const monthsToBackfill = req.body.months || 14;
      
      console.log(`🔄 Starting historical data sync for client ${clientId}`);
      
      // Run backfill in background (async, don't await)
      backfillClientMonthlyData(clientId, monthsToBackfill)
        .then(() => {
          console.log(`✅ Historical data sync completed for client ${clientId}`);
        })
        .catch((error) => {
          console.error(`❌ Historical data sync failed for client ${clientId}:`, error);
        });
      
      // Return immediately - don't make client wait
      res.json({ message: "Historical data sync started", clientId, months: monthsToBackfill });
    } catch (error) {
      console.error("❌ Error starting historical data sync:", error);
      res.status(500).json({ error: "Failed to start historical data sync" });
    }
  });

  app.get("/api/clients/:id/monthly-metrics", async (req, res) => {
    try {
      const clientId = req.params.id;
      const metrics = await getClientMonthlyMetrics(clientId);
      res.json(metrics);
    } catch (error) {
      console.error("❌ Error fetching monthly metrics:", error);
      res.status(500).json({ error: "Failed to fetch monthly metrics" });
    }
  });

  // Monthly data override routes - admin only
  app.get("/api/clients/:id/monthly-overrides", requireAuth, async (req, res) => {
    try {
      const clientId = req.params.id;
      const overrides = await storage.getClientOverrides(clientId);
      res.json(overrides);
    } catch (error) {
      console.error("❌ Error fetching monthly overrides:", error);
      res.status(500).json({ error: "Failed to fetch monthly overrides" });
    }
  });

  app.post("/api/clients/:id/monthly-overrides/batch", requireAdmin, async (req, res) => {
    try {
      const clientId = req.params.id;
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Validate the batch data
      const batchSchema = z.array(
        z.object({
          monthEndDate: z.string(),
          metricId: z.enum(["spend", "ecommerceRevenue", "roas", "orders", "cpo", "aov", "cpm"]),
          overrideValue: z.string(),
        })
      );

      const validatedBatch = batchSchema.parse(req.body);
      const results = [];

      // Process each override in the batch
      for (const item of validatedBatch) {
        // Get the existing value (if any) for audit trail
        const existing = await storage.getOverride(clientId, item.monthEndDate, item.metricId);
        
        // Create or update the override
        const override = await storage.createOrUpdateOverride({
          clientId,
          monthEndDate: item.monthEndDate,
          metricId: item.metricId,
          overrideValue: item.overrideValue,
          editedBy: userId,
        });

        // Create audit trail
        await storage.createAuditEntry({
          overrideId: override.id,
          clientId,
          monthEndDate: item.monthEndDate,
          metricId: item.metricId,
          actionType: existing ? "updated" : "created",
          oldValue: existing?.overrideValue || null,
          newValue: item.overrideValue,
          editedBy: userId,
        });

        results.push(override);
      }

      console.log(`✓ Saved ${results.length} monthly data overrides for client ${clientId}`);
      res.json({ success: true, overrides: results });
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("❌ Validation error saving overrides:", error.errors);
        return res.status(400).json({ error: error.errors });
      }
      console.error("❌ Error saving monthly overrides:", error);
      res.status(500).json({ error: "Failed to save monthly overrides" });
    }
  });

  app.delete("/api/clients/:id/monthly-overrides", requireAdmin, async (req, res) => {
    try {
      const clientId = req.params.id;
      const userId = req.user?.id;
      const { monthEndDate, metricId } = req.query;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      if (!monthEndDate || !metricId) {
        return res.status(400).json({ error: "monthEndDate and metricId are required" });
      }

      // Get the existing override for audit trail
      const existing = await storage.getOverride(clientId, monthEndDate as string, metricId as string);
      
      if (!existing) {
        return res.status(404).json({ error: "Override not found" });
      }

      // Delete the override
      const deleted = await storage.deleteOverride(clientId, monthEndDate as string, metricId as string);

      if (deleted) {
        // Create audit trail
        await storage.createAuditEntry({
          overrideId: existing.id,
          clientId,
          monthEndDate: monthEndDate as string,
          metricId: metricId as string,
          actionType: "deleted",
          oldValue: existing.overrideValue,
          newValue: null,
          editedBy: userId,
        });

        console.log(`✓ Deleted override for ${metricId} on ${monthEndDate}`);
        res.json({ success: true });
      } else {
        res.status(500).json({ error: "Failed to delete override" });
      }
    } catch (error) {
      console.error("❌ Error deleting monthly override:", error);
      res.status(500).json({ error: "Failed to delete monthly override" });
    }
  });

  // Report routes
  // Public route - get report by slug (shareable link)
  app.get("/api/reports/slug/:slug", async (req, res) => {
    try {
      const report = await storage.getReportBySlug(req.params.slug);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      
      // Only return public reports unless user is authenticated
      if (!report.isPublic && !req.isAuthenticated()) {
        return res.status(403).json({ error: "This report is private" });
      }
      
      res.json(report);
    } catch (error) {
      console.error("❌ Error fetching report:", error);
      res.status(500).json({ error: "Failed to fetch report" });
    }
  });

  // List all reports - authenticated users only
  app.get("/api/reports", requireAuth, async (req, res) => {
    try {
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      console.error("❌ Error fetching reports:", error);
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });

  // Create a new report - admin only
  app.post("/api/reports", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertReportSchema.parse({
        ...req.body,
        createdBy: req.user?.id,
      });
      const report = await storage.createReport(validatedData);
      console.log(`✓ Report created: ${report.name} (${report.slug})`);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("❌ Error creating report:", error);
      res.status(500).json({ error: "Failed to create report" });
    }
  });

  // Delete a report - admin only
  app.delete("/api/reports/:id", requireAdmin, async (req, res) => {
    try {
      const success = await storage.deleteReport(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Report not found" });
      }
      console.log(`✓ Report deleted: ${req.params.id}`);
      res.status(204).send();
    } catch (error) {
      console.error("❌ Error deleting report:", error);
      res.status(500).json({ error: "Failed to delete report" });
    }
  });

  // Platform connection routes - protected
  app.get("/api/platforms", requireAuth, async (req, res) => {
    try {
      const connections = await storage.getAllPlatformConnections();
      res.json(connections);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch platform connections" });
    }
  });

  app.get("/api/platforms/client/:clientId", requireAuth, async (req, res) => {
    try {
      const connections = await storage.getPlatformConnections(req.params.clientId);
      res.json(connections);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch platform connections" });
    }
  });

  app.post("/api/platforms", requireAdmin, async (req, res) => {
    try {
      console.log("Creating platform connection:", req.body.platform, "for client:", req.body.clientId);
      const validatedData = insertPlatformConnectionSchema.parse(req.body);
      const connection = await storage.createPlatformConnection(validatedData);
      console.log(`✓ Platform connection created successfully: ${connection.platform}`);
      res.status(201).json(connection);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("❌ Validation error creating platform connection:", error.errors);
        return res.status(400).json({ error: error.errors });
      }
      console.error("❌ Error creating platform connection:", error);
      res.status(500).json({ error: "Failed to create platform connection" });
    }
  });

  app.patch("/api/platforms/:id", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertPlatformConnectionSchema.partial().parse(req.body);
      const connection = await storage.updatePlatformConnection(req.params.id, validatedData);
      if (!connection) {
        return res.status(404).json({ error: "Platform connection not found" });
      }
      res.json(connection);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update platform connection" });
    }
  });

  app.delete("/api/platforms/:id", requireAdmin, async (req, res) => {
    try {
      const success = await storage.deletePlatformConnection(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Platform connection not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete platform connection" });
    }
  });

  // Report routes - protected
  app.get("/api/reports", requireAuth, async (req, res) => {
    try {
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });

  app.get("/api/reports/client/:clientId", requireAuth, async (req, res) => {
    try {
      const reports = await storage.getReportsByClient(req.params.clientId);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });

  app.get("/api/reports/:id", requireAuth, async (req, res) => {
    try {
      const report = await storage.getReport(req.params.id);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch report" });
    }
  });

  app.post("/api/reports", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertReportSchema.parse(req.body);
      const report = await storage.createReport(validatedData);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create report" });
    }
  });

  app.patch("/api/reports/:id", requireAdmin, async (req, res) => {
    try {
      const validatedData = insertReportSchema.partial().parse(req.body);
      const report = await storage.updateReport(req.params.id, validatedData);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update report" });
    }
  });

  app.delete("/api/reports/:id", requireAdmin, async (req, res) => {
    try {
      const success = await storage.deleteReport(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete report" });
    }
  });

  // Platform data aggregation endpoint
  app.get("/api/metrics/dashboard", async (req, res) => {
    try {
      const { aggregatePlatformData, isAdPlatform, isEcommercePlatform } = await import("./services/platform-data");
      const { convertCurrency } = await import("./services/currency");
      
      const clientId = req.query.clientId as string;
      const timeframe = parseInt(req.query.timeframe as string) || 30;
      
      if (!clientId) {
        return res.status(400).json({ error: "Client ID is required" });
      }
      
      // Get client to access base currency
      const client = await storage.getClient(clientId);
      if (!client) {
        return res.status(404).json({ error: "Client not found" });
      }
      
      const baseCurrency = client.baseCurrency || "USD";
      
      // Get connected platforms for this client
      const connections = await storage.getAllPlatformConnections();
      const connectedPlatforms = connections.filter(c => c.isConnected && c.clientId === clientId);
      
      console.log(`📊 Dashboard for ${client.name} (${baseCurrency}): Found ${connectedPlatforms.length} connected platforms:`, 
        connectedPlatforms.map(c => c.platform).join(", ") || "none");
      
      // Prepare GA4 configuration if available
      const ga4Config = (client.ga4PropertyId && client.ga4Credentials) 
        ? { propertyId: client.ga4PropertyId, credentials: client.ga4Credentials }
        : undefined;
      
      if (ga4Config) {
        console.log('  📊 GA4 configured for client, will use for session data if needed');
      }
      
      // Helper function to fetch and aggregate platform data for a given period
      const fetchPeriodData = async (days: number, daysOffset: number = 0) => {
        const periodDataPromises = connectedPlatforms.map(async (connection) => {
          const metrics = await aggregatePlatformData(connection.platform, connection.credentials, days, daysOffset, ga4Config);
          const platformCurrency = metrics.currency || baseCurrency;
          
          const convertedRevenue = convertCurrency(metrics.revenue, platformCurrency, baseCurrency) ?? 0;
          const convertedSpend = convertCurrency(metrics.spend, platformCurrency, baseCurrency) ?? 0;
          const convertedCpm = convertCurrency(metrics.cpm || 0, platformCurrency, baseCurrency) ?? 0;
          
          if (convertedRevenue === 0 && metrics.revenue > 0) {
            console.error(`  ❌ Revenue conversion failed for ${connection.platform}: ${metrics.revenue} ${platformCurrency} to ${baseCurrency}`);
          }
          
          if (convertedSpend === 0 && metrics.spend > 0) {
            console.error(`  ❌ Spend conversion failed for ${connection.platform}: ${metrics.spend} ${platformCurrency} to ${baseCurrency}`);
          }
          
          if (convertedCpm === 0 && (metrics.cpm || 0) > 0) {
            console.error(`  ❌ CPM conversion failed for ${connection.platform}: ${metrics.cpm} ${platformCurrency} to ${baseCurrency}`);
          }
          
          const ctr = metrics.impressions > 0 ? (metrics.clicks / metrics.impressions) * 100 : 0;
          const roas = convertedSpend > 0 ? convertedRevenue / convertedSpend : 0;
          
          return {
            platform: connection.platform,
            platformType: isAdPlatform(connection.platform) ? 'ad' : isEcommercePlatform(connection.platform) ? 'ecommerce' : 'other',
            impressions: metrics.impressions,
            clicks: metrics.clicks,
            ctr: parseFloat(ctr.toFixed(2)),
            conversions: metrics.conversions,
            spend: convertedSpend,
            revenue: convertedRevenue,
            roas: parseFloat(roas.toFixed(2)),
            currency: baseCurrency,
            originalCurrency: platformCurrency,
            // Ad platform specific metrics
            reach: metrics.reach || 0,
            frequency: metrics.frequency || 0,
            linkClicks: metrics.linkClicks || 0,
            cpm: convertedCpm,
            // E-commerce specific metrics
            sessions: metrics.sessions || 0,
            dailyData: metrics.dailyData, // Pass through cached daily data
          };
        });
        
        const periodData = await Promise.all(periodDataPromises);
        
        // Separate ad platform metrics from e-commerce metrics
        const adPlatforms = periodData.filter(p => p.platformType === 'ad');
        const ecommercePlatforms = periodData.filter(p => p.platformType === 'ecommerce');
        
        // Aggregate ONLY ad platforms for impression, clicks, spend, and ad-specific metrics
        const adTotals = adPlatforms.reduce(
          (acc, platform) => ({
            impressions: acc.impressions + platform.impressions,
            clicks: acc.clicks + platform.clicks,
            spend: acc.spend + platform.spend,
            conversions: acc.conversions + platform.conversions,
            revenue: acc.revenue + platform.revenue,
            reach: acc.reach + (platform.reach || 0),
            frequency: acc.frequency + (platform.frequency || 0),
            linkClicks: acc.linkClicks + (platform.linkClicks || 0),
            cpm: acc.cpm + (platform.cpm || 0),
          }),
          { impressions: 0, clicks: 0, spend: 0, conversions: 0, revenue: 0, reach: 0, frequency: 0, linkClicks: 0, cpm: 0 }
        );
        
        // Average frequency and CPM across platforms
        if (adPlatforms.length > 0) {
          adTotals.frequency = adTotals.frequency / adPlatforms.length;
          adTotals.cpm = adTotals.cpm / adPlatforms.length;
        }
        
        // Aggregate e-commerce platforms for orders, revenue, and sessions
        const ecommerceTotals = ecommercePlatforms.reduce(
          (acc, platform) => ({
            orders: acc.orders + platform.conversions,
            revenue: acc.revenue + platform.revenue,
            sessions: acc.sessions + platform.sessions,
          }),
          { orders: 0, revenue: 0, sessions: 0 }
        );
        
        // Combined metrics logic:
        // - Impressions, clicks, spend: ONLY from ad platforms
        // - Revenue: Sum of ad revenue (from ROAS) + e-commerce revenue
        // - Conversions: Ad conversions + e-commerce orders (total purchases)
        // - Sessions: From e-commerce platforms (Shopify/WooCommerce)
        const periodTotals = {
          impressions: adTotals.impressions,
          clicks: adTotals.clicks,
          spend: adTotals.spend,
          conversions: adTotals.conversions + ecommerceTotals.orders,
          revenue: adTotals.revenue + ecommerceTotals.revenue,
          adRevenue: adTotals.revenue,
          ecommerceRevenue: ecommerceTotals.revenue,
          adConversions: adTotals.conversions,
          ecommerceOrders: ecommerceTotals.orders,
          // Ad platform specific metrics
          reach: adTotals.reach,
          frequency: adTotals.frequency,
          linkClicks: adTotals.linkClicks,
          cpm: adTotals.cpm,
          // E-commerce specific metrics
          ecommerceSessions: ecommerceTotals.sessions,
        };
        
        // Log the breakdown
        if (daysOffset === 0) {
          console.log(`  📊 Metrics breakdown:`);
          console.log(`     Ad platforms (${adPlatforms.length}): Impressions=${adTotals.impressions.toLocaleString()}, Clicks=${adTotals.clicks.toLocaleString()}, Spend=${adTotals.spend.toFixed(2)}, Conversions=${adTotals.conversions}, Revenue=${adTotals.revenue.toFixed(2)}`);
          console.log(`     E-commerce (${ecommercePlatforms.length}): Orders=${ecommerceTotals.orders}, Revenue=${ecommerceTotals.revenue.toFixed(2)}, Sessions=${ecommerceTotals.sessions.toLocaleString()}`);
          console.log(`     Combined: Revenue=${periodTotals.revenue.toFixed(2)} (${baseCurrency}), Total Conversions=${periodTotals.conversions}`);
        }
        
        // ROAS should only use Ad Revenue (not e-commerce revenue)
        const totalRoas = periodTotals.spend > 0 ? periodTotals.adRevenue / periodTotals.spend : 0;
        const totalCtr = periodTotals.impressions > 0 ? (periodTotals.clicks / periodTotals.impressions) * 100 : 0;
        // Conversion Rate uses E-commerce sessions (not ad clicks)
        // Return null if session data unavailable, 0 if sessions exist but no orders
        const hasSessionData = ecommercePlatforms.length > 0 && periodTotals.ecommerceSessions > 0;
        const conversionRate = hasSessionData ? (periodTotals.ecommerceOrders / periodTotals.ecommerceSessions) * 100 : null;
        
        return {
          platformData: periodData,
          totals: periodTotals,
          roas: totalRoas,
          ctr: totalCtr,
          conversionRate,
        };
      };
      
      // Fetch current period data
      console.log(`  → Fetching current period data (${timeframe} days)`);
      const currentPeriod = await fetchPeriodData(timeframe, 0);
      
      // Fetch previous period data for comparison
      console.log(`  → Fetching previous period data (${timeframe} days) for comparison`);
      const previousPeriod = await fetchPeriodData(timeframe, timeframe);
      
      console.log('📊 Current period totals:', currentPeriod.totals);
      console.log('📊 Previous period totals:', previousPeriod.totals);
      
      // Calculate percentage changes
      const calculateChange = (current: number, previous: number): number => {
        if (previous === 0) return current > 0 ? 100 : 0;
        return parseFloat((((current - previous) / previous) * 100).toFixed(1));
      };
      
      const changes = {
        impressions: calculateChange(currentPeriod.totals.impressions, previousPeriod.totals.impressions),
        clicks: calculateChange(currentPeriod.totals.clicks, previousPeriod.totals.clicks),
        spend: calculateChange(currentPeriod.totals.spend, previousPeriod.totals.spend),
        conversions: calculateChange(currentPeriod.totals.conversions, previousPeriod.totals.conversions),
        adRevenue: calculateChange(currentPeriod.totals.adRevenue, previousPeriod.totals.adRevenue),
        ecommerceRevenue: calculateChange(currentPeriod.totals.ecommerceRevenue, previousPeriod.totals.ecommerceRevenue),
        roas: calculateChange(currentPeriod.roas, previousPeriod.roas),
        ctr: calculateChange(currentPeriod.ctr, previousPeriod.ctr),
        // Conversion rate change only if both periods have session data
        conversionRate: (currentPeriod.conversionRate !== null && previousPeriod.conversionRate !== null) 
          ? calculateChange(currentPeriod.conversionRate, previousPeriod.conversionRate)
          : 0,
      };
      
      console.log('📈 Period-over-period changes:', changes);
      
      // Fetch real daily data for chart by combining all platform data
      const { fetchMetaAdsDailyData } = await import("./services/platform-data");
      console.log(`  → Fetching daily breakdown data (${timeframe} days)`);
      
      // Build a comprehensive daily dataset from all sources
      // Use ISO dates (YYYY-MM-DD) as map keys to avoid year collisions
      const dailyDataMap = new Map<string, { 
        impressions: number; 
        clicks: number; 
        spend: number; 
        adRevenue: number;
        ecommerceRevenue: number;
        conversions: number;
      }>();
      
      // Initialize all days in the timeframe with zeros (excluding today)
      for (let i = 0; i < timeframe; i++) {
        const date = new Date();
        // Start from yesterday (not today) and go back
        date.setDate(date.getDate() - 1 - timeframe + i + 1);
        // Format as YYYY-MM-DD without timezone conversion to match Shopify dates
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const isoDateKey = `${year}-${month}-${day}`;
        dailyDataMap.set(isoDateKey, { 
          impressions: 0, 
          clicks: 0, 
          spend: 0, 
          adRevenue: 0,
          ecommerceRevenue: 0,
          conversions: 0 
        });
      }
      
      // Track data availability metadata (for platforms with lagging daily data)
      let metaLastBreakdownDate: string | null = null;
      
      // Add Meta Ads daily data
      const metaConnection = connectedPlatforms.find(c => c.platform === 'Meta Ads');
      if (metaConnection) {
        // Get Meta's currency from the platform data we already fetched
        const metaPlatformData = currentPeriod.platformData.find(p => p.platform === 'Meta Ads');
        const metaCurrency = metaPlatformData?.originalCurrency || baseCurrency;
        
        const metaDailyData = await fetchMetaAdsDailyData(metaConnection.credentials, timeframe, 0);
        for (const day of metaDailyData) {
          const convertedRevenue = convertCurrency(day.revenue, metaCurrency, baseCurrency);
          const convertedSpend = convertCurrency(day.spend, metaCurrency, baseCurrency);
          
          if (convertedRevenue !== null && convertedSpend !== null) {
            // Meta now returns ISO date directly in day.date (YYYY-MM-DD)
            const isoDateKey = day.date;
            const existing = dailyDataMap.get(isoDateKey);
            
            if (existing) {
              dailyDataMap.set(isoDateKey, {
                impressions: existing.impressions + day.impressions,
                clicks: existing.clicks + day.clicks,
                spend: existing.spend + convertedSpend,
                adRevenue: existing.adRevenue + convertedRevenue,
                ecommerceRevenue: existing.ecommerceRevenue,
                conversions: existing.conversions + day.conversions,
              });
            }
          }
        }
        console.log(`  ✓ Added Meta Ads daily data (${metaDailyData.length} days)`);
        
        // Track last date with actual Meta daily breakdown data
        // Meta's daily breakdown lags 3-7 days behind aggregate endpoint
        metaLastBreakdownDate = metaDailyData.length > 0 
          ? metaDailyData[metaDailyData.length - 1].date 
          : null;
        
        if (metaLastBreakdownDate) {
          const requestedEndDate = Array.from(dailyDataMap.keys()).sort().pop();
          console.log(`  ℹ️  Meta daily breakdown available through: ${metaLastBreakdownDate} (requested through: ${requestedEndDate})`);
        }
      }
      
      // Add Shopify daily data from cached data (avoids second API call)
      const shopifyPlatformData = currentPeriod.platformData.find(p => p.platform === 'Shopify');
      if (shopifyPlatformData && shopifyPlatformData.dailyData) {
        const shopifyDailyData = shopifyPlatformData.dailyData;
        
        for (const day of shopifyDailyData) {
          // Shopify data already uses ISO format (YYYY-MM-DD)
          const isoDateKey = day.date;
          
          const convertedRevenue = convertCurrency(day.revenue, day.currency, baseCurrency);
          
          if (convertedRevenue !== null) {
            const existing = dailyDataMap.get(isoDateKey);
            // Only update existing entries - don't create new ones outside initialized timeframe (excludes today)
            if (existing) {
              dailyDataMap.set(isoDateKey, {
                impressions: existing.impressions,
                clicks: existing.clicks,
                spend: existing.spend,
                adRevenue: existing.adRevenue,
                ecommerceRevenue: existing.ecommerceRevenue + convertedRevenue,
                conversions: existing.conversions + day.orders,
              });
            }
          }
        }
        console.log(`  ✓ Added Shopify daily data (${shopifyDailyData.length} days) from cache`);
      }
      
      // Convert map to sorted array and transform to display format
      const chartData = Array.from(dailyDataMap.entries())
        .sort((a, b) => a[0].localeCompare(b[0])) // Sort by ISO date string (YYYY-MM-DD)
        .map(([isoDate, data]) => {
          // Convert ISO date to display format for client
          const displayDate = new Date(isoDate + 'T00:00:00').toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric' 
          });
          return {
            isoDate, // ISO format for reliable parsing (e.g., "2025-11-04")
            date: displayDate, // Display format for charts: "Nov 4"
            impressions: data.impressions,
            clicks: data.clicks,
            spend: data.spend,
            revenue: data.adRevenue + data.ecommerceRevenue, // Total revenue for charts
            adRevenue: data.adRevenue, // Separate ad revenue for ROAS
            conversions: data.conversions,
            roas: data.spend > 0 ? data.adRevenue / data.spend : 0, // ROAS uses only ad revenue
          };
        });
      
      console.log(`  ✓ Generated chart data for ${chartData.length} days`);
      
      // Generate trends from actual chart data (last 7 days)
      const trendPoints = Math.min(7, chartData.length);
      const recentChartData = chartData.slice(-trendPoints);
      
      // Get platform sources for each metric
      const adPlatformNames = currentPeriod.platformData.filter(p => p.platformType === 'ad').map(p => p.platform);
      const ecommercePlatformNames = currentPeriod.platformData.filter(p => p.platformType === 'ecommerce').map(p => p.platform);
      
      // Calculate derived metrics
      const costPerOrder = currentPeriod.totals.spend > 0 && currentPeriod.totals.adConversions > 0 
        ? currentPeriod.totals.spend / currentPeriod.totals.adConversions 
        : 0;
      const linkCtr = currentPeriod.totals.impressions > 0 && currentPeriod.totals.linkClicks > 0
        ? (currentPeriod.totals.linkClicks / currentPeriod.totals.impressions) * 100 
        : 0;
      const costPerLinkClick = currentPeriod.totals.spend > 0 && currentPeriod.totals.linkClicks > 0
        ? currentPeriod.totals.spend / currentPeriod.totals.linkClicks
        : 0;
      
      // Calculate e-commerce metrics
      const avgOrderValue = currentPeriod.totals.ecommerceOrders > 0
        ? currentPeriod.totals.ecommerceRevenue / currentPeriod.totals.ecommerceOrders
        : 0;
      
      const response = {
        // Existing metrics
        impressions: { 
          value: currentPeriod.totals.impressions, 
          change: changes.impressions, 
          trend: recentChartData.map(d => ({ date: d.date, value: d.impressions })),
          platforms: adPlatformNames,
        },
        clicks: { 
          value: currentPeriod.totals.clicks, 
          change: changes.clicks, 
          trend: recentChartData.map(d => ({ date: d.date, value: d.clicks })),
          platforms: adPlatformNames,
        },
        spend: {
          value: currentPeriod.totals.spend,
          change: changes.spend,
          trend: recentChartData.map(d => ({ date: d.date, value: d.spend })),
          platforms: adPlatformNames,
        },
        // Split revenue into ad revenue and e-commerce revenue
        adRevenue: {
          value: currentPeriod.totals.adRevenue,
          change: calculateChange(currentPeriod.totals.adRevenue, previousPeriod.totals.adRevenue),
          trend: recentChartData.map(d => ({ date: d.date, value: d.adRevenue })), // Use ad revenue only
          platforms: adPlatformNames,
        },
        ecommerceRevenue: {
          value: currentPeriod.totals.ecommerceRevenue,
          change: calculateChange(currentPeriod.totals.ecommerceRevenue, previousPeriod.totals.ecommerceRevenue),
          trend: [],
          platforms: ecommercePlatformNames,
        },
        roas: { 
          value: parseFloat(currentPeriod.roas.toFixed(1)), 
          change: changes.roas, 
          trend: recentChartData.map(d => ({ date: d.date, value: d.roas })),
          platforms: adPlatformNames,
        },
        ctr: {
          value: parseFloat(currentPeriod.ctr.toFixed(2)),
          change: changes.ctr,
          trend: recentChartData.map(d => ({ 
            date: d.date, 
            value: d.impressions > 0 ? parseFloat(((d.clicks / d.impressions) * 100).toFixed(2)) : 0 
          })),
          platforms: adPlatformNames,
        },
        
        // Split purchases into ad conversions and e-commerce orders
        adConversions: {
          value: currentPeriod.totals.adConversions,
          change: calculateChange(currentPeriod.totals.adConversions, previousPeriod.totals.adConversions),
          trend: recentChartData.map(d => ({ date: d.date, value: d.conversions })),
          platforms: adPlatformNames,
        },
        ecommerceOrders: {
          value: currentPeriod.totals.ecommerceOrders,
          change: calculateChange(currentPeriod.totals.ecommerceOrders, previousPeriod.totals.ecommerceOrders),
          trend: [],
          platforms: ecommercePlatformNames,
        },
        
        // New ad platform metrics
        reach: {
          value: currentPeriod.totals.reach,
          change: calculateChange(currentPeriod.totals.reach, previousPeriod.totals.reach),
          trend: [],
          platforms: adPlatformNames,
        },
        frequency: {
          value: parseFloat(currentPeriod.totals.frequency.toFixed(2)),
          change: calculateChange(currentPeriod.totals.frequency, previousPeriod.totals.frequency),
          trend: [],
          platforms: adPlatformNames,
        },
        linkClicks: {
          value: currentPeriod.totals.linkClicks,
          change: calculateChange(currentPeriod.totals.linkClicks, previousPeriod.totals.linkClicks),
          trend: [],
          platforms: adPlatformNames,
        },
        cpm: {
          value: parseFloat(currentPeriod.totals.cpm.toFixed(2)),
          change: calculateChange(currentPeriod.totals.cpm, previousPeriod.totals.cpm),
          trend: [],
          platforms: adPlatformNames,
        },
        costPerOrder: {
          value: parseFloat(costPerOrder.toFixed(2)),
          change: calculateChange(
            costPerOrder,
            previousPeriod.totals.spend > 0 && previousPeriod.totals.adConversions > 0 
              ? previousPeriod.totals.spend / previousPeriod.totals.adConversions 
              : 0
          ),
          trend: [],
          platforms: adPlatformNames,
        },
        linkCtr: {
          value: parseFloat(linkCtr.toFixed(2)),
          change: calculateChange(
            linkCtr,
            previousPeriod.totals.impressions > 0 && previousPeriod.totals.linkClicks > 0
              ? (previousPeriod.totals.linkClicks / previousPeriod.totals.impressions) * 100
              : 0
          ),
          trend: [],
          platforms: adPlatformNames,
        },
        costPerLinkClick: {
          value: parseFloat(costPerLinkClick.toFixed(2)),
          change: calculateChange(
            costPerLinkClick,
            previousPeriod.totals.spend > 0 && previousPeriod.totals.linkClicks > 0
              ? previousPeriod.totals.spend / previousPeriod.totals.linkClicks
              : 0
          ),
          trend: [],
          platforms: adPlatformNames,
        },
        
        // New e-commerce metrics
        conversionRate: {
          value: currentPeriod.conversionRate !== null ? parseFloat(currentPeriod.conversionRate.toFixed(2)) : 0,
          change: changes.conversionRate,
          trend: [],
          platforms: ecommercePlatformNames,
          hasSessionData: currentPeriod.conversionRate !== null, // Flag to differentiate missing data vs 0%
        },
        avgOrderValue: {
          value: parseFloat(avgOrderValue.toFixed(2)),
          change: calculateChange(
            avgOrderValue,
            previousPeriod.totals.ecommerceOrders > 0
              ? previousPeriod.totals.ecommerceRevenue / previousPeriod.totals.ecommerceOrders
              : 0
          ),
          trend: [],
          platforms: ecommercePlatformNames,
        },
        
        chartData,
        platformData: currentPeriod.platformData,
        baseCurrency,
        
        // Data availability metadata for transparency about lagging platform data
        dataAvailability: {
          metaLastBreakdownDate, // Last date with actual Meta daily breakdown (null if no Meta data)
          totalDaysRequested: timeframe,
          dailyDataCount: chartData.length,
        },
      };
      
      res.json(response);
    } catch (error) {
      console.error("Dashboard metrics error:", error);
      res.status(500).json({ error: "Failed to fetch dashboard metrics" });
    }
  });

  // Top performing ads endpoint
  app.get("/api/metrics/top-ads", async (req, res) => {
    try {
      const { fetchTopPerformingAds } = await import("./services/platform-data");
      const { convertCurrency } = await import("./services/currency");
      
      const clientId = req.query.clientId as string;
      const timeframe = parseInt(req.query.timeframe as string) || 30;
      const limit = parseInt(req.query.limit as string) || 10;
      
      if (!clientId) {
        return res.status(400).json({ error: "Client ID is required" });
      }
      
      // Get client to access base currency
      const client = await storage.getClient(clientId);
      if (!client) {
        return res.status(404).json({ error: "Client not found" });
      }
      const baseCurrency = client.baseCurrency;
      
      // Get connected platforms for this client  
      const connections = await storage.getAllPlatformConnections();
      const metaConnection = connections.find(c => 
        c.platform === "Meta Ads" && c.isConnected && c.clientId === clientId
      );
      
      let topAds = [];
      
      if (metaConnection) {
        console.log(`📊 Fetching top performing ads for client ${clientId} (${timeframe} days, limit ${limit})`);
        topAds = await fetchTopPerformingAds(metaConnection.credentials, timeframe, limit);
      } else {
        console.log(`📊 No Meta Ads connection found for client ${clientId}, using demo data`);
        topAds = await fetchTopPerformingAds(undefined, timeframe, limit);
      }
      
      // Convert spend to client's base currency
      // Meta Ads returns data in account currency (typically USD or the account's currency)
      const platformCurrency = (metaConnection?.credentials as any)?.currency || 'USD';
      const convertedAds = topAds.map(ad => {
        const convertedSpend = convertCurrency(ad.metrics.spend, platformCurrency, baseCurrency);
        
        if (convertedSpend === null) {
          console.error(`  ❌ Top ad spend conversion failed for ad ${ad.id}: ${ad.metrics.spend} ${platformCurrency} to ${baseCurrency} - zeroing spend`);
          // Zero out spend to avoid returning platform currency labeled as base currency
          return {
            ...ad,
            metrics: {
              ...ad.metrics,
              spend: 0,
            }
          };
        }
        
        return {
          ...ad,
          metrics: {
            ...ad.metrics,
            spend: convertedSpend,
          }
        };
      });
      
      res.json({
        ads: convertedAds,
        baseCurrency,
      });
    } catch (error) {
      console.error("Top ads error:", error);
      res.status(500).json({ error: "Failed to fetch top performing ads" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
