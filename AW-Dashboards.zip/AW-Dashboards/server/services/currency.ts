// Currency conversion service
// In production, this would use a real exchange rate API like fixer.io or exchangerate-api.com

interface ExchangeRates {
  [key: string]: number;
}

// Mock exchange rates (USD base)
// In production, this should be fetched from a real exchange rate API like exchangerate-api.com
// Covers all major Shopify-supported currencies
const exchangeRates: ExchangeRates = {
  // Americas
  USD: 1.0,     // US Dollar
  CAD: 1.36,    // Canadian Dollar
  BRL: 4.98,    // Brazilian Real
  MXN: 17.1,    // Mexican Peso
  CLP: 950,     // Chilean Peso
  COP: 4100,    // Colombian Peso
  ARS: 850,     // Argentine Peso
  PEN: 3.75,    // Peruvian Sol
  UYU: 39.5,    // Uruguayan Peso
  BOB: 6.91,    // Bolivian Boliviano
  
  // Europe
  EUR: 0.92,    // Euro
  GBP: 0.79,    // British Pound
  CHF: 0.88,    // Swiss Franc
  SEK: 10.5,    // Swedish Krona
  NOK: 10.8,    // Norwegian Krone
  DKK: 6.86,    // Danish Krone
  PLN: 4.02,    // Polish Zloty
  CZK: 22.8,    // Czech Koruna
  HUF: 360,     // Hungarian Forint
  RON: 4.57,    // Romanian Leu
  BGN: 1.80,    // Bulgarian Lev
  HRK: 6.95,    // Croatian Kuna
  ISK: 135,     // Icelandic Króna
  TRY: 32.5,    // Turkish Lira
  RUB: 92.0,    // Russian Ruble
  UAH: 36.7,    // Ukrainian Hryvnia
  
  // Middle East & Africa
  AED: 3.67,    // UAE Dirham
  SAR: 3.75,    // Saudi Riyal
  QAR: 3.64,    // Qatari Riyal
  KWD: 0.31,    // Kuwaiti Dinar
  BHD: 0.38,    // Bahraini Dinar
  OMR: 0.38,    // Omani Rial
  JOD: 0.71,    // Jordanian Dinar
  ILS: 3.72,    // Israeli Shekel
  EGP: 30.9,    // Egyptian Pound
  ZAR: 18.5,    // South African Rand
  MAD: 10.1,    // Moroccan Dirham
  NGN: 790,     // Nigerian Naira
  KES: 129,     // Kenyan Shilling
  GHS: 12.8,    // Ghanaian Cedi
  
  // Asia-Pacific
  JPY: 149.5,   // Japanese Yen
  CNY: 7.24,    // Chinese Yuan
  INR: 83.2,    // Indian Rupee
  SGD: 1.34,    // Singapore Dollar
  HKD: 7.83,    // Hong Kong Dollar
  KRW: 1320,    // South Korean Won
  THB: 35.0,    // Thai Baht
  MYR: 4.72,    // Malaysian Ringgit
  IDR: 15700,   // Indonesian Rupiah
  PHP: 56.5,    // Philippine Peso
  VND: 24500,   // Vietnamese Dong
  TWD: 31.5,    // Taiwan Dollar
  AUD: 1.52,    // Australian Dollar
  NZD: 1.65,    // New Zealand Dollar
  BDT: 110,     // Bangladeshi Taka
  PKR: 278,     // Pakistani Rupee
  LKR: 305,     // Sri Lankan Rupee
  NPR: 133,     // Nepalese Rupee
  MMK: 2100,    // Myanmar Kyat
  KHR: 4050,    // Cambodian Riel
  LAK: 21500,   // Lao Kip
  
  // Additional currencies
  XAF: 605,     // Central African CFA Franc
  XOF: 605,     // West African CFA Franc
  TND: 3.12,    // Tunisian Dinar
  DZD: 135,     // Algerian Dinar
  AOA: 850,     // Angolan Kwanza
  ETB: 56.0,    // Ethiopian Birr
  UGX: 3750,    // Ugandan Shilling
  TZS: 2520,    // Tanzanian Shilling
  MUR: 45.5,    // Mauritian Rupee
  RWF: 1280,    // Rwandan Franc
  ZMW: 22.5,    // Zambian Kwacha
  BWP: 13.5,    // Botswana Pula
  NAD: 18.5,    // Namibian Dollar
  SZL: 18.5,    // Swazi Lilangeni
  LSL: 18.5,    // Lesotho Loti
  MWK: 1730,    // Malawian Kwacha
  MZN: 63.8,    // Mozambican Metical
  CDF: 2800,    // Congolese Franc
  GMD: 63.0,    // Gambian Dalasi
  ALL: 95.0,    // Albanian Lek
  BAM: 1.80,    // Bosnia-Herzegovina Convertible Mark
  MKD: 56.5,    // Macedonian Denar
  RSD: 108,     // Serbian Dinar
  GEL: 2.68,    // Georgian Lari
  AMD: 390,     // Armenian Dram
  AZN: 1.70,    // Azerbaijani Manat
  KZT: 465,     // Kazakhstani Tenge
  UZS: 12500,   // Uzbekistani Som
  KGS: 87.0,    // Kyrgyzstani Som
  TJS: 10.9,    // Tajikistani Somoni
  TMT: 3.50,    // Turkmenistani Manat
  AFN: 70.0,    // Afghan Afghani
  IQD: 1310,    // Iraqi Dinar
  YER: 250,     // Yemeni Rial
  SYP: 2512,    // Syrian Pound
  LBP: 89500,   // Lebanese Pound
};

export function convertCurrency(
  amount: number,
  fromCurrency: string,
  toCurrency: string
): number | null {
  if (fromCurrency === toCurrency) {
    return amount;
  }

  const fromKey = fromCurrency.toUpperCase();
  const toKey = toCurrency.toUpperCase();

  // Check if rates are available - return null to signal conversion failure
  if (!exchangeRates[fromKey]) {
    console.error(`❌ Currency conversion failed: Unknown source currency "${fromCurrency}"`);
    return null;
  }

  if (!exchangeRates[toKey]) {
    console.error(`❌ Currency conversion failed: Unknown target currency "${toCurrency}"`);
    return null;
  }

  const fromRate = exchangeRates[fromKey];
  const toRate = exchangeRates[toKey];

  // Convert to USD first, then to target currency
  const usdAmount = amount / fromRate;
  const converted = usdAmount * toRate;
  
  return converted;
}

export function formatCurrency(amount: number, currency: string): string {
  const symbols: { [key: string]: string } = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    CAD: "C$",
    AUD: "A$",
    JPY: "¥",
    CNY: "¥",
    INR: "₹",
    BRL: "R$",
    MXN: "$",
    EGP: "E£",
    AED: "د.إ",
    SAR: "﷼",
  };

  const symbol = symbols[currency.toUpperCase()] || currency;
  return `${symbol}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
