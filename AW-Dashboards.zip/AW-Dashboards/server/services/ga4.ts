import { BetaAnalyticsDataClient } from '@google-analytics/data';

export interface GA4SessionData {
  sessions: number;
  users: number;
  newUsers: number;
  bounceRate: number;
  avgSessionDuration: number;
}

/**
 * Fetch session data from Google Analytics 4 for a specific date range
 * @param credentials - Service account credentials JSON
 * @param propertyId - GA4 property ID (format: properties/123456789)
 * @param startDate - Start date in YYYY-MM-DD format
 * @param endDate - End date in YYYY-MM-DD format
 */
export async function fetchGA4Sessions(
  credentials: any,
  propertyId: string,
  startDate: string,
  endDate: string
): Promise<GA4SessionData> {
  try {
    console.log(`📊 Fetching GA4 session data for ${propertyId} from ${startDate} to ${endDate}`);
    
    // Initialize the analytics client with service account credentials
    const analyticsDataClient = new BetaAnalyticsDataClient({
      credentials: {
        client_email: credentials.client_email,
        private_key: credentials.private_key,
      },
    });

    // Make sure property ID is in correct format
    const formattedPropertyId = propertyId.startsWith('properties/') 
      ? propertyId 
      : `properties/${propertyId}`;

    // Run the report
    const [response] = await analyticsDataClient.runReport({
      property: formattedPropertyId,
      dateRanges: [
        {
          startDate,
          endDate,
        },
      ],
      metrics: [
        { name: 'sessions' },
        { name: 'totalUsers' },
        { name: 'newUsers' },
        { name: 'bounceRate' },
        { name: 'averageSessionDuration' },
      ],
    });

    // Extract metrics from response
    const row = response.rows?.[0];
    if (!row || !row.metricValues) {
      console.warn('  ⚠️ No GA4 data returned for date range');
      return {
        sessions: 0,
        users: 0,
        newUsers: 0,
        bounceRate: 0,
        avgSessionDuration: 0,
      };
    }

    const sessions = parseInt(row.metricValues[0].value || '0');
    const users = parseInt(row.metricValues[1].value || '0');
    const newUsers = parseInt(row.metricValues[2].value || '0');
    const bounceRate = parseFloat(row.metricValues[3].value || '0');
    const avgSessionDuration = parseFloat(row.metricValues[4].value || '0');

    console.log(`  ✅ GA4 Sessions: ${sessions.toLocaleString()}`);
    console.log(`  ✅ GA4 Users: ${users.toLocaleString()}`);

    return {
      sessions,
      users,
      newUsers,
      bounceRate,
      avgSessionDuration,
    };
  } catch (error: any) {
    console.error('  ❌ GA4 API error:', error.message);
    
    // Return zeros on error so we can still show the dashboard
    return {
      sessions: 0,
      users: 0,
      newUsers: 0,
      bounceRate: 0,
      avgSessionDuration: 0,
    };
  }
}

/**
 * Fetch daily session data from Google Analytics 4
 * @param credentials - Service account credentials JSON
 * @param propertyId - GA4 property ID (format: properties/123456789)
 * @param startDate - Start date in YYYY-MM-DD format
 * @param endDate - End date in YYYY-MM-DD format
 */
export async function fetchGA4DailySessions(
  credentials: any,
  propertyId: string,
  startDate: string,
  endDate: string
): Promise<{ date: string; sessions: number }[]> {
  try {
    console.log(`📊 Fetching GA4 daily session data for ${propertyId}`);
    
    const analyticsDataClient = new BetaAnalyticsDataClient({
      credentials: {
        client_email: credentials.client_email,
        private_key: credentials.private_key,
      },
    });

    const formattedPropertyId = propertyId.startsWith('properties/') 
      ? propertyId 
      : `properties/${propertyId}`;

    const [response] = await analyticsDataClient.runReport({
      property: formattedPropertyId,
      dateRanges: [
        {
          startDate,
          endDate,
        },
      ],
      dimensions: [
        { name: 'date' },
      ],
      metrics: [
        { name: 'sessions' },
      ],
      orderBys: [
        {
          dimension: {
            dimensionName: 'date',
          },
        },
      ],
    });

    if (!response.rows || response.rows.length === 0) {
      console.warn('  ⚠️ No GA4 daily data returned');
      return [];
    }

    const dailyData = response.rows.map(row => {
      const dateStr = row.dimensionValues?.[0].value || '';
      const sessions = parseInt(row.metricValues?.[0].value || '0');
      
      // Convert YYYYMMDD to YYYY-MM-DD
      const formattedDate = dateStr.replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');
      
      return {
        date: formattedDate,
        sessions,
      };
    });

    console.log(`  ✅ Fetched ${dailyData.length} days of GA4 session data`);
    return dailyData;
  } catch (error: any) {
    console.error('  ❌ GA4 daily data error:', error.message);
    return [];
  }
}
