import { db } from "../db";
import { monthlyPlatformMetrics, monthlyClientRollups, dataSyncJobs, clients, platformConnections } from "../../shared/schema";
import { eq, and } from "drizzle-orm";
import { fetchMetaAdsData, fetchShopifyData } from "./platform-data";
import { convertCurrency } from "./currency";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";
import { storage } from "../storage";

// Helper to get the last day of a month in YYYY-MM-DD format
function getMonthEndDate(year: number, month: number): string {
  const date = new Date(year, month, 1);
  return format(endOfMonth(date), 'yyyy-MM-dd');
}

// Helper to get date range for a month
function getMonthDateRange(year: number, month: number) {
  const date = new Date(year, month, 1);
  return {
    start: format(startOfMonth(date), 'yyyy-MM-dd'),
    end: format(endOfMonth(date), 'yyyy-MM-dd'),
  };
}

interface PlatformMonthlyData {
  platform: string;
  platformType: 'ad' | 'ecommerce';
  currency: string;
  originalCurrency?: string;
  impressions: number;
  clicks: number;
  spend: number;
  revenue: number;
  conversions: number;
  orders: number;
  sessions: number;
  reach: number;
  frequency: number;
  linkClicks: number;
  cpm: number;
}

// Fetch and aggregate Meta Ads data for a specific month
async function aggregateMetaAdsMonth(
  credentials: any,
  year: number,
  month: number,
  baseCurrency: string
): Promise<PlatformMonthlyData | null> {
  try {
    // Calculate days and offset for the specific month
    const now = new Date();
    const monthDate = new Date(year, month, 1);
    const monthEnd = endOfMonth(monthDate);
    const daysInMonth = monthEnd.getDate();
    
    // Calculate days offset from today to the END of the target month
    const daysOffset = Math.floor((now.getTime() - monthEnd.getTime()) / (1000 * 60 * 60 * 24));
    
    const data = await fetchMetaAdsData(credentials, daysInMonth, daysOffset);

    if (!data) {
      return null;
    }

    // Convert spend and revenue to base currency
    const spendInBase = await convertCurrency(
      data.spend,
      data.currency || 'USD',
      baseCurrency
    );
    const revenueInBase = await convertCurrency(
      data.revenue,
      data.currency || 'USD',
      baseCurrency
    );

    return {
      platform: 'Meta Ads',
      platformType: 'ad',
      currency: baseCurrency,
      originalCurrency: data.currency,
      impressions: data.impressions,
      clicks: data.clicks,
      spend: spendInBase || 0,
      revenue: revenueInBase || 0,
      conversions: data.conversions,
      orders: 0,
      sessions: 0,
      reach: data.reach || 0,
      frequency: data.frequency || 0,
      linkClicks: data.linkClicks || 0,
      cpm: data.cpm || 0,
    };
  } catch (error) {
    console.error(`❌ Failed to aggregate Meta Ads for ${year}-${month + 1}:`, error);
    return null;
  }
}

// Fetch and aggregate Shopify data for a specific month
async function aggregateShopifyMonth(
  credentials: any,
  year: number,
  month: number,
  baseCurrency: string
): Promise<PlatformMonthlyData | null> {
  try {
    // Calculate days and offset for the specific month
    const now = new Date();
    const monthDate = new Date(year, month, 1);
    const monthEnd = endOfMonth(monthDate);
    const daysInMonth = monthEnd.getDate();
    
    // Calculate days offset from today to the END of the target month
    const daysOffset = Math.floor((now.getTime() - monthEnd.getTime()) / (1000 * 60 * 60 * 24));
    
    const data = await fetchShopifyData(credentials, daysInMonth, daysOffset);

    // Convert revenue to base currency (Shopify returns revenue in shop currency)
    const revenueInBase = await convertCurrency(
      data.revenue,
      data.currency,
      baseCurrency
    );

    return {
      platform: 'Shopify',
      platformType: 'ecommerce',
      currency: baseCurrency,
      originalCurrency: data.currency,
      impressions: 0,
      clicks: 0,
      spend: 0,
      revenue: revenueInBase || 0,
      conversions: 0,
      orders: data.orders,
      sessions: data.sessions,
      reach: 0,
      frequency: 0,
      linkClicks: 0,
      cpm: 0,
    };
  } catch (error) {
    console.error(`❌ Failed to aggregate Shopify for ${year}-${month + 1}:`, error);
    return null;
  }
}

// Store monthly platform metrics in database
async function storePlatformMetrics(
  clientId: string,
  monthEndDate: string,
  platformData: PlatformMonthlyData
) {
  await db.insert(monthlyPlatformMetrics)
    .values({
      clientId,
      platform: platformData.platform,
      platformType: platformData.platformType,
      monthEndDate,
      currency: platformData.currency,
      originalCurrency: platformData.originalCurrency || platformData.currency,
      impressions: platformData.impressions.toString(),
      clicks: platformData.clicks.toString(),
      spend: platformData.spend.toString(),
      revenue: platformData.revenue.toString(),
      conversions: platformData.conversions.toString(),
      orders: platformData.orders.toString(),
      sessions: platformData.sessions.toString(),
      reach: platformData.reach.toString(),
      frequency: platformData.frequency.toString(),
      linkClicks: platformData.linkClicks.toString(),
      cpm: platformData.cpm.toString(),
    })
    .onConflictDoUpdate({
      target: [monthlyPlatformMetrics.clientId, monthlyPlatformMetrics.platform, monthlyPlatformMetrics.monthEndDate],
      set: {
        impressions: platformData.impressions.toString(),
        clicks: platformData.clicks.toString(),
        spend: platformData.spend.toString(),
        revenue: platformData.revenue.toString(),
        conversions: platformData.conversions.toString(),
        orders: platformData.orders.toString(),
        sessions: platformData.sessions.toString(),
        reach: platformData.reach.toString(),
        frequency: platformData.frequency.toString(),
        linkClicks: platformData.linkClicks.toString(),
        cpm: platformData.cpm.toString(),
        aggregatedAt: new Date(),
      },
    });
}

// Calculate and store client-level rollups for a month
async function calculateClientRollups(clientId: string, monthEndDate: string, currency: string) {
  // Get all platform metrics for this month
  const platformMetrics = await db
    .select()
    .from(monthlyPlatformMetrics)
    .where(
      and(
        eq(monthlyPlatformMetrics.clientId, clientId),
        eq(monthlyPlatformMetrics.monthEndDate, monthEndDate)
      )
    );

  // Separate ad platforms and ecommerce platforms
  const adMetrics = platformMetrics.filter((m: any) => m.platformType === 'ad');
  const ecommerceMetrics = platformMetrics.filter((m: any) => m.platformType === 'ecommerce');

  // Calculate ad rollup
  const adRollup = {
    impressions: adMetrics.reduce((sum: number, m: any) => sum + parseFloat(m.impressions || '0'), 0),
    clicks: adMetrics.reduce((sum: number, m: any) => sum + parseFloat(m.clicks || '0'), 0),
    spend: adMetrics.reduce((sum: number, m: any) => sum + parseFloat(m.spend || '0'), 0),
    revenue: adMetrics.reduce((sum: number, m: any) => sum + parseFloat(m.revenue || '0'), 0),
    conversions: adMetrics.reduce((sum: number, m: any) => sum + parseFloat(m.conversions || '0'), 0),
    roas: 0,
    cpo: 0,
    cpm: 0,
  };
  adRollup.roas = adRollup.spend > 0 ? adRollup.revenue / adRollup.spend : 0;
  adRollup.cpo = adRollup.conversions > 0 ? adRollup.spend / adRollup.conversions : 0;
  adRollup.cpm = adRollup.impressions > 0 ? (adRollup.spend / adRollup.impressions) * 1000 : 0;

  // Calculate ecommerce rollup
  const ecommerceRollup = {
    revenue: ecommerceMetrics.reduce((sum: number, m: any) => sum + parseFloat(m.revenue || '0'), 0),
    orders: ecommerceMetrics.reduce((sum: number, m: any) => sum + parseFloat(m.orders || '0'), 0),
    sessions: ecommerceMetrics.reduce((sum: number, m: any) => sum + parseFloat(m.sessions || '0'), 0),
    aov: 0,
  };
  ecommerceRollup.aov = ecommerceRollup.orders > 0 ? ecommerceRollup.revenue / ecommerceRollup.orders : 0;

  // Calculate combined rollup
  const combinedRollup = {
    impressions: adRollup.impressions,
    clicks: adRollup.clicks,
    spend: adRollup.spend,
    revenue: adRollup.revenue + ecommerceRollup.revenue,
    conversions: adRollup.conversions + ecommerceRollup.orders,
    orders: ecommerceRollup.orders,
    sessions: ecommerceRollup.sessions,
    roas: adRollup.roas,
    cpo: adRollup.cpo,
    aov: ecommerceRollup.aov,
    cpm: adRollup.cpm,
  };

  // Store all three rollups
  const rollups: Array<{
    platformType: string;
    impressions: number;
    clicks: number;
    spend: number;
    revenue: number;
    conversions: number;
    orders: number;
    sessions: number;
    roas: number;
    cpo: number;
    aov: number;
    cpm: number;
  }> = [
    { platformType: 'ad', ...adRollup, orders: 0, sessions: 0, aov: 0 },
    { platformType: 'ecommerce', ...ecommerceRollup, impressions: 0, clicks: 0, spend: 0, conversions: 0, roas: 0, cpo: 0, cpm: 0 },
    { platformType: 'combined', ...combinedRollup },
  ];

  for (const rollup of rollups) {
    await db.insert(monthlyClientRollups)
      .values({
        clientId,
        platformType: rollup.platformType,
        monthEndDate,
        currency,
        impressions: rollup.impressions.toString(),
        clicks: rollup.clicks.toString(),
        spend: rollup.spend.toString(),
        revenue: rollup.revenue.toString(),
        conversions: rollup.conversions.toString(),
        orders: rollup.orders.toString(),
        sessions: rollup.sessions.toString(),
        roas: rollup.roas.toString(),
        cpo: rollup.cpo.toString(),
        aov: rollup.aov.toString(),
        cpm: rollup.cpm.toString(),
      })
      .onConflictDoUpdate({
        target: [monthlyClientRollups.clientId, monthlyClientRollups.platformType, monthlyClientRollups.monthEndDate],
        set: {
          impressions: rollup.impressions.toString(),
          clicks: rollup.clicks.toString(),
          spend: rollup.spend.toString(),
          revenue: rollup.revenue.toString(),
          conversions: rollup.conversions.toString(),
          orders: rollup.orders.toString(),
          sessions: rollup.sessions.toString(),
          roas: rollup.roas.toString(),
          cpo: rollup.cpo.toString(),
          aov: rollup.aov.toString(),
          cpm: rollup.cpm.toString(),
          aggregatedAt: new Date(),
        },
      });
  }
}

// Main function to backfill historical data for a client
export async function backfillClientMonthlyData(clientId: string, monthsToBackfill: number = 14) {
  console.log(`\n🔄 Starting backfill for client ${clientId} (${monthsToBackfill} months)`);

  // Create job record
  const now = new Date();
  const jobResult = await db.insert(dataSyncJobs).values({
    clientId,
    jobType: 'initial_backfill',
    status: 'running',
    startedAt: now,
  }).returning();
  const jobId = jobResult[0].id;

  try {
    // Get client and their platform connections
    const client = await db.select().from(clients).where(eq(clients.id, clientId)).limit(1);
    if (!client || client.length === 0) {
      throw new Error('Client not found');
    }
    const baseCurrency = client[0].baseCurrency;

    const connections = await db
      .select()
      .from(platformConnections)
      .where(and(
        eq(platformConnections.clientId, clientId),
        eq(platformConnections.isConnected, true)
      ));

    if (connections.length === 0) {
      throw new Error('No connected platforms found');
    }

    // Process each of the last N months
    const today = new Date();
    for (let i = 1; i <= monthsToBackfill; i++) {
      const monthDate = subMonths(today, i);
      const year = monthDate.getFullYear();
      const month = monthDate.getMonth();
      const monthEndDate = getMonthEndDate(year, month);

      console.log(`  📅 Processing ${format(monthDate, 'MMMM yyyy')} (${monthEndDate})`);

      // Process each connected platform
      for (const connection of connections) {
        if (connection.platform === 'Meta Ads' && connection.credentials) {
          const data = await aggregateMetaAdsMonth(
            connection.credentials,
            year,
            month,
            baseCurrency
          );
          if (data) {
            await storePlatformMetrics(clientId, monthEndDate, data);
            console.log(`    ✅ Meta Ads: ${data.conversions} conversions, $${data.spend.toFixed(2)} spend`);
          }
        } else if (connection.platform === 'Shopify' && connection.credentials) {
          const data = await aggregateShopifyMonth(
            connection.credentials,
            year,
            month,
            baseCurrency
          );
          if (data) {
            await storePlatformMetrics(clientId, monthEndDate, data);
            console.log(`    ✅ Shopify: ${data.orders} orders, $${data.revenue.toFixed(2)} revenue`);
          }
        }
      }

      // Calculate and store rollups for this month
      await calculateClientRollups(clientId, monthEndDate, baseCurrency);
    }

    // Mark job as completed
    await db.update(dataSyncJobs)
      .set({
        status: 'completed',
        completedAt: new Date(),
      })
      .where(eq(dataSyncJobs.id, jobId));

    console.log(`✅ Backfill completed successfully for client ${clientId}\n`);
    return { success: true, jobId };
  } catch (error) {
    console.error(`❌ Backfill failed for client ${clientId}:`, error);
    
    // Mark job as failed
    await db.update(dataSyncJobs)
      .set({
        status: 'failed',
        errorMessage: error instanceof Error ? error.message : 'Unknown error',
        completedAt: new Date(),
      })
      .where(eq(dataSyncJobs.id, jobId));

    throw error;
  }
}

// Get monthly metrics for a client (latest 14 months)
export async function getClientMonthlyMetrics(clientId: string) {
  const rollups = await db
    .select()
    .from(monthlyClientRollups)
    .where(eq(monthlyClientRollups.clientId, clientId))
    .orderBy(monthlyClientRollups.monthEndDate);

  // Get latest 14 months
  const latest14 = rollups.slice(-42); // 14 months * 3 platform types = 42 records

  // Group by month
  const monthsMap = new Map();
  for (const rollup of latest14) {
    if (!monthsMap.has(rollup.monthEndDate)) {
      monthsMap.set(rollup.monthEndDate, {
        monthEndDate: rollup.monthEndDate,
        currency: rollup.currency,
        ad: {},
        ecommerce: {},
        combined: {},
      });
    }
    const monthData = monthsMap.get(rollup.monthEndDate);
    monthData[rollup.platformType] = {
      impressions: parseFloat(rollup.impressions || '0'),
      clicks: parseFloat(rollup.clicks || '0'),
      spend: parseFloat(rollup.spend || '0'),
      revenue: parseFloat(rollup.revenue || '0'),
      conversions: parseFloat(rollup.conversions || '0'),
      orders: parseFloat(rollup.orders || '0'),
      sessions: parseFloat(rollup.sessions || '0'),
      roas: parseFloat(rollup.roas || '0'),
      cpo: parseFloat(rollup.cpo || '0'),
      aov: parseFloat(rollup.aov || '0'),
      cpm: parseFloat(rollup.cpm || '0'),
    };
  }

  // Fetch and merge manual overrides
  const overrides = await storage.getClientOverrides(clientId);
  
  for (const override of overrides) {
    const monthData = monthsMap.get(override.monthEndDate);
    if (!monthData) continue; // Skip if month not in the latest 14
    
    const value = parseFloat(override.overrideValue);
    
    // Map metricId to the appropriate platform type and field
    switch (override.metricId) {
      case 'spend':
        if (monthData.ad) monthData.ad.spend = value;
        break;
      case 'ecommerceRevenue':
        if (monthData.ecommerce) monthData.ecommerce.revenue = value;
        break;
      case 'roas':
        if (monthData.ad) monthData.ad.roas = value;
        break;
      case 'orders':
        if (monthData.ecommerce) monthData.ecommerce.orders = value;
        break;
      case 'cpo':
        if (monthData.ecommerce) monthData.ecommerce.cpo = value;
        break;
      case 'aov':
        if (monthData.ecommerce) monthData.ecommerce.aov = value;
        break;
      case 'cpm':
        if (monthData.ad) monthData.ad.cpm = value;
        break;
    }
  }

  return {
    months: Array.from(monthsMap.values()),
    asOf: new Date().toISOString(),
  };
}
