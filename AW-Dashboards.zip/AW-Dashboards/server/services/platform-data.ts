import axios from "axios";

interface PlatformMetrics {
  impressions: number;
  clicks: number;
  conversions: number;
  spend: number;
  revenue: number;
  currency?: string;
  // Ad platform specific metrics
  reach?: number;
  frequency?: number;
  linkClicks?: number;
  cpm?: number;
  // E-commerce specific metrics
  totalOrders?: number;
  totalCustomers?: number;
  repeatCustomers?: number;
  // Daily breakdown (from e-commerce platforms)
  dailyData?: { date: string; revenue: number; orders: number; currency: string }[];
  sessions?: number; // Store sessions for conversion rate calculation
}

interface TimeSeriesData {
  date: string;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
  spend: number;
  roas: number;
}

// Utility function to parse date strings without timezone shifts
// Parses 'YYYY-MM-DD' format directly to avoid UTC/local timezone issues
function parseDateString(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, month - 1, day); // month is 0-indexed
}

// Validate Meta Ads credentials
function validateMetaCredentials(credentials: any): { accessToken: string; adAccountId: string } | null {
  if (!credentials || typeof credentials !== 'object') return null;
  if (typeof credentials.accessToken !== 'string' || !credentials.accessToken.trim()) return null;
  if (typeof credentials.adAccountId !== 'string' || !credentials.adAccountId.trim()) return null;
  return {
    accessToken: credentials.accessToken.trim(),
    adAccountId: credentials.adAccountId.trim(),
  };
}

// Validate Shopify credentials
function validateShopifyCredentials(credentials: any): { shopUrl: string; accessToken: string } | null {
  if (!credentials || typeof credentials !== 'object') return null;
  if (typeof credentials.shopUrl !== 'string' || !credentials.shopUrl.trim()) return null;
  if (typeof credentials.accessToken !== 'string' || !credentials.accessToken.trim()) return null;
  return {
    shopUrl: credentials.shopUrl.trim(),
    accessToken: credentials.accessToken.trim(),
  };
}

// Meta Ads (Facebook) API Integration
export async function fetchMetaAdsData(credentials?: any, days: number = 30, daysOffset: number = 0): Promise<PlatformMetrics> {
  const validatedCreds = validateMetaCredentials(credentials);
  
  if (!validatedCreds) {
    console.log("Meta Ads: Using demo data (credentials not provided or invalid)");
    return generateMockMetrics("Meta Ads");
  }

  try {
    const { accessToken, adAccountId } = validatedCreds;
    const apiVersion = "v21.0";
    const endpoint = `https://graph.facebook.com/${apiVersion}/act_${adAccountId}/insights`;
    
    // Calculate date range with offset
    // daysOffset = 0: last N days (yesterday back N days)
    // daysOffset = N: the N days before that
    const referenceDate = new Date();
    referenceDate.setDate(referenceDate.getDate() - 1 - daysOffset); // yesterday minus offset
    
    const endDate = new Date(referenceDate);
    const startDate = new Date(referenceDate);
    startDate.setDate(referenceDate.getDate() - (days - 1));
    
    const params = {
      access_token: accessToken,
      time_range: JSON.stringify({
        since: startDate.toISOString().split('T')[0],
        until: endDate.toISOString().split('T')[0],
      }),
      // Request specific fields with proper attribution window
      fields: 'impressions,clicks,spend,actions,action_values,purchase_roas,account_currency,reach,frequency,cpm',
      level: 'account',
      // Use 7-day click or 1-day view attribution (default for most accounts)
      action_attribution_windows: ['7d_click', '1d_view'],
    };

    console.log(`Meta Ads API Request: ${startDate.toISOString().split('T')[0]} to ${endDate.toISOString().split('T')[0]}`);

    const response = await axios.get(endpoint, { params });
    const data = response.data.data[0] || {};
    
    console.log('Meta Ads Raw Response:', JSON.stringify(data, null, 2));
    
    // Get account currency
    const currency = data.account_currency || 'USD';

    // Extract purchase actions (conversions) and Meta's calculated revenue
    // Meta provides purchase_roas which uses their attribution model
    let conversions = 0;
    let metaRoas = 0;
    let linkClicks = 0;
    const spend = parseFloat(data.spend || '0');

    if (data.actions) {
      // Use ONLY omni_purchase to avoid double-counting
      // Meta returns the same conversion under multiple action_type aliases:
      // - purchase, offsite_conversion.fb_pixel_purchase, omni_purchase
      // omni_purchase is the canonical, comprehensive metric
      const omniPurchase = data.actions.find((a: any) => a.action_type === 'omni_purchase');
      
      if (omniPurchase) {
        // Use the total value which includes all attribution windows (7d_click + 1d_view + etc)
        conversions = parseFloat(omniPurchase.value || '0');
        console.log(`Meta Ads Conversions: ${conversions} (from omni_purchase total value)`);
      } else {
        console.log('Meta Ads Conversions: No omni_purchase found in actions');
      }
      
      // Extract link clicks
      const linkClickAction = data.actions.find((a: any) => a.action_type === 'link_click');
      if (linkClickAction) {
        linkClicks = parseFloat(linkClickAction.value || '0');
      }
    }

    // Get Meta's calculated ROAS (this uses their proper attribution model)
    if (data.purchase_roas && data.purchase_roas.length > 0) {
      // Use omni_purchase ROAS if available (most comprehensive)
      const omniRoas = data.purchase_roas.find((r: any) => r.action_type === 'omni_purchase');
      if (omniRoas) {
        // Use the total value which includes all attribution windows (7d_click + 1d_view + etc)
        metaRoas = parseFloat(omniRoas.value || '0');
        console.log(`Meta Ads ROAS (from API): ${metaRoas}x`);
      }
    }

    // Calculate revenue from Meta's ROAS * spend
    // This ensures we use Meta's attribution model, not our own calculation
    const revenue = spend > 0 && metaRoas > 0 ? spend * metaRoas : 0;
    
    console.log(`Meta Ads Revenue: ${revenue} ${currency} (calculated from ROAS ${metaRoas}x * spend ${spend})`);

    const reach = parseInt(data.reach || '0');
    const frequency = parseFloat(data.frequency || '0');
    const cpm = parseFloat(data.cpm || '0');

    const metrics = {
      impressions: parseInt(data.impressions || '0'),
      clicks: parseInt(data.clicks || '0'),
      conversions: Math.round(conversions),
      spend,
      revenue: Math.round(revenue * 100) / 100, // Round to 2 decimal places
      currency,
      reach,
      frequency: Math.round(frequency * 100) / 100,
      linkClicks: Math.round(linkClicks),
      cpm: Math.round(cpm * 100) / 100,
    };

    console.log('Meta Ads Final Metrics:', metrics);

    return metrics;
  } catch (error: any) {
    console.error("Meta Ads API error:", error.response?.data || error.message);
    console.log("Falling back to demo data for Meta Ads");
    return generateMockMetrics("Meta Ads");
  }
}

// Shopify API Integration
export async function fetchShopifyData(credentials?: any, days: number = 30, daysOffset: number = 0): Promise<{ orders: number; revenue: number; products: number; currency: string; sessions: number; dailyData?: { date: string; revenue: number; orders: number; currency: string }[] }> {
  const validatedCreds = validateShopifyCredentials(credentials);
  
  if (!validatedCreds) {
    console.log("Shopify: Using demo data (credentials not provided or invalid)");
    return {
      orders: 2340,
      revenue: 187600,
      products: 156,
      currency: 'USD',
      sessions: 58500, // Demo session data
      dailyData: [],
    };
  }

  try {
    const { shopUrl, accessToken } = validatedCreds;
    const apiVersion = "2024-01";
    
    // Ensure shopUrl doesn't have protocol or trailing slash
    const cleanShopUrl = shopUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
    const baseUrl = `https://${cleanShopUrl}/admin/api/${apiVersion}`;

    const headers = {
      'X-Shopify-Access-Token': accessToken,
      'Content-Type': 'application/json',
    };

    // Get orders from specified date range with offset
    // daysOffset = 0: last N days (today back N days)
    // daysOffset = N: the N days before that
    // Normalize dates to start/end of day to prevent overlapping boundaries
    const referenceDate = new Date();
    referenceDate.setHours(23, 59, 59, 999); // End of day
    referenceDate.setDate(referenceDate.getDate() - daysOffset);
    
    const endDate = new Date(referenceDate);
    const startDate = new Date(referenceDate);
    startDate.setDate(referenceDate.getDate() - (days - 1));
    startDate.setHours(0, 0, 0, 0); // Start of day

    // Fetch all pages of orders (Shopify paginates at 250 per page)
    let allOrders: any[] = [];
    let hasMore = true;
    let pageInfo: string | null = null;
    
    console.log(`  → Fetching Shopify orders (may require multiple pages)...`);
    
    while (hasMore) {
      const params: any = {
        fields: 'id,created_at,total_price,currency,financial_status', // Include created_at for daily aggregation
        limit: 250, // Maximum allowed by Shopify API
      };
      
      if (pageInfo) {
        // When using page_info, ONLY include page_info and fields (no other filters)
        params.page_info = pageInfo;
      } else {
        // Only include filters on the FIRST request
        params.status = 'any';
        params.created_at_min = startDate.toISOString();
        params.created_at_max = endDate.toISOString();
      }
      
      const ordersResponse = await axios.get(`${baseUrl}/orders.json`, { headers, params });
      const pageOrders = ordersResponse.data.orders || [];
      allOrders = allOrders.concat(pageOrders);
      
      // Check for pagination link in headers
      const linkHeader = ordersResponse.headers['link'];
      if (linkHeader && linkHeader.includes('rel="next"')) {
        // Extract page_info from next link
        const nextMatch = linkHeader.match(/page_info=([^&>]+)/);
        if (nextMatch) {
          pageInfo = nextMatch[1];
          console.log(`  → Fetched ${pageOrders.length} orders, continuing to next page...`);
        } else {
          hasMore = false;
        }
      } else {
        hasMore = false;
      }
      
      // Safety limit to prevent infinite loops
      if (allOrders.length >= 10000) {
        console.warn(`  ⚠️ Reached safety limit of 10,000 orders`);
        hasMore = false;
      }
    }
    
    const [productsResponse, shopResponse] = await Promise.all([
      axios.get(`${baseUrl}/products/count.json`, { headers }),
      axios.get(`${baseUrl}/shop.json`, { 
        headers,
        params: {
          fields: 'currency,money_format',
        },
      }),
    ]);

    const orders = allOrders;
    const shopCurrency = shopResponse.data.shop?.currency || 'USD';
    
    console.log(`Shopify: Retrieved ${orders.length} orders (last ${days} days), shop currency: ${shopCurrency}`);
    
    // Import currency conversion
    const { convertCurrency } = await import("./currency");
    
    // Calculate total revenue by converting all currencies to shop's primary currency
    let totalRevenue = 0;
    let skippedOrders = 0;
    const ordersByCurrency: Record<string, { count: number; revenue: number; convertedRevenue: number }> = {};
    
    // Aggregate both totals AND daily data in a single pass
    const dailyMap = new Map<string, { revenue: number; orders: number }>();
    
    orders.forEach((order: any) => {
      const orderCurrency = order.currency || shopCurrency;
      const totalPrice = parseFloat(order.total_price || '0');
      
      // Convert to shop currency
      const convertedRevenue = convertCurrency(totalPrice, orderCurrency, shopCurrency);
      
      if (convertedRevenue === null) {
        // Conversion failed - skip this order's revenue
        skippedOrders++;
        console.warn(`  ⚠️ Skipping order revenue: ${totalPrice} ${orderCurrency} (unknown currency)`);
        return;
      }
      
      // Track by currency for logging
      if (!ordersByCurrency[orderCurrency]) {
        ordersByCurrency[orderCurrency] = { count: 0, revenue: 0, convertedRevenue: 0 };
      }
      ordersByCurrency[orderCurrency].count++;
      ordersByCurrency[orderCurrency].revenue += totalPrice;
      ordersByCurrency[orderCurrency].convertedRevenue += convertedRevenue;
      
      // Add to total
      totalRevenue += convertedRevenue;
      
      // Aggregate by date (ISO format YYYY-MM-DD)
      if (order.created_at) {
        const dateKey = order.created_at.split('T')[0]; // Timezone-safe extraction
        const existing = dailyMap.get(dateKey) || { revenue: 0, orders: 0 };
        dailyMap.set(dateKey, {
          revenue: existing.revenue + convertedRevenue,
          orders: existing.orders + 1,
        });
      }
    });
    
    // Log currency breakdown if multiple currencies detected
    const currencies = Object.keys(ordersByCurrency);
    if (currencies.length > 1) {
      console.log(`  📊 Shopify multi-currency breakdown (converting to ${shopCurrency}):`);
      currencies.forEach(currency => {
        const data = ordersByCurrency[currency];
        console.log(`     ${currency}: ${data.count} orders, ${data.revenue.toFixed(2)} ${currency} → ${data.convertedRevenue.toFixed(2)} ${shopCurrency}`);
      });
      console.log(`     Total: ${orders.length} orders, ${totalRevenue.toFixed(2)} ${shopCurrency}`);
    }
    
    if (skippedOrders > 0) {
      console.error(`  ❌ WARNING: Skipped ${skippedOrders} order(s) due to unknown currencies - revenue may be incomplete`);
    }

    // Fetch session data using ShopifyQL via GraphQL Admin API
    // Use the EXACT same date range as orders to ensure accurate conversion rate
    let totalSessions = 0;
    try {
      // Format dates for ShopifyQL (YYYY-MM-DD format)
      const startDateFormatted = startDate.toISOString().split('T')[0]; // YYYY-MM-DD
      const endDateFormatted = endDate.toISOString().split('T')[0]; // Use endDate to match order query
      
      const shopifyqlQuery = `FROM visits SHOW total_sessions SINCE '${startDateFormatted}' UNTIL '${endDateFormatted}'`;
      
      const graphqlQuery = {
        query: `{
          shopifyqlQuery(query: "${shopifyqlQuery}") {
            __typename
            ... on TableResponse {
              tableData {
                rowData
                columns {
                  name
                  dataType
                }
              }
            }
            parseErrors {
              message
            }
          }
        }`
      };

      console.log(`  📊 Fetching session data via ShopifyQL (${startDateFormatted} to ${endDateFormatted})...`);
      
      const graphqlResponse = await axios.post(
        `${baseUrl}/graphql.json`,
        graphqlQuery,
        { headers }
      );

      const shopifyqlData = graphqlResponse.data?.data?.shopifyqlQuery;
      
      if (shopifyqlData?.parseErrors && shopifyqlData.parseErrors.length > 0) {
        console.warn(`  ⚠️ ShopifyQL query errors:`, shopifyqlData.parseErrors);
      }
      
      if (shopifyqlData?.__typename === 'TableResponse' && shopifyqlData.tableData?.rowData) {
        const rowData = shopifyqlData.tableData.rowData;
        if (rowData.length > 0 && rowData[0].length > 0) {
          totalSessions = parseInt(rowData[0][0]) || 0;
          console.log(`  ✓ Retrieved session data: ${totalSessions} sessions`);
        } else {
          console.warn(`  ⚠️ ShopifyQL returned empty session data`);
        }
      } else {
        console.warn(`  ⚠️ ShopifyQL not available (requires Shopify Analytics API access)`);
      }
    } catch (sessionError: any) {
      console.warn(`  ⚠️ Could not fetch session data via ShopifyQL:`, sessionError.response?.data?.errors || sessionError.message);
      console.log(`  → This may require 'read_analytics' permission. Continuing without session data.`);
    }

    // Convert daily map to sorted array
    const dailyData = Array.from(dailyMap.entries())
      .sort((a, b) => b[0].localeCompare(a[0])) // Sort descending by date
      .map(([date, data]) => ({
        date,
        revenue: data.revenue,
        orders: data.orders,
        currency: shopCurrency,
      }));

    return {
      orders: orders.length - skippedOrders,  // Only count orders we could process
      revenue: Math.round(totalRevenue * 100) / 100,
      products: productsResponse.data.count || 0,
      currency: shopCurrency,
      sessions: totalSessions,
      dailyData, // Include daily aggregated data
    };
  } catch (error: any) {
    console.error("Shopify API error:", error.response?.data || error.message);
    console.log("Falling back to demo data for Shopify");
    return {
      orders: 2340,
      revenue: 187600,
      products: 156,
      currency: 'USD',
      sessions: 58500, // Demo session data
      dailyData: [], // Empty daily data for demo
    };
  }
}

// Google Ads API Integration (Placeholder)
export async function fetchGoogleAdsData(credentials?: any): Promise<PlatformMetrics> {
  console.log("Google Ads: Using demo data (real API not yet implemented)");
  return generateMockMetrics("Google Ads");
}

// TikTok Ads API Integration (Placeholder)
export async function fetchTikTokAdsData(credentials?: any): Promise<PlatformMetrics> {
  console.log("TikTok Ads: Using demo data (real API not yet implemented)");
  return generateMockMetrics("TikTok Ads");
}

// Snapchat Ads API Integration (Placeholder)
export async function fetchSnapchatAdsData(credentials?: any): Promise<PlatformMetrics> {
  console.log("Snapchat Ads: Using demo data (real API not yet implemented)");
  return generateMockMetrics("Snapchat Ads");
}

// Google Analytics API Integration (Placeholder)
export async function fetchGoogleAnalyticsData(credentials?: any): Promise<{ sessions: number; users: number; pageviews: number }> {
  console.log("Google Analytics: Using demo data (real API not yet implemented)");
  return {
    sessions: 125000,
    users: 89000,
    pageviews: 456000,
  };
}

// WooCommerce API Integration (Placeholder)
export async function fetchWooCommerceData(credentials?: any, days: number = 30, daysOffset: number = 0): Promise<{ orders: number; revenue: number; products: number; currency: string; sessions: number }> {
  console.log("WooCommerce: Using demo data (real API not yet implemented)");
  return {
    orders: 1890,
    revenue: 145300,
    products: 203,
    currency: 'USD',
    sessions: 47250, // Demo session data
  };
}

// Mock data generator for development/fallback
function generateMockMetrics(platform: string): PlatformMetrics {
  const multipliers: Record<string, number> = {
    "Meta Ads": 1.0,
    "Google Ads": 0.7,
    "TikTok Ads": 0.55,
    "Snapchat Ads": 0.27,
  };
  
  const mult = multipliers[platform] || 0.5;
  const impressions = Math.floor(1200000 * mult);
  const clicks = Math.floor(48000 * mult);
  const linkClicks = Math.floor(clicks * 0.85); // ~85% of clicks are link clicks
  const reach = Math.floor(impressions * 0.7); // Reach is typically 70% of impressions
  const frequency = impressions / reach; // Frequency = Impressions / Reach
  const spend = Math.floor(15000 * mult);
  const cpm = (spend / impressions) * 1000; // Cost per thousand impressions
  
  return {
    impressions,
    clicks,
    conversions: Math.floor(1200 * mult),
    spend,
    revenue: Math.floor(72000 * mult),
    reach,
    frequency: Math.round(frequency * 100) / 100,
    linkClicks,
    cpm: Math.round(cpm * 100) / 100,
  };
}

// Platform type classification
export const AD_PLATFORMS = ["Meta Ads", "Google Ads", "TikTok Ads", "Snapchat Ads"];
export const ECOMMERCE_PLATFORMS = ["Shopify", "WooCommerce"];

export function isAdPlatform(platformName: string): boolean {
  return AD_PLATFORMS.includes(platformName);
}

export function isEcommercePlatform(platformName: string): boolean {
  return ECOMMERCE_PLATFORMS.includes(platformName);
}

// Main aggregation function
export async function aggregatePlatformData(
  platformName: string, 
  credentials?: any, 
  days: number = 30, 
  daysOffset: number = 0,
  ga4Config?: { propertyId: string; credentials: any } // Optional GA4 configuration
): Promise<PlatformMetrics> {
  switch (platformName) {
    case "Meta Ads":
      return fetchMetaAdsData(credentials, days, daysOffset);
    case "Google Ads":
      return fetchGoogleAdsData(credentials);
    case "TikTok Ads":
      return fetchTikTokAdsData(credentials);
    case "Snapchat Ads":
      return fetchSnapchatAdsData(credentials);
    case "Shopify": {
      const shopifyData = await fetchShopifyData(credentials, days, daysOffset);
      
      // If GA4 is configured and Shopify doesn't have session data, try GA4
      let sessions = shopifyData.sessions;
      if (ga4Config && shopifyData.sessions === 0) {
        // Verify both property ID and credentials are present
        if (!ga4Config.propertyId || !ga4Config.credentials) {
          console.warn('  ⚠️ GA4 configured but missing property ID or credentials - skipping GA4 fetch');
        } else {
          console.log('  📊 Shopify session data unavailable, attempting to use GA4...');
          const { fetchGA4Sessions } = await import('./ga4');
          
          // Calculate date range
          const endDate = new Date();
          endDate.setDate(endDate.getDate() - daysOffset);
          const startDate = new Date(endDate);
          startDate.setDate(startDate.getDate() - days + 1);
          
          const startDateStr = startDate.toISOString().split('T')[0];
          const endDateStr = endDate.toISOString().split('T')[0];
          
          const ga4Data = await fetchGA4Sessions(
            ga4Config.credentials,
            ga4Config.propertyId,
            startDateStr,
            endDateStr
          );
          
          sessions = ga4Data.sessions;
          if (sessions > 0) {
            console.log(`  ✅ Using GA4 sessions: ${sessions.toLocaleString()}`);
          }
        }
      }
      
      // E-commerce platforms don't have ad metrics (impressions, clicks, spend)
      // They only provide orders, revenue, and sessions
      return {
        impressions: 0,
        clicks: 0,
        conversions: shopifyData.orders,
        spend: 0,
        revenue: shopifyData.revenue,
        currency: shopifyData.currency,
        sessions,
        dailyData: shopifyData.dailyData, // Pass through daily data
      };
    }
    case "WooCommerce": {
      const wooData = await fetchWooCommerceData(credentials, days, daysOffset);
      return {
        impressions: 0,
        clicks: 0,
        conversions: wooData.orders,
        spend: 0,
        revenue: wooData.revenue,
        currency: wooData.currency,
        sessions: wooData.sessions,
      };
    }
    default:
      return generateMockMetrics(platformName);
  }
}

// Fetch daily breakdown from Meta Ads API
export async function fetchMetaAdsDailyData(credentials?: any, days: number = 30, daysOffset: number = 0): Promise<TimeSeriesData[]> {
  const validatedCreds = validateMetaCredentials(credentials);
  
  if (!validatedCreds) {
    return [];
  }

  try {
    const { accessToken, adAccountId } = validatedCreds;
    const apiVersion = "v21.0";
    const endpoint = `https://graph.facebook.com/${apiVersion}/act_${adAccountId}/insights`;
    
    const referenceDate = new Date();
    referenceDate.setDate(referenceDate.getDate() - 1 - daysOffset);
    
    const endDate = new Date(referenceDate);
    const startDate = new Date(referenceDate);
    startDate.setDate(referenceDate.getDate() - (days - 1));
    
    const timeRange = {
      since: startDate.toISOString().split('T')[0],
      until: endDate.toISOString().split('T')[0],
    };
    
    // DUAL-FETCH STRATEGY for complete daily coverage
    // 1. Conversion-time data: Authoritative but lags 3-7 days
    const conversionParams = {
      access_token: accessToken,
      time_range: JSON.stringify(timeRange),
      time_increment: 1,
      fields: 'impressions,clicks,spend,actions,purchase_roas',
      level: 'account',
      action_attribution_windows: ['7d_click', '1d_view'],
      action_report_time: 'conversion', // Most accurate, but lags
    };

    // 2. Impression-time data: Always complete (all days), provisional metrics
    const impressionParams = {
      access_token: accessToken,
      time_range: JSON.stringify(timeRange),
      time_increment: 1,
      fields: 'impressions,clicks,spend,actions,purchase_roas',
      level: 'account',
      action_attribution_windows: ['7d_click', '1d_view'],
      action_report_time: 'impression', // Complete coverage, less accurate conversions
    };

    // Helper function to fetch all pages from Meta API (handles pagination)
    const fetchAllPages = async (params: any): Promise<any[]> => {
      let allData: any[] = [];
      let currentUrl: string | null = endpoint;
      let pageCount = 0;
      
      while (currentUrl && pageCount < 10) { // Safety limit: max 10 pages
        pageCount++;
        let pageResponse;
        if (currentUrl === endpoint) {
          pageResponse = await axios.get(endpoint, { params });
        } else {
          pageResponse = await axios.get(currentUrl);
        }
        
        const pageData = pageResponse.data.data || [];
        allData = allData.concat(pageData);
        
        // Check if there's a next page
        currentUrl = pageResponse.data.paging?.next || null;
      }
      
      return allData;
    };

    // Fetch both datasets with full pagination support
    console.log(`🔍 Fetching Meta daily data for account ${adAccountId}`);
    
    const [conversionData, impressionData] = await Promise.all([
      fetchAllPages(conversionParams),
      fetchAllPages(impressionParams),
    ]);
    
    console.log(`📊 Meta API returned for account ${adAccountId}:
   Conversion-time dataset: ${conversionData.length} days
   Impression-time dataset: ${impressionData.length} days`);
    
    if (conversionData.length > 0) {
      console.log(`   Conversion dates: ${conversionData[0].date_start} to ${conversionData[conversionData.length - 1].date_start}`);
    }
    if (impressionData.length > 0) {
      console.log(`   Impression dates: ${impressionData[0].date_start} to ${impressionData[impressionData.length - 1].date_start}`);
    }
    
    // Create map for quick lookup
    const conversionMap = new Map(conversionData.map((d: any) => [d.date_start, d]));
    const impressionMap = new Map(impressionData.map((d: any) => [d.date_start, d]));
    
    // Generate FULL date range (all days from start to end)
    const dailyData: any[] = [];
    const currentDate = new Date(startDate);
    
    while (currentDate <= endDate) {
      const dateStr = currentDate.toISOString().split('T')[0];
      const conversionDay = conversionMap.get(dateStr);
      const impressionDay = impressionMap.get(dateStr);
      
      // Use conversion-time, fallback to impression-time, or create zero record
      let sourceDay;
      let dataSource;
      let pendingAttribution;
      
      if (conversionDay) {
        sourceDay = conversionDay;
        dataSource = 'conversion';
        pendingAttribution = false;
      } else if (impressionDay) {
        sourceDay = impressionDay;
        dataSource = 'impression';
        pendingAttribution = true;
      } else {
        // Create zero record for days with no Meta data
        sourceDay = {
          date_start: dateStr,
          impressions: '0',
          clicks: '0',
          spend: '0',
          actions: [],
          purchase_roas: [],
        };
        dataSource = 'none';
        pendingAttribution = false;
      }
      
      dailyData.push({
        ...sourceDay,
        _pendingAttribution: pendingAttribution,
        _dataSource: dataSource,
      });
      
      // Move to next day
      currentDate.setDate(currentDate.getDate() + 1);
    }
    
    // Log data coverage summary
    const conversionDays = conversionData.length;
    const impressionDays = impressionData.length;
    const totalDays = dailyData.length;
    const pendingDays = dailyData.filter((d: any) => d._pendingAttribution).length;
    
    console.log(`  📊 Meta daily data coverage: ${totalDays} days total`);
    console.log(`     Conversion-time: ${conversionDays} days (authoritative)`);
    console.log(`     Impression-time backfill: ${pendingDays} days (pending attribution)`);
    
    if (dailyData.length > 0) {
      const lastDay = dailyData[dailyData.length - 1];
      console.log(`  ℹ️  Last day: ${lastDay.date_start} (source: ${lastDay._dataSource})`);
    }
    
    return dailyData.map((day: any) => {
      const impressions = parseInt(day.impressions || '0');
      const clicks = parseInt(day.clicks || '0');
      const spend = parseFloat(day.spend || '0');
      
      let conversions = 0;
      let metaRoas = 0;
      
      if (day.actions) {
        const omniPurchase = day.actions.find((a: any) => a.action_type === 'omni_purchase');
        if (omniPurchase) {
          // actions array contains COUNTS, not monetary values
          conversions = parseFloat(omniPurchase.value || '0');
        }
      }
      
      if (day.purchase_roas && day.purchase_roas.length > 0) {
        const omniRoas = day.purchase_roas.find((r: any) => r.action_type === 'omni_purchase');
        if (omniRoas) {
          metaRoas = parseFloat(omniRoas.value || '0');
        }
      }
      
      const revenue = spend > 0 && metaRoas > 0 ? spend * metaRoas : 0;
      const roas = spend > 0 ? metaRoas : 0;
      
      // Parse date string directly to avoid timezone shifts
      // Keep ISO date for proper aggregation, generate display format for convenience
      return {
        date: day.date_start, // ISO format (YYYY-MM-DD) for aggregation
        displayDate: parseDateString(day.date_start).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        impressions,
        clicks,
        conversions: Math.round(conversions),
        revenue: Math.round(revenue * 100) / 100,
        spend: Math.round(spend * 100) / 100,
        roas: parseFloat(roas.toFixed(2)),
      };
    });
  } catch (error: any) {
    console.error("Meta Ads daily data error:", error.response?.data || error.message);
    return [];
  }
}

// Top performing ads data structure
export interface TopAd {
  id: string;
  name: string;
  creative: {
    type: 'image' | 'video' | 'carousel';
    thumbnail_url?: string;
    image_url?: string;
    video_url?: string;
  };
  adCopy: {
    headline?: string;
    primaryText?: string;
    description?: string;
  };
  metrics: {
    impressions: number;
    clicks: number;
    conversions: number;
    spend: number;
    ctr: number;
    cpc: number;
    roas: number;
  };
}

// Fetch top performing ads with creatives from Meta Ads API
export async function fetchTopPerformingAds(credentials?: any, days: number = 30, limit: number = 10): Promise<TopAd[]> {
  const validatedCreds = validateMetaCredentials(credentials);
  
  if (!validatedCreds) {
    console.log("Top Ads: Using demo data (credentials not provided or invalid)");
    return generateMockTopAds(limit);
  }

  try {
    const { accessToken, adAccountId } = validatedCreds;
    const apiVersion = "v21.0";
    
    // Calculate date range
    const endDate = new Date();
    endDate.setDate(endDate.getDate() - 1); // yesterday
    const startDate = new Date(endDate);
    startDate.setDate(endDate.getDate() - (days - 1));
    
    // Fetch ads with insights at the ad level
    // Request higher resolution images for better display quality
    const adsEndpoint = `https://graph.facebook.com/${apiVersion}/act_${adAccountId}/ads`;
    const params = {
      access_token: accessToken,
      fields: 'id,name,creative{id,title,body,thumbnail_url,image_url,image_hash,video_id,object_type,effective_object_story_id,asset_feed_spec},insights.time_range({"since":"' + startDate.toISOString().split('T')[0] + '","until":"' + endDate.toISOString().split('T')[0] + '"}){impressions,clicks,spend,actions,purchase_roas,ctr,cpc}',
      limit: 100, // Fetch more to sort and filter
      filtering: JSON.stringify([{
        field: 'effective_status',
        operator: 'IN',
        value: ['ACTIVE', 'PAUSED']
      }])
    };

    console.log(`Fetching top performing ads for ${days} days...`);
    const response = await axios.get(adsEndpoint, { params });
    const ads = response.data.data || [];

    // Process and sort ads by performance
    const processedAds: TopAd[] = ads
      .filter((ad: any) => ad.insights && ad.insights.data && ad.insights.data.length > 0)
      .map((ad: any) => {
        const insight = ad.insights.data[0];
        const impressions = parseInt(insight.impressions || '0');
        const clicks = parseInt(insight.clicks || '0');
        const spend = parseFloat(insight.spend || '0');
        const ctr = parseFloat(insight.ctr || '0');
        const cpc = parseFloat(insight.cpc || '0');
        
        // Get conversions from actions
        let conversions = 0;
        if (insight.actions) {
          const omniPurchase = insight.actions.find((a: any) => a.action_type === 'omni_purchase');
          if (omniPurchase) {
            conversions = parseFloat(omniPurchase.value || '0');
          }
        }
        
        // Get ROAS
        let roas = 0;
        if (insight.purchase_roas) {
          const omniRoas = insight.purchase_roas.find((r: any) => r.action_type === 'omni_purchase');
          if (omniRoas) {
            roas = parseFloat(omniRoas.value || '0');
          }
        }
        
        // Determine creative type and URLs with better type detection
        const creative = ad.creative || {};
        let creativeType: 'image' | 'video' | 'carousel' = 'image';
        let thumbnailUrl = creative.thumbnail_url;
        let imageUrl = creative.image_url;
        let videoUrl = undefined;
        
        // Better ad type detection using object_type and asset_feed_spec
        if (creative.video_id) {
          creativeType = 'video';
          videoUrl = creative.thumbnail_url; // For videos, thumbnail_url is often the video preview
        } else if (creative.asset_feed_spec || creative.object_type === 'SHARE') {
          // Carousel ads often have object_type === 'SHARE' and asset_feed_spec
          creativeType = 'carousel';
        } else if (creative.object_type === 'PHOTO' || creative.image_hash) {
          creativeType = 'image';
        }
        
        // For higher quality images, if we have image_hash, construct full-resolution URL
        if (creative.image_hash && !imageUrl) {
          imageUrl = `https://scontent.xx.fbcdn.net/v/t45.1600-4/${creative.image_hash}`;
        }
        
        return {
          id: ad.id,
          name: ad.name || 'Untitled Ad',
          creative: {
            type: creativeType,
            thumbnail_url: thumbnailUrl,
            image_url: imageUrl,
            video_url: videoUrl,
          },
          adCopy: {
            headline: creative.title || '',
            primaryText: creative.body || '',
            description: '',
          },
          metrics: {
            impressions,
            clicks,
            conversions: Math.round(conversions),
            spend: Math.round(spend * 100) / 100,
            ctr: Math.round(ctr * 100) / 100,
            cpc: Math.round(cpc * 100) / 100,
            roas: Math.round(roas * 100) / 100,
          },
        };
      })
      .sort((a: TopAd, b: TopAd) => {
        // Sort by ROAS first, then by conversions, then by impressions
        if (b.metrics.roas !== a.metrics.roas) return b.metrics.roas - a.metrics.roas;
        if (b.metrics.conversions !== a.metrics.conversions) return b.metrics.conversions - a.metrics.conversions;
        return b.metrics.impressions - a.metrics.impressions;
      })
      .slice(0, limit);

    console.log(`Found ${processedAds.length} top performing ads`);
    return processedAds;
  } catch (error: any) {
    console.error("Top Ads API error:", error.response?.data || error.message);
    console.log("Falling back to demo data for top ads");
    return generateMockTopAds(limit);
  }
}

// Generate mock top performing ads for demo/fallback
function generateMockTopAds(limit: number = 10): TopAd[] {
  const adTypes: ('image' | 'video' | 'carousel')[] = ['image', 'video', 'carousel'];
  const headlines = [
    'Summer Sale - 50% Off Everything',
    'New Collection Just Dropped',
    'Limited Time Offer - Shop Now',
    'Free Shipping on All Orders',
    'Exclusive Deal Inside',
  ];
  const primaryTexts = [
    'Discover amazing deals on our latest collection. Shop now and save big!',
    'Transform your style with our premium products. Quality guaranteed.',
    'Don\'t miss out on this incredible offer. Limited stock available.',
    'Join thousands of happy customers. Order today!',
    'Experience the difference. Premium quality at unbeatable prices.',
  ];

  return Array.from({ length: limit }, (_, i) => ({
    id: `ad_${i + 1}`,
    name: `Top Performing Ad ${i + 1}`,
    creative: {
      type: adTypes[i % 3],
      thumbnail_url: `https://placehold.co/400x400/3b82f6/white?text=Ad+${i + 1}`,
      image_url: `https://placehold.co/800x600/3b82f6/white?text=Ad+${i + 1}`,
    },
    adCopy: {
      headline: headlines[i % headlines.length],
      primaryText: primaryTexts[i % primaryTexts.length],
    },
    metrics: {
      impressions: Math.floor(50000 * (1 - i * 0.1)),
      clicks: Math.floor(2000 * (1 - i * 0.1)),
      conversions: Math.floor(150 * (1 - i * 0.12)),
      spend: Math.floor(1500 * (1 - i * 0.1)),
      ctr: parseFloat((4 - i * 0.2).toFixed(2)),
      cpc: parseFloat((0.75 + i * 0.05).toFixed(2)),
      roas: parseFloat((8 - i * 0.5).toFixed(2)),
    },
  }));
}

// Time series data generator (fallback for non-Meta platforms)
export function generateTimeSeriesData(days: number = 7): TimeSeriesData[] {
  const data: TimeSeriesData[] = [];
  const today = new Date();
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    
    const baseImpressions = 450000;
    const variation = Math.random() * 0.3 - 0.15;
    const impressions = Math.floor(baseImpressions * (1 + variation));
    const clicks = Math.floor(impressions * 0.04);
    const conversions = Math.floor(impressions * 0.003);
    const revenue = Math.floor(impressions * 0.014);
    const spend = Math.floor(impressions * 0.007);
    const roas = spend > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0;
    
    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      impressions,
      clicks,
      conversions,
      revenue,
      spend,
      roas,
    });
  }
  
  return data;
}

// Fetch Shopify orders aggregated by date for chart data
export async function fetchShopifyDailyData(credentials?: any, days: number = 30, daysOffset: number = 0): Promise<{ date: string; revenue: number; orders: number }[]> {
  const validatedCreds = validateShopifyCredentials(credentials);
  
  if (!validatedCreds) {
    return [];
  }

  try {
    const { shopUrl, accessToken } = validatedCreds;
    const apiVersion = "2024-01";
    
    const cleanShopUrl = shopUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
    const baseUrl = `https://${cleanShopUrl}/admin/api/${apiVersion}`;

    const headers = {
      'X-Shopify-Access-Token': accessToken,
      'Content-Type': 'application/json',
    };

    // Calculate date range
    const referenceDate = new Date();
    referenceDate.setHours(23, 59, 59, 999);
    referenceDate.setDate(referenceDate.getDate() - daysOffset);
    
    const endDate = new Date(referenceDate);
    const startDate = new Date(referenceDate);
    startDate.setDate(referenceDate.getDate() - (days - 1));
    startDate.setHours(0, 0, 0, 0);

    // Fetch all orders with created_at and total_price
    let allOrders: any[] = [];
    let hasMore = true;
    let pageInfo: string | null = null;
    
    while (hasMore) {
      const params: any = {
        fields: 'id,created_at,total_price,currency,financial_status',
        limit: 250,
      };
      
      if (pageInfo) {
        params.page_info = pageInfo;
      } else {
        params.status = 'any';
        params.created_at_min = startDate.toISOString();
        params.created_at_max = endDate.toISOString();
      }
      
      const ordersResponse = await axios.get(`${baseUrl}/orders.json`, { headers, params });
      const pageOrders = ordersResponse.data.orders || [];
      allOrders = allOrders.concat(pageOrders);
      
      const linkHeader = ordersResponse.headers['link'];
      if (linkHeader && linkHeader.includes('rel="next"')) {
        const nextMatch = linkHeader.match(/page_info=([^&>]+)/);
        if (nextMatch) {
          pageInfo = nextMatch[1];
        } else {
          hasMore = false;
        }
      } else {
        hasMore = false;
      }
      
      if (allOrders.length >= 10000) {
        hasMore = false;
      }
    }

    // Get shop currency
    const shopResponse = await axios.get(`${baseUrl}/shop.json`, {
      headers,
      params: { fields: 'currency' },
    });
    const shopCurrency = shopResponse.data.shop?.currency || 'USD';

    // Aggregate orders by date using ISO format (YYYY-MM-DD)
    const dailyMap = new Map<string, { revenue: number; orders: number }>();
    
    for (const order of allOrders) {
      // Extract date directly from created_at ISO string to avoid timezone shifts
      // created_at format: "2025-10-15T14:23:45-04:00"
      const dateKey = order.created_at.split('T')[0]; // YYYY-MM-DD (preserves store timezone)
      
      const revenue = parseFloat(order.total_price) || 0;
      const existing = dailyMap.get(dateKey) || { revenue: 0, orders: 0 };
      
      dailyMap.set(dateKey, {
        revenue: existing.revenue + revenue,
        orders: existing.orders + 1,
      });
    }

    // Convert to sorted array (most recent first)
    const sortedData = Array.from(dailyMap.entries())
      .sort((a, b) => b[0].localeCompare(a[0])) // Sort descending by date
      .map(([date, data]) => ({
        date,
        revenue: data.revenue,
        orders: data.orders,
        currency: shopCurrency,
      }));

    return sortedData;

  } catch (error: any) {
    console.error(`Shopify daily data error:`, error.response?.data || error.message);
    return [];
  }
}
