import { 
  type User, 
  type InsertUser,
  type Client,
  type InsertClient,
  type PlatformConnection,
  type InsertPlatformConnection,
  type Report,
  type InsertReport,
  type MonthlyDataOverride,
  type InsertMonthlyDataOverride,
  type OverridesAudit,
  type InsertOverridesAudit
} from "@shared/schema";
import { db } from "./db";
import { users, clients, platformConnections, reports, monthlyDataOverrides, overridesAudit } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  
  // Client methods
  getAllClients(): Promise<Client[]>;
  getClient(id: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: string, client: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: string): Promise<boolean>;
  
  // Platform connection methods
  getPlatformConnections(clientId: string): Promise<PlatformConnection[]>;
  getAllPlatformConnections(): Promise<PlatformConnection[]>;
  createPlatformConnection(connection: InsertPlatformConnection): Promise<PlatformConnection>;
  updatePlatformConnection(id: string, connection: Partial<InsertPlatformConnection>): Promise<PlatformConnection | undefined>;
  deletePlatformConnection(id: string): Promise<boolean>;
  
  // Report methods
  getAllReports(): Promise<Report[]>;
  getReportsByClient(clientId: string): Promise<Report[]>;
  getReport(id: string): Promise<Report | undefined>;
  getReportBySlug(slug: string): Promise<Report | undefined>;
  createReport(report: InsertReport): Promise<Report>;
  updateReport(id: string, report: Partial<InsertReport>): Promise<Report | undefined>;
  deleteReport(id: string): Promise<boolean>;
  
  // Monthly data override methods
  getClientOverrides(clientId: string): Promise<MonthlyDataOverride[]>;
  getOverride(clientId: string, monthEndDate: string, metricId: string): Promise<MonthlyDataOverride | undefined>;
  createOrUpdateOverride(override: InsertMonthlyDataOverride): Promise<MonthlyDataOverride>;
  deleteOverride(clientId: string, monthEndDate: string, metricId: string): Promise<boolean>;
  createAuditEntry(audit: InsertOverridesAudit): Promise<OverridesAudit>;
}

export class DbStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ pool, createTableIfMissing: true });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Client methods
  async getAllClients(): Promise<Client[]> {
    return await db.select().from(clients);
  }

  async getClient(id: string): Promise<Client | undefined> {
    const result = await db.select().from(clients).where(eq(clients.id, id));
    return result[0];
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const result = await db.insert(clients).values(insertClient).returning();
    return result[0];
  }

  async updateClient(id: string, clientUpdate: Partial<InsertClient>): Promise<Client | undefined> {
    const result = await db.update(clients)
      .set(clientUpdate)
      .where(eq(clients.id, id))
      .returning();
    return result[0];
  }

  async deleteClient(id: string): Promise<boolean> {
    const result = await db.delete(clients).where(eq(clients.id, id)).returning();
    return result.length > 0;
  }

  // Platform connection methods
  async getPlatformConnections(clientId: string): Promise<PlatformConnection[]> {
    return await db.select().from(platformConnections).where(eq(platformConnections.clientId, clientId));
  }

  async getAllPlatformConnections(): Promise<PlatformConnection[]> {
    return await db.select().from(platformConnections);
  }

  async createPlatformConnection(connection: InsertPlatformConnection): Promise<PlatformConnection> {
    const result = await db.insert(platformConnections).values(connection).returning();
    return result[0];
  }

  async updatePlatformConnection(id: string, connectionUpdate: Partial<InsertPlatformConnection>): Promise<PlatformConnection | undefined> {
    const result = await db.update(platformConnections)
      .set(connectionUpdate)
      .where(eq(platformConnections.id, id))
      .returning();
    return result[0];
  }

  async deletePlatformConnection(id: string): Promise<boolean> {
    const result = await db.delete(platformConnections).where(eq(platformConnections.id, id)).returning();
    return result.length > 0;
  }

  // Report methods
  async getAllReports(): Promise<Report[]> {
    return await db.select().from(reports);
  }

  async getReportsByClient(clientId: string): Promise<Report[]> {
    return await db.select().from(reports).where(eq(reports.clientId, clientId));
  }

  async getReport(id: string): Promise<Report | undefined> {
    const result = await db.select().from(reports).where(eq(reports.id, id));
    return result[0];
  }

  async getReportBySlug(slug: string): Promise<Report | undefined> {
    const result = await db.select().from(reports).where(eq(reports.slug, slug));
    return result[0];
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const result = await db.insert(reports).values(insertReport).returning();
    return result[0];
  }

  async updateReport(id: string, reportUpdate: Partial<InsertReport>): Promise<Report | undefined> {
    const result = await db.update(reports)
      .set(reportUpdate)
      .where(eq(reports.id, id))
      .returning();
    return result[0];
  }

  async deleteReport(id: string): Promise<boolean> {
    const result = await db.delete(reports).where(eq(reports.id, id)).returning();
    return result.length > 0;
  }

  // Monthly data override methods
  async getClientOverrides(clientId: string): Promise<MonthlyDataOverride[]> {
    return await db.select().from(monthlyDataOverrides).where(eq(monthlyDataOverrides.clientId, clientId));
  }

  async getOverride(clientId: string, monthEndDate: string, metricId: string): Promise<MonthlyDataOverride | undefined> {
    const result = await db.select()
      .from(monthlyDataOverrides)
      .where(
        and(
          eq(monthlyDataOverrides.clientId, clientId),
          eq(monthlyDataOverrides.monthEndDate, monthEndDate),
          eq(monthlyDataOverrides.metricId, metricId)
        )
      );
    return result[0];
  }

  async createOrUpdateOverride(override: InsertMonthlyDataOverride): Promise<MonthlyDataOverride> {
    const existing = await this.getOverride(override.clientId, override.monthEndDate, override.metricId);
    
    if (existing) {
      // Update existing override
      const result = await db.update(monthlyDataOverrides)
        .set({
          overrideValue: override.overrideValue,
          editedBy: override.editedBy,
          editedAt: new Date(),
        })
        .where(
          and(
            eq(monthlyDataOverrides.clientId, override.clientId),
            eq(monthlyDataOverrides.monthEndDate, override.monthEndDate),
            eq(monthlyDataOverrides.metricId, override.metricId)
          )
        )
        .returning();
      return result[0];
    } else {
      // Create new override
      const result = await db.insert(monthlyDataOverrides).values(override).returning();
      return result[0];
    }
  }

  async deleteOverride(clientId: string, monthEndDate: string, metricId: string): Promise<boolean> {
    const result = await db.delete(monthlyDataOverrides)
      .where(
        and(
          eq(monthlyDataOverrides.clientId, clientId),
          eq(monthlyDataOverrides.monthEndDate, monthEndDate),
          eq(monthlyDataOverrides.metricId, metricId)
        )
      )
      .returning();
    return result.length > 0;
  }

  async createAuditEntry(audit: InsertOverridesAudit): Promise<OverridesAudit> {
    const result = await db.insert(overridesAudit).values(audit).returning();
    return result[0];
  }
}

export const storage = new DbStorage();
