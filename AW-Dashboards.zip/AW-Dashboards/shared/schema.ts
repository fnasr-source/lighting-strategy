import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb, decimal, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"), // 'admin' or 'user'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const clients = pgTable("clients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email"),
  baseCurrency: text("base_currency").default("USD").notNull(),
  ga4PropertyId: text("ga4_property_id"),
  ga4Credentials: jsonb("ga4_credentials"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const platformConnections = pgTable("platform_connections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => clients.id, { onDelete: "cascade" }),
  platform: text("platform").notNull(),
  isConnected: boolean("is_connected").default(false).notNull(),
  credentials: jsonb("credentials"),
  lastSync: timestamp("last_sync"),
});

export const reports = pgTable("reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => clients.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(), // For shareable URLs
  description: text("description"), // Short summary
  content: text("content").notNull(), // Markdown content
  dateRange: jsonb("date_range"), // Optional - for compatibility
  platforms: text("platforms").array(), // Optional - for compatibility
  isPublic: boolean("is_public").default(true).notNull(), // Public by default for sharing
  createdBy: varchar("created_by").references(() => users.id),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
});

export const monthlyPlatformMetrics = pgTable("monthly_platform_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => clients.id, { onDelete: "cascade" }),
  platform: text("platform").notNull(), // e.g., "Meta Ads", "Shopify"
  platformType: text("platform_type").notNull(), // "ad" or "ecommerce"
  monthEndDate: text("month_end_date").notNull(), // YYYY-MM-DD format (last day of month)
  currency: text("currency").notNull(), // Client's base currency
  originalCurrency: text("original_currency"), // Original platform currency for reference
  
  // Metrics (stored as text to preserve precision, convert to number in app)
  impressions: text("impressions").default("0"),
  clicks: text("clicks").default("0"),
  spend: text("spend").default("0"),
  revenue: text("revenue").default("0"),
  conversions: text("conversions").default("0"),
  orders: text("orders").default("0"),
  sessions: text("sessions").default("0"),
  reach: text("reach").default("0"),
  frequency: text("frequency").default("0"),
  linkClicks: text("link_clicks").default("0"),
  cpm: text("cpm").default("0"),
  
  aggregatedAt: timestamp("aggregated_at").defaultNow().notNull(),
}, (table) => ({
  uniqueMonthPlatform: unique().on(table.clientId, table.platform, table.monthEndDate),
}));

export const monthlyClientRollups = pgTable("monthly_client_rollups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => clients.id, { onDelete: "cascade" }),
  platformType: text("platform_type").notNull(), // "ad", "ecommerce", or "combined"
  monthEndDate: text("month_end_date").notNull(), // YYYY-MM-DD format
  currency: text("currency").notNull(),
  
  // Aggregated metrics
  impressions: text("impressions").default("0"),
  clicks: text("clicks").default("0"),
  spend: text("spend").default("0"),
  revenue: text("revenue").default("0"),
  conversions: text("conversions").default("0"),
  orders: text("orders").default("0"),
  sessions: text("sessions").default("0"),
  roas: text("roas").default("0"),
  cpo: text("cpo").default("0"),
  aov: text("aov").default("0"),
  cpm: text("cpm").default("0"),
  
  aggregatedAt: timestamp("aggregated_at").defaultNow().notNull(),
}, (table) => ({
  uniqueMonthType: unique().on(table.clientId, table.platformType, table.monthEndDate),
}));

export const dataSyncJobs = pgTable("data_sync_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => clients.id, { onDelete: "cascade" }),
  jobType: text("job_type").notNull(), // "initial_backfill", "monthly_update"
  status: text("status").notNull().default("pending"), // "pending", "running", "completed", "failed"
  startDate: text("start_date"), // YYYY-MM-DD
  endDate: text("end_date"), // YYYY-MM-DD
  errorMessage: text("error_message"),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const monthlyDataOverrides = pgTable("monthly_data_overrides", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => clients.id, { onDelete: "cascade" }),
  monthEndDate: text("month_end_date").notNull(), // YYYY-MM-DD format (last day of month)
  metricId: text("metric_id").notNull(), // e.g., "spend", "ecommerceRevenue", "roas", "orders", "cpo", "aov", "cpm"
  overrideValue: text("override_value").notNull(), // Stored as text to preserve precision
  editedBy: varchar("edited_by").notNull().references(() => users.id),
  editedAt: timestamp("edited_at").defaultNow().notNull(),
}, (table) => ({
  uniqueMonthMetric: unique().on(table.clientId, table.monthEndDate, table.metricId),
}));

export const overridesAudit = pgTable("overrides_audit", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  overrideId: varchar("override_id").references(() => monthlyDataOverrides.id, { onDelete: "set null" }),
  clientId: varchar("client_id").notNull().references(() => clients.id, { onDelete: "cascade" }),
  monthEndDate: text("month_end_date").notNull(),
  metricId: text("metric_id").notNull(),
  actionType: text("action_type").notNull(), // "created", "updated", "deleted"
  oldValue: text("old_value"),
  newValue: text("new_value"),
  editedBy: varchar("edited_by").notNull().references(() => users.id),
  editedAt: timestamp("edited_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
}).extend({
  role: z.enum(["admin", "user"]).default("user"),
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true,
});

export const insertPlatformConnectionSchema = createInsertSchema(platformConnections).omit({
  id: true,
  lastSync: true,
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  generatedAt: true,
}).extend({
  slug: z.string().min(1).regex(/^[a-z0-9-]+$/, "Slug must contain only lowercase letters, numbers, and hyphens"),
  content: z.string().min(10, "Report content is required"),
  isPublic: z.boolean().default(true),
});

export const insertMonthlyDataOverrideSchema = createInsertSchema(monthlyDataOverrides).omit({
  id: true,
  editedAt: true,
}).extend({
  metricId: z.enum(["spend", "ecommerceRevenue", "roas", "orders", "cpo", "aov", "cpm"]),
  overrideValue: z.string(),
});

export const insertOverridesAuditSchema = createInsertSchema(overridesAudit).omit({
  id: true,
  editedAt: true,
}).extend({
  actionType: z.enum(["created", "updated", "deleted"]),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type PlatformConnection = typeof platformConnections.$inferSelect;
export type InsertPlatformConnection = z.infer<typeof insertPlatformConnectionSchema>;
export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;
export type MonthlyPlatformMetrics = typeof monthlyPlatformMetrics.$inferSelect;
export type MonthlyClientRollups = typeof monthlyClientRollups.$inferSelect;
export type DataSyncJob = typeof dataSyncJobs.$inferSelect;
export type MonthlyDataOverride = typeof monthlyDataOverrides.$inferSelect;
export type InsertMonthlyDataOverride = z.infer<typeof insertMonthlyDataOverrideSchema>;
export type OverridesAudit = typeof overridesAudit.$inferSelect;
export type InsertOverridesAudit = z.infer<typeof insertOverridesAuditSchema>;
